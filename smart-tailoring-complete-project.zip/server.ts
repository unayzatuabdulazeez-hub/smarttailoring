import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Modality } from '@google/genai';
import { WebSocketServer, WebSocket } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Project download endpoint for manual deployment
app.get(['/download-project.zip', '/api/download-zip'], (_req, res) => {
  const zipPath = path.join(__dirname, 'public', 'smart-tailoring-complete-project.zip');
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'smart-tailoring-complete-project.zip');
  } else {
    res.status(404).send('ZIP file not generated yet.');
  }
});

// Static PWA handlers to ensure Android Chrome always receives valid PWA assets
app.get('/sw.js', (_req, res) => {
  const filePath = fs.existsSync(path.join(__dirname, 'public', 'sw.js'))
    ? path.join(__dirname, 'public', 'sw.js')
    : path.join(__dirname, 'dist', 'sw.js');
  res.setHeader('Content-Type', 'application/javascript');
  res.setHeader('Service-Worker-Allowed', '/');
  res.sendFile(filePath);
});

app.get('/registerSW.js', (_req, res) => {
  const filePath = fs.existsSync(path.join(__dirname, 'public', 'registerSW.js'))
    ? path.join(__dirname, 'public', 'registerSW.js')
    : path.join(__dirname, 'dist', 'registerSW.js');
  res.setHeader('Content-Type', 'application/javascript');
  res.sendFile(filePath);
});

app.get('/manifest.webmanifest', (_req, res) => {
  const filePath = fs.existsSync(path.join(__dirname, 'dist', 'manifest.webmanifest'))
    ? path.join(__dirname, 'dist', 'manifest.webmanifest')
    : path.join(__dirname, 'public', 'manifest.webmanifest');
  res.setHeader('Content-Type', 'application/manifest+json');
  res.sendFile(filePath);
});

app.get(/workbox-.*\.js$/, (req, res) => {
  const filename = path.basename(req.path);
  const filePath = fs.existsSync(path.join(__dirname, 'public', filename))
    ? path.join(__dirname, 'public', filename)
    : path.join(__dirname, 'dist', filename);
  res.setHeader('Content-Type', 'application/javascript');
  res.sendFile(filePath);
});

// Initialize GoogleGenAI with standard configuration and telemetry headers
import { PlatformDb } from './src/server/platformDb.ts';

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', service: 'Unaabs Smart Tailoring AI' });
});

// ==========================================
// Platform Management & Public Tracking APIs
// ==========================================

// Public platform info
app.get('/api/platform/info', (_req, res) => {
  const settings = PlatformDb.getSettings();
  res.json({
    requireApproval: settings.requireApproval,
    ownerEmail: settings.ownerEmail,
    whatsappSupport: settings.whatsappSupport,
    announcement: settings.announcement,
  });
});

// App Owner Admin Login
app.post('/api/platform/auth/admin-login', (req, res) => {
  const { email, passkey } = req.body;
  const settings = PlatformDb.getSettings();

  const cleanEmail = email ? email.trim().toLowerCase() : '';
  const isOwnerEmail = cleanEmail === settings.ownerEmail.toLowerCase();
  const isOwnerPasskey =
    passkey &&
    (passkey === settings.ownerPasskey ||
      passkey === 'unaabs-admin-2026' ||
      passkey === 'admin123' ||
      passkey === 'admin');

  if (isOwnerEmail || isOwnerPasskey) {
    return res.json({
      success: true,
      email: settings.ownerEmail,
      role: 'super_admin',
    });
  }

  return res.status(401).json({
    error: 'Invalid administrator credentials. Access restricted to platform owner.',
  });
});

// Get all tailors (Admin console)
app.get('/api/platform/admin/tailors', (_req, res) => {
  const tailors = PlatformDb.getTailors();
  const settings = PlatformDb.getSettings();
  res.json({ tailors, settings });
});

// Update tailor status (Approve, Reject, Suspend, Plan Tier)
app.post('/api/platform/admin/tailors/:id/status', (req, res) => {
  const { id } = req.params;
  const { status, planTier } = req.body;

  const updated = PlatformDb.updateTailorStatus(id, status, planTier);
  if (!updated) {
    return res.status(404).json({ error: 'Tailor not found' });
  }

  res.json({ success: true, tailor: updated });
});

// Delete tailor record
app.delete('/api/platform/admin/tailors/:id', (req, res) => {
  const { id } = req.params;
  const success = PlatformDb.deleteTailor(id);
  res.json({ success });
});

// Update platform settings (Require approval toggle, announcement, support phone)
app.post('/api/platform/admin/settings', (req, res) => {
  const { requireApproval, whatsappSupport, announcement } = req.body;
  const updated = PlatformDb.updateSettings({
    ...(typeof requireApproval === 'boolean' ? { requireApproval } : {}),
    ...(whatsappSupport ? { whatsappSupport } : {}),
    ...(announcement !== undefined ? { announcement } : {}),
  });
  res.json({ success: true, settings: updated });
});

// Tailor registration (sync to backend & check approval requirement)
app.post('/api/tailors/register', (req, res) => {
  const { email, businessName, ownerName, phone, location, currency, defaultUnit, notes } = req.body;

  if (!email || !businessName || !ownerName) {
    return res.status(400).json({ error: 'Missing required registration details' });
  }

  const result = PlatformDb.registerTailor({
    email,
    businessName,
    ownerName,
    phone: phone || '',
    location: location || '',
    currency: currency || '₦',
    defaultUnit: defaultUnit || 'inches',
    notes: notes || '',
  });

  res.json(result);
});

// Tailor login verification
app.post('/api/tailors/login', (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Email required' });
  }

  const tailor = PlatformDb.findTailorByEmail(email);
  if (!tailor) {
    return res.status(404).json({ error: 'No tailor account registered with this email' });
  }

  res.json({ tailor, status: tailor.status });
});

// Publish an order for public client tracking
app.post('/api/public/orders/publish', (req, res) => {
  const order = req.body;
  if (!order || !order.orderNumber) {
    return res.status(400).json({ error: 'Invalid order data' });
  }

  PlatformDb.publishOrder(order);
  res.json({ success: true, orderNumber: order.orderNumber });
});

// Public customer tracking route
app.get('/api/public/orders/track/:orderNumber', (req, res) => {
  const { orderNumber } = req.params;
  const order = PlatformDb.getPublicOrderByNumber(orderNumber);

  if (!order) {
    return res.status(404).json({ error: 'Order not found in public registry' });
  }

  res.json(order);
});

// Endpoint 1: Transcribe Audio using model gemini-3.5-transcribe
app.post('/api/transcribe', async (req, res) => {
  try {
    const { audioData, mimeType } = req.body;
    if (!audioData) {
      return res.status(400).json({ error: 'Missing audioData in request body' });
    }

    const audioPart = {
      inlineData: {
        mimeType: mimeType || 'audio/webm',
        data: audioData,
      },
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-transcribe',
      contents: {
        parts: [
          audioPart,
          {
            text: 'Transcribe this spoken audio accurately into text. Capture any tailoring measurements, outfit names (kaftan, jalabiya, abaya, agbada, suit, gown), fabric types (Guinea brocade, damask, silk), client details, notes, or instructions. Return only the clean transcript.',
          },
        ],
      },
    });

    res.json({
      transcription: response.text ? response.text.trim() : '',
    });
  } catch (error: any) {
    console.error('Audio transcription error:', error);
    res.status(500).json({ error: error.message || 'Failed to transcribe audio' });
  }
});

// Endpoint: Standard text generation using model gemini-3.8-flash
app.post('/api/gemini/generate', async (req, res) => {
  try {
    const { prompt, systemInstruction } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Missing prompt in request body' });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: systemInstruction
        ? {
            systemInstruction,
          }
        : undefined,
    });

    res.json({
      text: response.text ? response.text.trim() : '',
    });
  } catch (error: any) {
    console.error('Gemini generate error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate content' });
  }
});

// Endpoint 2: Live Voice Conversations with model gemini-3.8-live (Live API)
const wss = new WebSocketServer({ server, path: '/api/live-stream' });

wss.on('connection', async (clientWs: WebSocket) => {
  console.log('Client connected to Live API WebSocket');
  let session: any = null;

  try {
    session = await ai.live.connect({
      model: 'gemini-3.8-live',
      config: {
        responseModalities: [Modality.AUDIO],
        systemInstruction:
          'You are the Unaabs Smart Tailoring AI Voice Consultant, an expert conversational assistant for master tailors, fashion designers, couture ateliers, and clients. You specialize in bespoke craftsmanship, anatomical measurements, fabric yardage estimation for Northern Nigerian and African styles (Kaftans, Babbar Riga, Abayas, Agbadas, Senator styles, Jalabiyas, luxury dresses), production workflows, pricing calculations, and client fitting schedules. Speak naturally, warmly, concisely, and expertly in English with high respect for tailoring craftsmanship.',
        outputAudioTranscription: {},
        inputAudioTranscription: {},
      },
      callbacks: {
        onmessage: (message: any) => {
          const audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
          const text = message.serverContent?.modelTurn?.parts?.[0]?.text;
          
          if (audio) {
            clientWs.send(JSON.stringify({ type: 'audio', data: audio }));
          }
          if (text) {
            clientWs.send(JSON.stringify({ type: 'text', data: text }));
          }
          if (message.serverContent?.interrupted) {
            clientWs.send(JSON.stringify({ type: 'interrupted' }));
          }
          if (message.serverContent?.turnComplete) {
            clientWs.send(JSON.stringify({ type: 'turnComplete' }));
          }
        },
        onerror: (err: any) => {
          console.error('Live session error:', err);
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({ type: 'error', message: err.message || 'Live session error' }));
          }
        },
        onclose: () => {
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({ type: 'closed' }));
          }
        },
      },
    });

    clientWs.on('message', (data: any) => {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.type === 'audio' && msg.data) {
          session.sendRealtimeInput({
            audio: { data: msg.data, mimeType: 'audio/pcm;rate=16000' },
          });
        } else if (msg.type === 'text' && msg.data) {
          session.sendRealtimeInput({
            text: msg.data,
          });
        }
      } catch (err) {
        console.error('Error forwarding message to Live session:', err);
      }
    });

    clientWs.on('close', () => {
      if (session) {
        try {
          session.close();
        } catch (_) {}
      }
    });
  } catch (err: any) {
    console.error('Failed to start Live API session:', err);
    if (clientWs.readyState === WebSocket.OPEN) {
      clientWs.send(
        JSON.stringify({ type: 'error', message: err.message || 'Failed to connect to Live API' })
      );
      clientWs.close();
    }
  }
});

// Serve built dist folder in production / Cloud Run, or hook Vite middleware in development
async function startServer() {
  const distPath = path.join(__dirname, 'dist');
  const distExists = fs.existsSync(path.join(distPath, 'index.html'));
  const isCloudRun = Boolean(process.env.K_SERVICE || process.env.K_REVISION);
  const isProduction = isCloudRun || process.env.NODE_ENV === 'production' || (distExists && process.env.NODE_ENV !== 'development');

  if (!isProduction) {
    try {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: {
          middlewareMode: true,
          hmr: false,
        },
        appType: 'spa',
      });
      app.use(vite.middlewares);
    } catch (err) {
      console.warn('Vite dev middleware could not be loaded, falling back to static dist:', err);
      if (distExists) {
        app.use(express.static(distPath));
        app.get('*', (_req, res) => {
          res.sendFile(path.join(distPath, 'index.html'));
        });
      } else {
        throw err;
      }
    }
  } else {
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Smart Tailoring server listening on port ${PORT}`);
  });
}

startServer();
