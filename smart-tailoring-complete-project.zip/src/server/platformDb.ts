import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.join(__dirname, '..', '..', 'data');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

export interface TailorRecord {
  id: string;
  email: string;
  businessName: string;
  ownerName: string;
  phone: string;
  location?: string;
  currency: string;
  defaultUnit: string;
  status: 'pending' | 'approved' | 'rejected' | 'suspended';
  planTier: 'Standard' | 'Premium' | 'VIP';
  registeredAt: string;
  approvedAt?: string;
  notes?: string;
}

export interface PlatformConfig {
  ownerEmail: string;
  ownerPasskey: string;
  requireApproval: boolean;
  whatsappSupport: string;
  announcement: string;
}

export interface PublicOrderRecord {
  orderNumber: string;
  tailorId: string;
  tailorBusinessName: string;
  tailorOwnerName: string;
  tailorPhone: string;
  tailorCurrency: string;
  tailorAddress?: string;
  bankDetails?: string;
  customerName: string;
  customerPhone?: string;
  outfitType: string;
  customOutfitType?: string;
  fabricType?: string;
  fabricColour?: string;
  serviceTier: 'Standard' | 'Premium' | 'Royal_VIP';
  productionStatus: string;
  orderDescription?: string;
  deliveryDate: string;
  fittingAppointmentDate?: string;
  totalCost: number;
  amountPaid: number;
  balanceDue: number;
  updatedAt: string;
}

const SETTINGS_FILE = path.join(DATA_DIR, 'platform_settings.json');
const TAILORS_FILE = path.join(DATA_DIR, 'tailors.json');
const PUBLIC_ORDERS_FILE = path.join(DATA_DIR, 'public_orders.json');

const DEFAULT_SETTINGS: PlatformConfig = {
  ownerEmail: 'unayzatuabdulazeez@gmail.com',
  ownerPasskey: 'unaabs-admin-2026',
  requireApproval: true,
  whatsappSupport: '+234 803 555 0192',
  announcement: 'Welcome to Unaabs Smart Tailoring! New ateliers require owner verification before access.'
};

const SEED_TAILORS: TailorRecord[] = [
  {
    id: 'demo_tailor_user',
    email: 'atelier@smarttailoring.africa',
    businessName: 'Zaria Bespoke & Couture',
    ownerName: 'Ibrahim & Fatima Al-Hassan',
    phone: '+234 803 555 0192',
    location: 'Victoria Island, Lagos & Kaduna',
    currency: '₦',
    defaultUnit: 'inches',
    status: 'approved',
    planTier: 'Premium',
    registeredAt: '2026-01-15T09:00:00.000Z',
    approvedAt: '2026-01-15T09:05:00.000Z'
  },
  {
    id: 'tailor_req_101',
    email: 'musa.kano@example.com',
    businessName: 'Kano Royal Stitches & Embroidery',
    ownerName: 'Musa Abdullahi',
    phone: '+234 802 111 2233',
    location: 'Kano, Fagge',
    currency: '₦',
    defaultUnit: 'inches',
    status: 'pending',
    planTier: 'Standard',
    registeredAt: '2026-10-05T14:30:00.000Z',
    notes: 'Specializes in Senator styles & Guinea brocade Kaftans'
  },
  {
    id: 'tailor_req_102',
    email: 'fatima.couture@example.com',
    businessName: 'Zahra Bridal & Abaya Atelier',
    ownerName: 'Fatima Zahra',
    phone: '+234 813 444 7788',
    location: 'Maitama, Abuja',
    currency: '₦',
    defaultUnit: 'inches',
    status: 'pending',
    planTier: 'Premium',
    registeredAt: '2026-10-05T16:45:00.000Z',
    notes: 'High-end modest couture & wedding guest capes'
  }
];

function readJson<T>(filePath: string, fallback: T): T {
  try {
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, 'utf-8');
      return JSON.parse(content);
    }
  } catch (err) {
    console.error(`Error reading ${filePath}:`, err);
  }
  return fallback;
}

function writeJson<T>(filePath: string, data: T): void {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error(`Error writing ${filePath}:`, err);
  }
}

export class PlatformDb {
  static getSettings(): PlatformConfig {
    const settings = readJson<PlatformConfig>(SETTINGS_FILE, DEFAULT_SETTINGS);
    return { ...DEFAULT_SETTINGS, ...settings };
  }

  static updateSettings(updates: Partial<PlatformConfig>): PlatformConfig {
    const current = this.getSettings();
    const updated = { ...current, ...updates };
    writeJson(SETTINGS_FILE, updated);
    return updated;
  }

  static getTailors(): TailorRecord[] {
    const tailors = readJson<TailorRecord[]>(TAILORS_FILE, SEED_TAILORS);
    if (!fs.existsSync(TAILORS_FILE)) {
      writeJson(TAILORS_FILE, SEED_TAILORS);
    }
    return tailors;
  }

  static findTailorByEmail(email: string): TailorRecord | undefined {
    const tailors = this.getTailors();
    const clean = email.trim().toLowerCase();
    return tailors.find((t) => t.email.toLowerCase() === clean);
  }

  static findTailorById(id: string): TailorRecord | undefined {
    const tailors = this.getTailors();
    return tailors.find((t) => t.id === id);
  }

  static registerTailor(data: {
    email: string;
    businessName: string;
    ownerName: string;
    phone: string;
    location?: string;
    currency?: string;
    defaultUnit?: string;
    notes?: string;
  }): { tailor: TailorRecord; requiresApproval: boolean } {
    const tailors = this.getTailors();
    const existing = this.findTailorByEmail(data.email);
    const settings = this.getSettings();
    const initialStatus = settings.requireApproval ? 'pending' : 'approved';

    if (existing) {
      return { tailor: existing, requiresApproval: existing.status === 'pending' };
    }

    const newTailor: TailorRecord = {
      id: 'tailor_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      email: data.email.trim(),
      businessName: data.businessName.trim(),
      ownerName: data.ownerName.trim(),
      phone: data.phone.trim(),
      location: data.location?.trim() || '',
      currency: data.currency || '₦',
      defaultUnit: data.defaultUnit || 'inches',
      status: initialStatus,
      planTier: 'Standard',
      registeredAt: new Date().toISOString(),
      approvedAt: initialStatus === 'approved' ? new Date().toISOString() : undefined,
      notes: data.notes || ''
    };

    tailors.push(newTailor);
    writeJson(TAILORS_FILE, tailors);
    return { tailor: newTailor, requiresApproval: initialStatus === 'pending' };
  }

  static updateTailorStatus(
    id: string,
    status: 'pending' | 'approved' | 'rejected' | 'suspended',
    planTier?: 'Standard' | 'Premium' | 'VIP'
  ): TailorRecord | null {
    const tailors = this.getTailors();
    const index = tailors.findIndex((t) => t.id === id);
    if (index === -1) return null;

    tailors[index].status = status;
    if (planTier) tailors[index].planTier = planTier;
    if (status === 'approved' && !tailors[index].approvedAt) {
      tailors[index].approvedAt = new Date().toISOString();
    }

    writeJson(TAILORS_FILE, tailors);
    return tailors[index];
  }

  static deleteTailor(id: string): boolean {
    const tailors = this.getTailors();
    const filtered = tailors.filter((t) => t.id !== id);
    if (filtered.length !== tailors.length) {
      writeJson(TAILORS_FILE, filtered);
      return true;
    }
    return false;
  }

  // Public Order Tracking
  static getPublicOrders(): Record<string, PublicOrderRecord> {
    return readJson<Record<string, PublicOrderRecord>>(PUBLIC_ORDERS_FILE, {});
  }

  static publishOrder(order: PublicOrderRecord): void {
    const orders = this.getPublicOrders();
    orders[order.orderNumber.toUpperCase()] = {
      ...order,
      orderNumber: order.orderNumber.toUpperCase(),
      updatedAt: new Date().toISOString()
    };
    writeJson(PUBLIC_ORDERS_FILE, orders);
  }

  static getPublicOrderByNumber(orderNumber: string): PublicOrderRecord | null {
    const orders = this.getPublicOrders();
    return orders[orderNumber.trim().toUpperCase()] || null;
  }
}
