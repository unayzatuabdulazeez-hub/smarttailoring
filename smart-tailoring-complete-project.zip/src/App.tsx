import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Customer, Order, Quote } from './types';
import { Navbar } from './components/common/Navbar';
import { Sidebar } from './components/common/Sidebar';
import { ToastContainer } from './components/common/ToastContainer';
import { PrintReceiptModal } from './components/common/PrintReceiptModal';
import { LandingPage } from './components/landing/LandingPage';
import { AuthModal } from './components/auth/AuthModal';
import { DashboardView } from './components/dashboard/DashboardView';
import { CustomersView } from './components/customers/CustomersView';
import { CustomerDetailView } from './components/customers/CustomerDetailView';
import { CustomerFormModal } from './components/customers/CustomerFormModal';
import { MeasurementsView } from './components/measurements/MeasurementsView';
import { OrdersView } from './components/orders/OrdersView';
import { OrderDetailView } from './components/orders/OrderDetailView';
import { OrderFormModal } from './components/orders/OrderFormModal';
import { RecordPaymentModal } from './components/orders/RecordPaymentModal';
import { PaymentsView } from './components/payments/PaymentsView';
import { PricingCalculatorView } from './components/calculator/PricingCalculatorView';
import { MaterialsView } from './components/materials/MaterialsView';
import { ReportsView } from './components/reports/ReportsView';
import { SettingsView } from './components/settings/SettingsView';
import { AudioTranscribeModal } from './components/voice/AudioTranscribeModal';
import { LiveVoiceAssistantModal } from './components/voice/LiveVoiceAssistantModal';
import { LocalToPremiumModal } from './components/premium/LocalToPremiumModal';
import { PlatformAdminView } from './components/admin/PlatformAdminView';
import { CustomerTrackingView } from './components/portal/CustomerTrackingView';
import { Rocket, Sparkles } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const {
    user,
    isLoggedIn,
    isDemo,
    activeTab,
    setActiveTab,
    selectedCustomerId,
    setSelectedCustomerId,
    selectedOrderId,
    setSelectedOrderId,
    enterDemoMode,
    getCustomer,
    getOrder
  } = useApp();

  // Modal controls
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup' | 'admin'>('signup');

  // Customer tracking & Admin state
  const [trackingOrderNumber, setTrackingOrderNumber] = useState<string | null>(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('track');
  });

  const [isPlatformAdmin, setIsPlatformAdmin] = useState<boolean>(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('admin') === 'true';
  });

  // Order modal states
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [orderToEdit, setOrderToEdit] = useState<Order | null>(null);
  const [initialCustomerIdForOrder, setInitialCustomerIdForOrder] = useState<string | undefined>();
  const [quoteForOrder, setQuoteForOrder] = useState<Quote | null>(null);

  // Customer modal states
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [customerToEdit, setCustomerToEdit] = useState<Customer | null>(null);

  // Record payment modal
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [orderForPayment, setOrderForPayment] = useState<Order | null>(null);

  // AI Voice & Hub modals
  const [showTranscribeModal, setShowTranscribeModal] = useState(false);
  const [showLiveVoiceModal, setShowLiveVoiceModal] = useState(false);
  const [showPremiumModal, setShowPremiumModal] = useState(false);

  // 1. If App Owner Admin View is active:
  if (isPlatformAdmin) {
    return (
      <>
        <PlatformAdminView
          adminEmail="unayzatuabdulazeez@gmail.com"
          onExitAdmin={() => {
            setIsPlatformAdmin(false);
            window.history.replaceState({}, '', '/');
          }}
        />
        <ToastContainer />
      </>
    );
  }

  // 2. If Public Customer Tracking portal is active:
  if (trackingOrderNumber !== null) {
    return (
      <>
        <CustomerTrackingView
          initialOrderNumber={trackingOrderNumber}
          onExitPortal={() => {
            setTrackingOrderNumber(null);
            window.history.replaceState({}, '', '/');
          }}
        />
        <ToastContainer />
      </>
    );
  }

  // 3. If user is not authenticated and not in demo, render public Landing Page
  if (!isLoggedIn) {
    return (
      <>
        <LandingPage
          onOpenAuth={() => {
            setAuthMode('signup');
            setShowAuthModal(true);
          }}
          onExploreDemo={() => {
            enterDemoMode();
          }}
          onOpenTracking={() => {
            setTrackingOrderNumber('');
          }}
          onOpenOwnerPortal={() => {
            setAuthMode('admin');
            setShowAuthModal(true);
          }}
        />
        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          defaultMode={authMode}
          onAdminLogin={() => setIsPlatformAdmin(true)}
        />
        <ToastContainer />
      </>
    );
  }

  // Handlers
  const handleOpenNewOrder = (customerId?: string) => {
    setOrderToEdit(null);
    setQuoteForOrder(null);
    setInitialCustomerIdForOrder(customerId);
    setShowOrderModal(true);
  };

  const handleEditOrder = (order: Order) => {
    setOrderToEdit(order);
    setQuoteForOrder(null);
    setShowOrderModal(true);
  };

  const handleConvertQuoteToOrder = (quote: Quote) => {
    setOrderToEdit(null);
    setQuoteForOrder(quote);
    setShowOrderModal(true);
  };

  const handleOpenNewCustomer = () => {
    setCustomerToEdit(null);
    setShowCustomerModal(true);
  };

  const handleEditCustomer = (customer: Customer) => {
    setCustomerToEdit(customer);
    setShowCustomerModal(true);
  };

  const handleRecordPayment = (order: Order) => {
    setOrderForPayment(order);
    setShowPaymentModal(true);
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-stone-900 flex flex-col font-sans">
      {/* Prominent Demo Mode Banner with 1-click Go Live */}
      {isDemo && (
        <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-[#58111A] text-white px-4 py-2.5 text-xs font-medium flex flex-col sm:flex-row items-center justify-between gap-2 shadow-sm no-print">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-full bg-white/20 text-white font-bold text-[10px] uppercase tracking-wider">
              Demo Mode
            </span>
            <span>You are previewing sample workshop data. Ready to use Smart Tailoring for your own shop?</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => {
                setAuthMode('signup');
                setShowAuthModal(true);
              }}
              className="bg-white text-[#58111A] hover:bg-amber-50 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
            >
              <Rocket className="w-3.5 h-3.5 text-[#58111A]" />
              <span>Go Live / Create My Account</span>
            </button>
            <button
              onClick={() => {
                setAuthMode('login');
                setShowAuthModal(true);
              }}
              className="text-amber-200 hover:text-white px-2 py-1 text-xs font-semibold underline cursor-pointer"
            >
              Log In
            </button>
          </div>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        onOpenNewOrder={() => handleOpenNewOrder()}
        onOpenAuth={() => setShowAuthModal(true)}
        onOpenTranscribe={() => setShowTranscribeModal(true)}
        onOpenLiveVoice={() => setShowLiveVoiceModal(true)}
        onOpenPremiumHub={() => setShowPremiumModal(true)}
      />

      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {/* Responsive Sidebar */}
        <Sidebar
          onOpenNewOrder={() => handleOpenNewOrder()}
          onOpenPremiumHub={() => setShowPremiumModal(true)}
          onOpenAuth={() => setShowAuthModal(true)}
          onOpenAdmin={() => setIsPlatformAdmin(true)}
        />

        {/* Main Content Area */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto pb-24 md:pb-8">
          {activeTab === 'dashboard' && (
            <DashboardView
              onOpenNewOrder={() => handleOpenNewOrder()}
              onOpenNewCustomer={handleOpenNewCustomer}
              onSelectOrder={(id) => {
                setSelectedOrderId(id);
                setActiveTab('orders');
              }}
              onSelectCustomer={(id) => {
                setSelectedCustomerId(id);
                setActiveTab('customers');
              }}
              onOpenTranscribe={() => setShowTranscribeModal(true)}
              onOpenLiveVoice={() => setShowLiveVoiceModal(true)}
              onOpenAuth={() => setShowAuthModal(true)}
            />
          )}

          {activeTab === 'customers' && (
            selectedCustomerId ? (
              <CustomerDetailView
                customerId={selectedCustomerId}
                onBack={() => setSelectedCustomerId(null)}
                onEditCustomer={() => {
                  const cust = getCustomer(selectedCustomerId);
                  if (cust) handleEditCustomer(cust);
                }}
                onOpenOrder={(orderId) => {
                  setSelectedOrderId(orderId);
                  setActiveTab('orders');
                }}
                onNewOrderForCustomer={(cId) => handleOpenNewOrder(cId)}
              />
            ) : (
              <CustomersView
                onSelectCustomer={(id) => setSelectedCustomerId(id)}
              />
            )
          )}

          {activeTab === 'measurements' && (
            <MeasurementsView
              onSelectCustomer={(customerId) => {
                setSelectedCustomerId(customerId);
                setActiveTab('customers');
              }}
            />
          )}

          {activeTab === 'orders' && (
            selectedOrderId ? (
              <OrderDetailView
                orderId={selectedOrderId}
                onBack={() => setSelectedOrderId(null)}
                onEditOrder={() => {
                  const ord = getOrder(selectedOrderId);
                  if (ord) handleEditOrder(ord);
                }}
                onRecordPayment={() => {
                  const ord = getOrder(selectedOrderId);
                  if (ord) handleRecordPayment(ord);
                }}
              />
            ) : (
              <OrdersView
                onOpenNewOrder={() => handleOpenNewOrder()}
                onSelectOrder={(orderId) => setSelectedOrderId(orderId)}
              />
            )
          )}

          {activeTab === 'payments' && (
            <PaymentsView
              onOpenOrder={(orderId) => {
                setSelectedOrderId(orderId);
                setActiveTab('orders');
              }}
              onOpenCustomer={(customerId) => {
                setSelectedCustomerId(customerId);
                setActiveTab('customers');
              }}
            />
          )}

          {activeTab === 'calculator' && (
            <PricingCalculatorView
              onConvertToOrder={handleConvertQuoteToOrder}
            />
          )}

          {activeTab === 'materials' && (
            <MaterialsView />
          )}

          {activeTab === 'reports' && (
            <ReportsView />
          )}

          {activeTab === 'settings' && (
            <SettingsView />
          )}
        </main>
      </div>

      {/* Global Modals */}
      {showOrderModal && (
        <OrderFormModal
          isOpen={showOrderModal}
          onClose={() => {
            setShowOrderModal(false);
            setOrderToEdit(null);
            setQuoteForOrder(null);
            setInitialCustomerIdForOrder(undefined);
          }}
          orderToEdit={orderToEdit}
          initialCustomerId={initialCustomerIdForOrder}
          initialQuoteData={
            quoteForOrder
              ? {
                  customerName: quoteForOrder.customerName,
                  outfitType: quoteForOrder.outfitType,
                  fabricCost: quoteForOrder.fabricCost,
                  labourCost: quoteForOrder.labourCost,
                  materialsCost: quoteForOrder.materialsCost,
                  otherExpenses: quoteForOrder.otherExpenses,
                  sellingPrice: quoteForOrder.sellingPrice,
                  notes: quoteForOrder.notes
                }
              : undefined
          }
        />
      )}

      {showCustomerModal && (
        <CustomerFormModal
          isOpen={showCustomerModal}
          onClose={() => {
            setShowCustomerModal(false);
            setCustomerToEdit(null);
          }}
          customerToEdit={customerToEdit}
        />
      )}

      {showPaymentModal && orderForPayment && (
        <RecordPaymentModal
          isOpen={showPaymentModal}
          onClose={() => {
            setShowPaymentModal(false);
            setOrderForPayment(null);
          }}
          order={orderForPayment}
        />
      )}

      <PrintReceiptModal />

      <AudioTranscribeModal
        isOpen={showTranscribeModal}
        onClose={() => setShowTranscribeModal(false)}
      />

      <LiveVoiceAssistantModal
        isOpen={showLiveVoiceModal}
        onClose={() => setShowLiveVoiceModal(false)}
      />

      <LocalToPremiumModal
        isOpen={showPremiumModal}
        onClose={() => setShowPremiumModal(false)}
      />

      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
