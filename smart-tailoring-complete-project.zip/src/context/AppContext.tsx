import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import {
  UserProfile,
  Customer,
  MeasurementProfile,
  Order,
  Payment,
  Material,
  Quote,
  NavigationTab,
  ProductionStatus
} from '../types';
import { StorageService, DEMO_USER_ID, DEFAULT_DEMO_PROFILE } from '../services/storage';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppContextType {
  user: UserProfile | null;
  isLoggedIn: boolean;
  isDemo: boolean;
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  selectedCustomerId: string | null;
  setSelectedCustomerId: (id: string | null) => void;
  selectedOrderId: string | null;
  setSelectedOrderId: (id: string | null) => void;
  
  // Data
  customers: Customer[];
  measurements: MeasurementProfile[];
  orders: Order[];
  payments: Payment[];
  materials: Material[];
  quotes: Quote[];

  // Actions
  login: (email: string) => boolean;
  register: (params: { email: string; businessName: string; ownerName: string; phone?: string; currency?: string }) => void;
  logout: () => void;
  enterDemoMode: () => void;
  resetDemoData: () => void;

  // Customers CRUD
  addCustomer: (cust: Omit<Customer, 'id' | 'userId' | 'createdAt'>) => Customer;
  updateCustomer: (id: string, updates: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;
  getCustomer: (id: string) => Customer | undefined;

  // Measurements CRUD
  addMeasurementProfile: (meas: Omit<MeasurementProfile, 'id' | 'userId' | 'recordedAt' | 'updatedAt'>) => MeasurementProfile;
  updateMeasurementProfile: (id: string, updates: Partial<MeasurementProfile>) => void;
  duplicateMeasurementProfile: (id: string) => MeasurementProfile | null;
  deleteMeasurementProfile: (id: string) => void;
  getMeasurementProfile: (id: string) => MeasurementProfile | undefined;
  getCustomerMeasurements: (customerId: string) => MeasurementProfile[];

  // Orders CRUD
  addOrder: (orderData: Omit<Order, 'id' | 'userId' | 'orderNumber' | 'createdAt' | 'updatedAt' | 'profit' | 'balanceDue' | 'totalCost'>) => Order;
  updateOrder: (id: string, updates: Partial<Order>) => void;
  updateOrderStatus: (id: string, status: ProductionStatus) => void;
  deleteOrder: (id: string) => void;
  getOrder: (id: string) => Order | undefined;
  getCustomerOrders: (customerId: string) => Order[];

  // Payments CRUD
  addPayment: (paymentData: Omit<Payment, 'id' | 'userId' | 'createdAt'>) => Payment;
  deletePayment: (id: string) => void;
  getOrderPayments: (orderId: string) => Payment[];

  // Materials CRUD
  addMaterial: (mat: Omit<Material, 'id' | 'userId' | 'updatedAt'>) => Material;
  updateMaterial: (id: string, updates: Partial<Material>) => void;
  adjustMaterialQuantity: (id: string, delta: number) => void;
  deleteMaterial: (id: string) => void;

  // Quotes CRUD
  addQuote: (quote: Omit<Quote, 'id' | 'userId' | 'createdAt'>) => Quote;
  deleteQuote: (id: string) => void;

  // Settings
  updateProfile: (updates: Partial<UserProfile>) => void;

  // Formatting & UI
  formatCurrency: (amount: number) => string;
  toasts: ToastMessage[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
  printOrder: Order | null;
  setPrintOrder: (order: Order | null) => void;
  globalSearch: string;
  setGlobalSearch: (q: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(() => {
    const session = StorageService.getCurrentSession();
    if (session) {
      const data = StorageService.getUserData(session.userId);
      return data.profile;
    }
    return null;
  });

  const [activeTab, setActiveTab] = useState<NavigationTab>('dashboard');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  // Core state for active user data
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [measurements, setMeasurements] = useState<MeasurementProfile[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);
  const [quotes, setQuotes] = useState<Quote[]>([]);

  // UI state
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [printOrder, setPrintOrder] = useState<Order | null>(null);
  const [globalSearch, setGlobalSearch] = useState<string>('');

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 6);
    setToasts(prev => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  // Sync memory state with storage for active user
  const reloadData = useCallback((userId: string) => {
    const data = StorageService.getUserData(userId);
    setUser(data.profile);
    setCustomers(data.customers);
    setMeasurements(data.measurements);
    setOrders(data.orders);
    setPayments(data.payments);
    setMaterials(data.materials);
    setQuotes(data.quotes);
  }, []);

  // Save current dataset to storage
  const syncStore = useCallback((userId: string, dataOverrides?: {
    customers?: Customer[];
    measurements?: MeasurementProfile[];
    orders?: Order[];
    payments?: Payment[];
    materials?: Material[];
    quotes?: Quote[];
    profile?: UserProfile;
  }) => {
    if (!user) return;
    const current = StorageService.getUserData(userId);
    const updated = {
      profile: dataOverrides?.profile ?? current.profile,
      customers: dataOverrides?.customers ?? customers,
      measurements: dataOverrides?.measurements ?? measurements,
      orders: dataOverrides?.orders ?? orders,
      payments: dataOverrides?.payments ?? payments,
      materials: dataOverrides?.materials ?? materials,
      quotes: dataOverrides?.quotes ?? quotes
    };
    StorageService.saveUserData(userId, updated);
  }, [user, customers, measurements, orders, payments, materials, quotes]);

  // Load user data on startup
  useEffect(() => {
    if (user) {
      reloadData(user.id);
    }
  }, [user?.id, reloadData]);

  // Auth methods
  const login = useCallback((email: string): boolean => {
    const loggedInProfile = StorageService.loginUser(email);
    if (loggedInProfile) {
      setUser(loggedInProfile);
      reloadData(loggedInProfile.id);
      showToast(`Welcome back to ${loggedInProfile.businessName}!`, 'success');
      return true;
    }
    showToast('User not found. Check your email or explore demo.', 'error');
    return false;
  }, [reloadData, showToast]);

  const register = useCallback((params: {
    email: string;
    businessName: string;
    ownerName: string;
    phone?: string;
    currency?: string;
  }) => {
    const newProfile = StorageService.registerUser(params);
    setUser(newProfile);
    reloadData(newProfile.id);
    showToast(`Welcome to Smart Tailoring, ${newProfile.businessName}!`, 'success');
  }, [reloadData, showToast]);

  const logout = useCallback(() => {
    StorageService.clearSession();
    setUser(null);
    setSelectedCustomerId(null);
    setSelectedOrderId(null);
    showToast('Logged out successfully.', 'info');
  }, [showToast]);

  const enterDemoMode = useCallback(() => {
    StorageService.setCurrentSession(DEMO_USER_ID, true);
    reloadData(DEMO_USER_ID);
    showToast('Switched to Demo Mode with sample atelier data.', 'info');
  }, [reloadData, showToast]);

  const resetDemoData = useCallback(() => {
    StorageService.resetDemoData();
    if (user?.id === DEMO_USER_ID) {
      reloadData(DEMO_USER_ID);
    }
    showToast('Demo data reset to original defaults.', 'info');
  }, [user?.id, reloadData, showToast]);

  // Formatting currency
  const formatCurrency = useCallback((amount: number): string => {
    const curr = user?.currency || '₦';
    const formatted = Math.round(amount).toLocaleString('en-US');
    return `${curr}${formatted}`;
  }, [user?.currency]);

  // Customer Actions
  const addCustomer = useCallback((custData: Omit<Customer, 'id' | 'userId' | 'createdAt'>): Customer => {
    if (!user) throw new Error('Not authenticated');
    const newCustomer: Customer = {
      ...custData,
      id: 'cust_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      userId: user.id,
      createdAt: new Date().toISOString()
    };
    const updated = [newCustomer, ...customers];
    setCustomers(updated);
    syncStore(user.id, { customers: updated });
    showToast(`Customer "${newCustomer.fullName}" added successfully!`, 'success');
    return newCustomer;
  }, [user, customers, syncStore, showToast]);

  const updateCustomer = useCallback((id: string, updates: Partial<Customer>) => {
    if (!user) return;
    const updated = customers.map(c => c.id === id ? { ...c, ...updates, updatedAt: new Date().toISOString() } : c);
    setCustomers(updated);
    syncStore(user.id, { customers: updated });
    showToast('Customer profile updated.', 'success');
  }, [user, customers, syncStore, showToast]);

  const deleteCustomer = useCallback((id: string) => {
    if (!user) return;
    const toDelete = customers.find(c => c.id === id);
    const updatedCustomers = customers.filter(c => c.id !== id);
    // Also remove customer's measurements and orders or keep clean
    const updatedMeasurements = measurements.filter(m => m.customerId !== id);
    const updatedOrders = orders.filter(o => o.customerId !== id);
    setCustomers(updatedCustomers);
    setMeasurements(updatedMeasurements);
    setOrders(updatedOrders);
    syncStore(user.id, {
      customers: updatedCustomers,
      measurements: updatedMeasurements,
      orders: updatedOrders
    });
    if (selectedCustomerId === id) setSelectedCustomerId(null);
    showToast(`Customer ${toDelete?.fullName || ''} deleted.`, 'info');
  }, [user, customers, measurements, orders, selectedCustomerId, syncStore, showToast]);

  const getCustomer = useCallback((id: string) => {
    return customers.find(c => c.id === id);
  }, [customers]);

  // Measurements Actions
  const addMeasurementProfile = useCallback((measData: Omit<MeasurementProfile, 'id' | 'userId' | 'recordedAt' | 'updatedAt'>): MeasurementProfile => {
    if (!user) throw new Error('Not authenticated');
    const now = new Date().toISOString();
    const newProfile: MeasurementProfile = {
      ...measData,
      id: 'meas_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      userId: user.id,
      recordedAt: now,
      updatedAt: now
    };
    const updated = [newProfile, ...measurements];
    setMeasurements(updated);
    syncStore(user.id, { measurements: updated });
    showToast(`Measurement "${newProfile.profileName}" saved!`, 'success');
    return newProfile;
  }, [user, measurements, syncStore, showToast]);

  const updateMeasurementProfile = useCallback((id: string, updates: Partial<MeasurementProfile>) => {
    if (!user) return;
    const updated = measurements.map(m => m.id === id ? { ...m, ...updates, updatedAt: new Date().toISOString() } : m);
    setMeasurements(updated);
    syncStore(user.id, { measurements: updated });
    showToast('Measurement profile updated.', 'success');
  }, [user, measurements, syncStore, showToast]);

  const duplicateMeasurementProfile = useCallback((id: string): MeasurementProfile | null => {
    if (!user) return null;
    const existing = measurements.find(m => m.id === id);
    if (!existing) return null;
    const now = new Date().toISOString();
    const duplicate: MeasurementProfile = {
      ...existing,
      id: 'meas_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      profileName: `${existing.profileName} (Copy)`,
      recordedAt: now,
      updatedAt: now
    };
    const updated = [duplicate, ...measurements];
    setMeasurements(updated);
    syncStore(user.id, { measurements: updated });
    showToast(`Measurement duplicated as "${duplicate.profileName}"!`, 'success');
    return duplicate;
  }, [user, measurements, syncStore, showToast]);

  const deleteMeasurementProfile = useCallback((id: string) => {
    if (!user) return;
    const updated = measurements.filter(m => m.id !== id);
    setMeasurements(updated);
    syncStore(user.id, { measurements: updated });
    showToast('Measurement profile deleted.', 'info');
  }, [user, measurements, syncStore, showToast]);

  const getMeasurementProfile = useCallback((id: string) => {
    return measurements.find(m => m.id === id);
  }, [measurements]);

  const getCustomerMeasurements = useCallback((customerId: string) => {
    return measurements.filter(m => m.customerId === customerId);
  }, [measurements]);

  // Orders Actions
  const addOrder = useCallback((orderData: Omit<Order, 'id' | 'userId' | 'orderNumber' | 'createdAt' | 'updatedAt' | 'profit' | 'balanceDue' | 'totalCost'>): Order => {
    if (!user) throw new Error('Not authenticated');
    const now = new Date().toISOString();
    const orderNumber = StorageService.generateNextOrderNumber(user.id);
    const totalCost = Number(orderData.fabricCost || 0) + 
                      Number(orderData.labourCost || 0) + 
                      Number(orderData.additionalMaterialCost || 0) + 
                      Number(orderData.otherCost || 0);
    const profit = Number(orderData.sellingPrice || 0) - totalCost;
    const balanceDue = Math.max(0, Number(orderData.sellingPrice || 0) - Number(orderData.amountPaid || 0));

    const newOrder: Order = {
      ...orderData,
      id: 'ord_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      userId: user.id,
      orderNumber,
      totalCost,
      profit,
      balanceDue,
      createdAt: now,
      updatedAt: now
    };

    const updatedOrders = [newOrder, ...orders];
    let updatedPayments = [...payments];

    // If an initial deposit was made with the order, record it in payments table!
    if (orderData.amountPaid > 0) {
      const initialPayment: Payment = {
        id: 'pay_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        orderId: newOrder.id,
        customerId: newOrder.customerId,
        userId: user.id,
        amount: orderData.amountPaid,
        paymentDate: now.split('T')[0],
        paymentMethod: 'Bank Transfer',
        note: 'Initial deposit with order creation',
        createdAt: now
      };
      updatedPayments = [initialPayment, ...updatedPayments];
      setPayments(updatedPayments);
    }

    setOrders(updatedOrders);
    syncStore(user.id, { orders: updatedOrders, payments: updatedPayments });
    showToast(`Order #${orderNumber} created successfully!`, 'success');
    return newOrder;
  }, [user, orders, payments, syncStore, showToast]);

  const updateOrder = useCallback((id: string, updates: Partial<Order>) => {
    if (!user) return;
    const updated = orders.map(ord => {
      if (ord.id !== id) return ord;
      const merged = { ...ord, ...updates, updatedAt: new Date().toISOString() };
      const totalCost = Number(merged.fabricCost || 0) + 
                        Number(merged.labourCost || 0) + 
                        Number(merged.additionalMaterialCost || 0) + 
                        Number(merged.otherCost || 0);
      merged.totalCost = totalCost;
      merged.profit = Number(merged.sellingPrice || 0) - totalCost;
      merged.balanceDue = Math.max(0, Number(merged.sellingPrice || 0) - Number(merged.amountPaid || 0));
      return merged;
    });
    setOrders(updated);
    syncStore(user.id, { orders: updated });
    showToast('Order details updated.', 'success');
  }, [user, orders, syncStore, showToast]);

  const updateOrderStatus = useCallback((id: string, status: ProductionStatus) => {
    if (!user) return;
    const updated = orders.map(o => o.id === id ? { ...o, productionStatus: status, updatedAt: new Date().toISOString() } : o);
    setOrders(updated);
    syncStore(user.id, { orders: updated });
    showToast(`Order status updated to "${status}"`, 'success');
  }, [user, orders, syncStore, showToast]);

  const deleteOrder = useCallback((id: string) => {
    if (!user) return;
    const orderToDelete = orders.find(o => o.id === id);
    const updatedOrders = orders.filter(o => o.id !== id);
    const updatedPayments = payments.filter(p => p.orderId !== id);
    setOrders(updatedOrders);
    setPayments(updatedPayments);
    syncStore(user.id, { orders: updatedOrders, payments: updatedPayments });
    if (selectedOrderId === id) setSelectedOrderId(null);
    showToast(`Order ${orderToDelete?.orderNumber || ''} deleted.`, 'info');
  }, [user, orders, payments, selectedOrderId, syncStore, showToast]);

  const getOrder = useCallback((id: string) => {
    return orders.find(o => o.id === id);
  }, [orders]);

  const getCustomerOrders = useCallback((customerId: string) => {
    return orders.filter(o => o.customerId === customerId);
  }, [orders]);

  // Payments Actions
  const addPayment = useCallback((paymentData: Omit<Payment, 'id' | 'userId' | 'createdAt'>): Payment => {
    if (!user) throw new Error('Not authenticated');
    const now = new Date().toISOString();
    const newPayment: Payment = {
      ...paymentData,
      id: 'pay_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      userId: user.id,
      createdAt: now
    };

    const updatedPayments = [newPayment, ...payments];
    setPayments(updatedPayments);

    // Recalculate target order total amount paid & balance due
    const updatedOrders = orders.map(ord => {
      if (ord.id !== paymentData.orderId) return ord;
      const orderPayments = updatedPayments.filter(p => p.orderId === ord.id);
      const totalPaid = orderPayments.reduce((sum, p) => sum + p.amount, 0);
      const balanceDue = Math.max(0, ord.sellingPrice - totalPaid);
      return {
        ...ord,
        amountPaid: totalPaid,
        balanceDue,
        updatedAt: now
      };
    });
    setOrders(updatedOrders);

    syncStore(user.id, { payments: updatedPayments, orders: updatedOrders });
    showToast(`Payment of ${formatCurrency(newPayment.amount)} recorded!`, 'success');
    return newPayment;
  }, [user, payments, orders, syncStore, showToast, formatCurrency]);

  const deletePayment = useCallback((id: string) => {
    if (!user) return;
    const paymentToDelete = payments.find(p => p.id === id);
    if (!paymentToDelete) return;
    const updatedPayments = payments.filter(p => p.id !== id);
    setPayments(updatedPayments);

    // Recalculate target order balance
    const updatedOrders = orders.map(ord => {
      if (ord.id !== paymentToDelete.orderId) return ord;
      const remainingOrderPayments = updatedPayments.filter(p => p.orderId === ord.id);
      const totalPaid = remainingOrderPayments.reduce((sum, p) => sum + p.amount, 0);
      return {
        ...ord,
        amountPaid: totalPaid,
        balanceDue: Math.max(0, ord.sellingPrice - totalPaid),
        updatedAt: new Date().toISOString()
      };
    });
    setOrders(updatedOrders);

    syncStore(user.id, { payments: updatedPayments, orders: updatedOrders });
    showToast('Payment record removed.', 'info');
  }, [user, payments, orders, syncStore, showToast]);

  const getOrderPayments = useCallback((orderId: string) => {
    return payments.filter(p => p.orderId === orderId);
  }, [payments]);

  // Materials Actions
  const addMaterial = useCallback((matData: Omit<Material, 'id' | 'userId' | 'updatedAt'>): Material => {
    if (!user) throw new Error('Not authenticated');
    const newMaterial: Material = {
      ...matData,
      id: 'mat_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      userId: user.id,
      updatedAt: new Date().toISOString()
    };
    const updated = [newMaterial, ...materials];
    setMaterials(updated);
    syncStore(user.id, { materials: updated });
    showToast(`Material "${newMaterial.name}" added to inventory!`, 'success');
    return newMaterial;
  }, [user, materials, syncStore, showToast]);

  const updateMaterial = useCallback((id: string, updates: Partial<Material>) => {
    if (!user) return;
    const updated = materials.map(m => m.id === id ? { ...m, ...updates, updatedAt: new Date().toISOString() } : m);
    setMaterials(updated);
    syncStore(user.id, { materials: updated });
    showToast('Material stock updated.', 'success');
  }, [user, materials, syncStore, showToast]);

  const adjustMaterialQuantity = useCallback((id: string, delta: number) => {
    if (!user) return;
    const updated = materials.map(m => {
      if (m.id !== id) return m;
      const newQty = Math.max(0, m.quantity + delta);
      return { ...m, quantity: newQty, updatedAt: new Date().toISOString() };
    });
    setMaterials(updated);
    syncStore(user.id, { materials: updated });
  }, [user, materials, syncStore]);

  const deleteMaterial = useCallback((id: string) => {
    if (!user) return;
    const updated = materials.filter(m => m.id !== id);
    setMaterials(updated);
    syncStore(user.id, { materials: updated });
    showToast('Material deleted from inventory.', 'info');
  }, [user, materials, syncStore, showToast]);

  // Quotes Actions
  const addQuote = useCallback((quoteData: Omit<Quote, 'id' | 'userId' | 'createdAt'>): Quote => {
    if (!user) throw new Error('Not authenticated');
    const newQuote: Quote = {
      ...quoteData,
      id: 'qt_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      userId: user.id,
      createdAt: new Date().toISOString()
    };
    const updated = [newQuote, ...quotes];
    setQuotes(updated);
    syncStore(user.id, { quotes: updated });
    showToast(`Quote "${newQuote.title}" saved!`, 'success');
    return newQuote;
  }, [user, quotes, syncStore, showToast]);

  const deleteQuote = useCallback((id: string) => {
    if (!user) return;
    const updated = quotes.filter(q => q.id !== id);
    setQuotes(updated);
    syncStore(user.id, { quotes: updated });
    showToast('Quote removed.', 'info');
  }, [user, quotes, syncStore, showToast]);

  // Settings
  const updateProfile = useCallback((updates: Partial<UserProfile>) => {
    if (!user) return;
    const updated = { ...user, ...updates };
    setUser(updated);
    syncStore(user.id, { profile: updated });
    showToast('Business settings saved successfully!', 'success');
  }, [user, syncStore, showToast]);

  const value = useMemo<AppContextType>(() => ({
    user,
    isLoggedIn: !!user,
    isDemo: !!user?.isDemo,
    activeTab,
    setActiveTab,
    selectedCustomerId,
    setSelectedCustomerId,
    selectedOrderId,
    setSelectedOrderId,
    customers,
    measurements,
    orders,
    payments,
    materials,
    quotes,
    login,
    register,
    logout,
    enterDemoMode,
    resetDemoData,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    getCustomer,
    addMeasurementProfile,
    updateMeasurementProfile,
    duplicateMeasurementProfile,
    deleteMeasurementProfile,
    getMeasurementProfile,
    getCustomerMeasurements,
    addOrder,
    updateOrder,
    updateOrderStatus,
    deleteOrder,
    getOrder,
    getCustomerOrders,
    addPayment,
    deletePayment,
    getOrderPayments,
    addMaterial,
    updateMaterial,
    adjustMaterialQuantity,
    deleteMaterial,
    addQuote,
    deleteQuote,
    updateProfile,
    formatCurrency,
    toasts,
    showToast,
    removeToast,
    printOrder,
    setPrintOrder,
    globalSearch,
    setGlobalSearch
  }), [
    user,
    activeTab,
    selectedCustomerId,
    selectedOrderId,
    customers,
    measurements,
    orders,
    payments,
    materials,
    quotes,
    login,
    register,
    logout,
    enterDemoMode,
    resetDemoData,
    addCustomer,
    updateCustomer,
    deleteCustomer,
    getCustomer,
    addMeasurementProfile,
    updateMeasurementProfile,
    duplicateMeasurementProfile,
    deleteMeasurementProfile,
    getMeasurementProfile,
    getCustomerMeasurements,
    addOrder,
    updateOrder,
    updateOrderStatus,
    deleteOrder,
    getOrder,
    getCustomerOrders,
    addPayment,
    deletePayment,
    getOrderPayments,
    addMaterial,
    updateMaterial,
    adjustMaterialQuantity,
    deleteMaterial,
    addQuote,
    deleteQuote,
    updateProfile,
    formatCurrency,
    toasts,
    showToast,
    removeToast,
    printOrder,
    globalSearch
  ]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
