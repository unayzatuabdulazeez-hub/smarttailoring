import {
  Customer,
  MeasurementProfile,
  Order,
  Payment,
  Material,
  Quote,
  UserProfile,
  ProductionStatus
} from '../types';

export const DEMO_USER_ID = 'demo_tailor_user';

export const DEFAULT_DEMO_PROFILE: UserProfile = {
  id: DEMO_USER_ID,
  email: 'atelier@smarttailoring.africa',
  businessName: 'Zaria Bespoke & Couture',
  ownerName: 'Ibrahim & Fatima Al-Hassan',
  phone: '+234 803 555 0192',
  address: 'Plot 14, Victoria Island, Lagos & Kaduna Atelier',
  currency: '₦',
  defaultUnit: 'inches',
  isDemo: true,
  createdAt: '2026-01-15T09:00:00.000Z'
};

const DEMO_CUSTOMERS: Customer[] = [
  {
    id: 'cust-1',
    userId: DEMO_USER_ID,
    fullName: 'Aisha Mohammed',
    phoneNumber: '+234 803 234 5678',
    email: 'aisha.mohammed@example.com',
    address: '42 Crescent Avenue, Maitama, Abuja',
    gender: 'Female',
    dateOfBirth: '1992-06-14',
    notes: 'Prefers modest cuts, high necklines, and breathable natural cotton & silk.',
    createdAt: '2026-09-10T10:00:00.000Z'
  },
  {
    id: 'cust-2',
    userId: DEMO_USER_ID,
    fullName: 'Fatima Yusuf',
    phoneNumber: '+234 806 876 5432',
    email: 'fatima.yusuf@example.com',
    address: '15 Bompai Road, Nassarawa, Kano',
    gender: 'Female',
    dateOfBirth: '1988-11-20',
    notes: 'Regular VIP client for family wedding outfits. Loves emerald green and gold trimming.',
    createdAt: '2026-09-18T14:30:00.000Z'
  },
  {
    id: 'cust-3',
    userId: DEMO_USER_ID,
    fullName: 'Maryam Bello',
    phoneNumber: '+234 812 345 6789',
    email: 'maryam.bello@example.com',
    address: '28 Admiralty Way, Lekki Phase 1, Lagos',
    gender: 'Female',
    dateOfBirth: '1995-03-08',
    notes: 'Strict delivery deadlines. Request fittings at least 3 days before event.',
    createdAt: '2026-09-22T08:15:00.000Z'
  },
  {
    id: 'cust-4',
    userId: DEMO_USER_ID,
    fullName: 'Babangida Aliyu',
    phoneNumber: '+234 802 991 2233',
    email: 'b.aliyu@example.com',
    address: '8 Gana Street, Wuse 2, Abuja',
    gender: 'Male',
    dateOfBirth: '1984-07-29',
    notes: 'Prefers classic 3-piece Agbada and crisp tailored Kaftans with subtle geometric embroidery.',
    createdAt: '2026-09-25T11:45:00.000Z'
  }
];

const DEMO_MEASUREMENTS: MeasurementProfile[] = [
  {
    id: 'meas-1',
    customerId: 'cust-1',
    userId: DEMO_USER_ID,
    profileName: 'Kaftan — October 2026',
    unit: 'inches',
    measurements: {
      shoulder: 15.5,
      bust: 38,
      waist: 32,
      hip: 42,
      sleeveLength: 23,
      armhole: 17.5,
      bicep: 13,
      wrist: 7.5,
      blouseLength: 26,
      gownLength: 58,
      neck: 15
    },
    notes: 'Relaxed fit around hips. Include 2 inch internal seam allowance.',
    recordedAt: '2026-10-01T11:00:00.000Z',
    updatedAt: '2026-10-01T11:00:00.000Z'
  },
  {
    id: 'meas-2',
    customerId: 'cust-1',
    userId: DEMO_USER_ID,
    profileName: 'Gown — Fitted Evening',
    unit: 'inches',
    measurements: {
      shoulder: 15.5,
      bust: 37.5,
      waist: 31,
      hip: 41.5,
      gownLength: 60,
      armhole: 17,
      backLength: 16
    },
    notes: 'Fitted silhouette with mermaid drape.',
    recordedAt: '2026-09-12T15:00:00.000Z',
    updatedAt: '2026-09-12T15:00:00.000Z'
  },
  {
    id: 'meas-3',
    customerId: 'cust-2',
    userId: DEMO_USER_ID,
    profileName: 'Jalabiya — Wedding Special',
    unit: 'inches',
    measurements: {
      shoulder: 16,
      bust: 40,
      waist: 34,
      hip: 44,
      sleeveLength: 24,
      armhole: 18.5,
      gownLength: 61,
      neck: 16
    },
    notes: 'A-line flare with front slit lined with gold piping.',
    recordedAt: '2026-09-20T10:00:00.000Z',
    updatedAt: '2026-09-20T10:00:00.000Z'
  },
  {
    id: 'meas-4',
    customerId: 'cust-3',
    userId: DEMO_USER_ID,
    profileName: 'Abaya & Slip Dress Set',
    unit: 'inches',
    measurements: {
      shoulder: 15,
      bust: 36,
      waist: 30,
      hip: 40,
      sleeveLength: 23.5,
      armhole: 16.5,
      gownLength: 57,
      wrist: 7
    },
    notes: 'Wide bell sleeves with contrast velvet cuffs.',
    recordedAt: '2026-09-24T12:00:00.000Z',
    updatedAt: '2026-09-24T12:00:00.000Z'
  },
  {
    id: 'meas-5',
    customerId: 'cust-4',
    userId: DEMO_USER_ID,
    profileName: '3-Piece Agbada & Trouser',
    unit: 'inches',
    measurements: {
      shoulder: 19.5,
      chest: 44,
      waist: 36,
      trouserLength: 42,
      thigh: 26,
      knee: 18,
      ankle: 15,
      neck: 17,
      sleeveLength: 25.5
    },
    notes: 'Firm waistband with internal drawstring option.',
    recordedAt: '2026-09-26T16:00:00.000Z',
    updatedAt: '2026-09-26T16:00:00.000Z'
  }
];

const DEMO_ORDERS: Order[] = [
  {
    id: 'ord-1',
    userId: DEMO_USER_ID,
    orderNumber: 'ST-2026-0001',
    customerId: 'cust-1',
    outfitType: 'Kaftan',
    orderDescription: 'Royal Burgundy Damask Kaftan with hand-stitched gold bullion embroidery across the chest and cuffs.',
    measurementProfileId: 'meas-1',
    fabricType: 'Damask & Cashmere Blend',
    fabricColour: 'Deep Burgundy / Wine',
    fabricSuppliedByCustomer: true,
    fabricCost: 0,
    labourCost: 28000,
    additionalMaterialCost: 8500,
    otherCost: 3500,
    sellingPrice: 75000,
    amountPaid: 50000,
    totalCost: 40000,
    profit: 35000,
    balanceDue: 25000,
    deliveryDate: '2026-10-15',
    productionStatus: 'Cutting',
    notes: 'Customer called: add gold cord tassel at the collar.',
    createdAt: '2026-10-01T12:30:00.000Z',
    updatedAt: '2026-10-02T09:00:00.000Z'
  },
  {
    id: 'ord-2',
    userId: DEMO_USER_ID,
    orderNumber: 'ST-2026-0002',
    customerId: 'cust-2',
    outfitType: 'Jalabiya',
    orderDescription: 'Emerald green silk Jalabiya with gold braided trims and matching scarf for bridal dinner.',
    measurementProfileId: 'meas-3',
    fabricType: 'Silk Brocade',
    fabricColour: 'Emerald Green',
    fabricSuppliedByCustomer: false,
    fabricCost: 18000,
    labourCost: 15000,
    additionalMaterialCost: 4500,
    otherCost: 2500,
    sellingPrice: 60000,
    amountPaid: 60000,
    totalCost: 40000,
    profit: 20000,
    balanceDue: 0,
    deliveryDate: '2026-10-10',
    productionStatus: 'Fitting',
    notes: 'Paid in full upon fabric selection. Fitting scheduled Thursday 3pm.',
    createdAt: '2026-09-28T14:00:00.000Z',
    updatedAt: '2026-10-03T16:00:00.000Z'
  },
  {
    id: 'ord-3',
    userId: DEMO_USER_ID,
    orderNumber: 'ST-2026-0003',
    customerId: 'cust-3',
    outfitType: 'Abaya',
    orderDescription: 'Luxury pleated Abaya with Japanese Crepe inner slip and swarovski crystal embellishments on sleeve borders.',
    measurementProfileId: 'meas-4',
    fabricType: 'Nida Crepe & Chiffon',
    fabricColour: 'Midnight Navy & Gold',
    fabricSuppliedByCustomer: false,
    fabricCost: 26000,
    labourCost: 22000,
    additionalMaterialCost: 9000,
    otherCost: 3000,
    sellingPrice: 95000,
    amountPaid: 45000,
    totalCost: 60000,
    profit: 35000,
    balanceDue: 50000,
    deliveryDate: '2026-10-22',
    productionStatus: 'Sewing',
    notes: 'Ensure crystals are heat-pressed firmly.',
    createdAt: '2026-10-02T10:15:00.000Z',
    updatedAt: '2026-10-04T11:00:00.000Z'
  },
  {
    id: 'ord-4',
    userId: DEMO_USER_ID,
    orderNumber: 'ST-2026-0004',
    customerId: 'cust-4',
    outfitType: 'Native wear',
    orderDescription: 'Traditional 3-Piece Grand Agbada in Senator Guinea Brocade with heavy thread embroidery motif.',
    measurementProfileId: 'meas-5',
    fabricType: 'Swiss Guinea Brocade',
    fabricColour: 'Warm Ivory / Cream',
    fabricSuppliedByCustomer: true,
    fabricCost: 0,
    labourCost: 45000,
    additionalMaterialCost: 12000,
    otherCost: 5000,
    sellingPrice: 120000,
    amountPaid: 120000,
    totalCost: 62000,
    profit: 58000,
    balanceDue: 0,
    deliveryDate: '2026-10-04',
    productionStatus: 'Ready',
    notes: 'Completed ahead of time. Packaged in garment bag with hanger.',
    createdAt: '2026-09-24T09:00:00.000Z',
    updatedAt: '2026-10-04T15:30:00.000Z'
  }
];

const DEMO_PAYMENTS: Payment[] = [
  {
    id: 'pay-1',
    orderId: 'ord-1',
    customerId: 'cust-1',
    userId: DEMO_USER_ID,
    amount: 50000,
    paymentDate: '2026-10-01',
    paymentMethod: 'Bank Transfer',
    note: 'Initial 67% deposit for cutting & materials',
    createdAt: '2026-10-01T12:35:00.000Z'
  },
  {
    id: 'pay-2',
    orderId: 'ord-2',
    customerId: 'cust-2',
    userId: DEMO_USER_ID,
    amount: 40000,
    paymentDate: '2026-09-28',
    paymentMethod: 'POS',
    note: 'Deposit paid at boutique checkout',
    createdAt: '2026-09-28T14:10:00.000Z'
  },
  {
    id: 'pay-3',
    orderId: 'ord-2',
    customerId: 'cust-2',
    userId: DEMO_USER_ID,
    amount: 20000,
    paymentDate: '2026-10-03',
    paymentMethod: 'Bank Transfer',
    note: 'Final settlement payment before fitting',
    createdAt: '2026-10-03T16:05:00.000Z'
  },
  {
    id: 'pay-4',
    orderId: 'ord-3',
    customerId: 'cust-3',
    userId: DEMO_USER_ID,
    amount: 45000,
    paymentDate: '2026-10-02',
    paymentMethod: 'Bank Transfer',
    note: 'Fabric & commencement deposit',
    createdAt: '2026-10-02T10:30:00.000Z'
  },
  {
    id: 'pay-5',
    orderId: 'ord-4',
    customerId: 'cust-4',
    userId: DEMO_USER_ID,
    amount: 70000,
    paymentDate: '2026-09-24',
    paymentMethod: 'Bank Transfer',
    note: 'Initial deposit',
    createdAt: '2026-09-24T09:15:00.000Z'
  },
  {
    id: 'pay-6',
    orderId: 'ord-4',
    customerId: 'cust-4',
    userId: DEMO_USER_ID,
    amount: 50000,
    paymentDate: '2026-10-04',
    paymentMethod: 'Cash',
    note: 'Final payment received at ready pickup',
    createdAt: '2026-10-04T15:35:00.000Z'
  }
];

const DEMO_MATERIALS: Material[] = [
  {
    id: 'mat-1',
    userId: DEMO_USER_ID,
    name: 'Gold Bullion Metallic Embroidery Thread',
    category: 'Thread',
    quantity: 26,
    unit: 'spools',
    costPerUnit: 1400,
    lowStockThreshold: 10,
    notes: 'Premium German metallic thread for chest monogramming',
    updatedAt: '2026-10-01T10:00:00.000Z'
  },
  {
    id: 'mat-2',
    userId: DEMO_USER_ID,
    name: 'YKK Invisible Zippers (22 inch)',
    category: 'Zippers',
    quantity: 14,
    unit: 'pieces',
    costPerUnit: 650,
    lowStockThreshold: 15,
    notes: 'Used for women evening gowns and kaftan neck closures',
    updatedAt: '2026-10-02T11:00:00.000Z'
  },
  {
    id: 'mat-3',
    userId: DEMO_USER_ID,
    name: 'Fine Cotton Silk Lining Cloth (Burgundy)',
    category: 'Lining',
    quantity: 42,
    unit: 'yards',
    costPerUnit: 2200,
    lowStockThreshold: 20,
    notes: 'Breathable and sweat-absorbent lining fabric',
    updatedAt: '2026-09-28T16:00:00.000Z'
  },
  {
    id: 'mat-4',
    userId: DEMO_USER_ID,
    name: 'Swarovski Crystal & Glass Stone Pack',
    category: 'Stones',
    quantity: 6,
    unit: 'packets',
    costPerUnit: 4800,
    lowStockThreshold: 10,
    notes: 'Low stock! Re-order from supplier in Lagos Island.',
    updatedAt: '2026-10-03T09:30:00.000Z'
  },
  {
    id: 'mat-5',
    userId: DEMO_USER_ID,
    name: 'Heavy Woven Interfacing Canvas',
    category: 'Interfacing',
    quantity: 28,
    unit: 'yards',
    costPerUnit: 1600,
    lowStockThreshold: 12,
    notes: 'For collars, cuffs, and agbada neck plates',
    updatedAt: '2026-09-25T14:20:00.000Z'
  },
  {
    id: 'mat-6',
    userId: DEMO_USER_ID,
    name: 'Carved Horn Buttons (24L)',
    category: 'Buttons',
    quantity: 110,
    unit: 'pieces',
    costPerUnit: 150,
    lowStockThreshold: 50,
    notes: 'High-end suit and kaftan front placket buttons',
    updatedAt: '2026-10-04T12:00:00.000Z'
  }
];

const DEMO_QUOTES: Quote[] = [
  {
    id: 'qt-1',
    userId: DEMO_USER_ID,
    title: 'Executive 3-Piece Silk Brocade Kaftan',
    customerName: 'Amina Danjuma',
    outfitType: 'Three-piece',
    fabricCost: 35000,
    labourCost: 30000,
    materialsCost: 8000,
    transportCost: 3000,
    otherExpenses: 2000,
    profitPercentage: 40,
    totalCost: 78000,
    sellingPrice: 110000,
    expectedProfit: 32000,
    notes: 'Quoted for December coronation ceremony.',
    createdAt: '2026-10-03T11:00:00.000Z'
  }
];

interface UserDataStore {
  profile: UserProfile;
  customers: Customer[];
  measurements: MeasurementProfile[];
  orders: Order[];
  payments: Payment[];
  materials: Material[];
  quotes: Quote[];
}

export class StorageService {
  private static AUTH_KEY = 'smart_tailoring_auth_session';
  private static USERS_REGISTRY_KEY = 'smart_tailoring_registered_users';

  // Session & Auth
  static getCurrentSession(): { userId: string; isDemo: boolean } | null {
    try {
      const data = localStorage.getItem(this.AUTH_KEY);
      if (!data) return null;
      return JSON.parse(data);
    } catch {
      return null;
    }
  }

  static setCurrentSession(userId: string, isDemo: boolean): void {
    localStorage.setItem(this.AUTH_KEY, JSON.stringify({ userId, isDemo }));
  }

  static clearSession(): void {
    localStorage.removeItem(this.AUTH_KEY);
  }

  private static getStoreKey(userId: string): string {
    return `smart_tailoring_data_${userId}`;
  }

  // Get or initialize data for a user
  static getUserData(userId: string): UserDataStore {
    if (userId === DEMO_USER_ID) {
      // Check if demo data was customized in this browser session
      const storedDemo = localStorage.getItem(this.getStoreKey(DEMO_USER_ID));
      if (storedDemo) {
        try {
          return JSON.parse(storedDemo);
        } catch {
          // fallback to defaults
        }
      }
      const initialDemo: UserDataStore = {
        profile: DEFAULT_DEMO_PROFILE,
        customers: DEMO_CUSTOMERS,
        measurements: DEMO_MEASUREMENTS,
        orders: DEMO_ORDERS,
        payments: DEMO_PAYMENTS,
        materials: DEMO_MATERIALS,
        quotes: DEMO_QUOTES
      };
      localStorage.setItem(this.getStoreKey(DEMO_USER_ID), JSON.stringify(initialDemo));
      return initialDemo;
    }

    const raw = localStorage.getItem(this.getStoreKey(userId));
    if (raw) {
      try {
        return JSON.parse(raw);
      } catch {
        // empty store fallback
      }
    }

    // New real user starts completely clean
    const newStore: UserDataStore = {
      profile: {
        id: userId,
        email: '',
        businessName: 'My Tailoring Studio',
        ownerName: 'Master Tailor',
        phone: '',
        address: '',
        currency: '₦',
        defaultUnit: 'inches',
        isDemo: false,
        createdAt: new Date().toISOString()
      },
      customers: [],
      measurements: [],
      orders: [],
      payments: [],
      materials: [],
      quotes: []
    };
    localStorage.setItem(this.getStoreKey(userId), JSON.stringify(newStore));
    return newStore;
  }

  static saveUserData(userId: string, data: UserDataStore): void {
    localStorage.setItem(this.getStoreKey(userId), JSON.stringify(data));
  }

  // User Auth Registry
  static registerUser(params: {
    email: string;
    businessName: string;
    ownerName: string;
    phone?: string;
    currency?: string;
  }): UserProfile {
    const userId = 'usr_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    const profile: UserProfile = {
      id: userId,
      email: params.email.trim(),
      businessName: params.businessName.trim(),
      ownerName: params.ownerName.trim(),
      phone: params.phone?.trim() || '',
      address: '',
      currency: params.currency || '₦',
      defaultUnit: 'inches',
      isDemo: false,
      createdAt: new Date().toISOString()
    };

    const emptyStore: UserDataStore = {
      profile,
      customers: [],
      measurements: [],
      orders: [],
      payments: [],
      materials: [],
      quotes: []
    };

    this.saveUserData(userId, emptyStore);

    // Save in user directory for login lookup
    try {
      const usersRaw = localStorage.getItem(this.USERS_REGISTRY_KEY) || '[]';
      const users: { email: string; id: string; name: string }[] = JSON.parse(usersRaw);
      users.push({ email: profile.email.toLowerCase(), id: userId, name: profile.businessName });
      localStorage.setItem(this.USERS_REGISTRY_KEY, JSON.stringify(users));
    } catch {
      // ignore
    }

    this.setCurrentSession(userId, false);
    return profile;
  }

  static loginUser(email: string): UserProfile | null {
    const cleanEmail = email.trim().toLowerCase();
    if (cleanEmail === 'demo@smarttailoring.africa' || cleanEmail === 'demo') {
      this.setCurrentSession(DEMO_USER_ID, true);
      return this.getUserData(DEMO_USER_ID).profile;
    }

    try {
      const usersRaw = localStorage.getItem(this.USERS_REGISTRY_KEY) || '[]';
      const users: { email: string; id: string }[] = JSON.parse(usersRaw);
      const match = users.find(u => u.email === cleanEmail);
      if (match) {
        this.setCurrentSession(match.id, false);
        return this.getUserData(match.id).profile;
      }
    } catch {
      // ignore
    }

    return null;
  }

  static getRegisteredUsers(): { email: string; id: string; name: string }[] {
    try {
      const usersRaw = localStorage.getItem(this.USERS_REGISTRY_KEY) || '[]';
      return JSON.parse(usersRaw);
    } catch {
      return [];
    }
  }

  // Generate sequential Order number
  static generateNextOrderNumber(userId: string): string {
    const data = this.getUserData(userId);
    const count = data.orders.length + 1;
    const year = new Date().getFullYear();
    const formattedCount = String(count).padStart(4, '0');
    return `ST-${year}-${formattedCount}`;
  }

  // Reset Demo Data to initial state
  static resetDemoData(): void {
    const initialDemo: UserDataStore = {
      profile: DEFAULT_DEMO_PROFILE,
      customers: DEMO_CUSTOMERS,
      measurements: DEMO_MEASUREMENTS,
      orders: DEMO_ORDERS,
      payments: DEMO_PAYMENTS,
      materials: DEMO_MATERIALS,
      quotes: DEMO_QUOTES
    };
    localStorage.setItem(this.getStoreKey(DEMO_USER_ID), JSON.stringify(initialDemo));
  }
}
