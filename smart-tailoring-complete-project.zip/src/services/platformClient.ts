export interface TailorAccount {
  id: string;
  email: string;
  businessName: string;
  ownerName: string;
  phone: string;
  location?: string;
  currency: string;
  defaultUnit: string;
  status: 'pending' | 'approved' | 'rejected' | 'suspended';
  planTier: 'Standard' | 'Premium' | 'VIP';
  registeredAt: string;
  approvedAt?: string;
  notes?: string;
}

export interface PlatformSettings {
  ownerEmail: string;
  requireApproval: boolean;
  whatsappSupport: string;
  announcement: string;
}

export interface PublicOrderData {
  orderNumber: string;
  tailorId: string;
  tailorBusinessName: string;
  tailorOwnerName: string;
  tailorPhone: string;
  tailorCurrency: string;
  tailorAddress?: string;
  bankDetails?: string;
  customerName: string;
  customerPhone?: string;
  outfitType: string;
  customOutfitType?: string;
  fabricType?: string;
  fabricColour?: string;
  serviceTier: 'Standard' | 'Premium' | 'Royal_VIP';
  productionStatus: string;
  orderDescription?: string;
  deliveryDate: string;
  fittingAppointmentDate?: string;
  totalCost: number;
  amountPaid: number;
  balanceDue: number;
  updatedAt: string;
}

export const PlatformClient = {
  async getInfo(): Promise<PlatformSettings> {
    const res = await fetch('/api/platform/info');
    if (!res.ok) throw new Error('Failed to load platform info');
    return res.json();
  },

  async adminLogin(email: string, passkey: string): Promise<{ success: boolean; email: string }> {
    const res = await fetch('/api/platform/auth/admin-login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, passkey })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Admin verification failed');
    }
    return res.json();
  },

  async getAdminTailors(): Promise<{ tailors: TailorAccount[]; settings: PlatformSettings }> {
    const res = await fetch('/api/platform/admin/tailors');
    if (!res.ok) throw new Error('Failed to load tailors list');
    return res.json();
  },

  async updateTailorStatus(
    id: string,
    status: 'pending' | 'approved' | 'rejected' | 'suspended',
    planTier?: 'Standard' | 'Premium' | 'VIP'
  ): Promise<TailorAccount> {
    const res = await fetch(`/api/platform/admin/tailors/${id}/status`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, planTier })
    });
    if (!res.ok) throw new Error('Failed to update tailor status');
    const data = await res.json();
    return data.tailor;
  },

  async deleteTailor(id: string): Promise<boolean> {
    const res = await fetch(`/api/platform/admin/tailors/${id}`, {
      method: 'DELETE'
    });
    return res.ok;
  },

  async updatePlatformSettings(settings: Partial<PlatformSettings>): Promise<PlatformSettings> {
    const res = await fetch('/api/platform/admin/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    });
    if (!res.ok) throw new Error('Failed to update platform settings');
    const data = await res.json();
    return data.settings;
  },

  async registerTailor(data: {
    email: string;
    businessName: string;
    ownerName: string;
    phone: string;
    location?: string;
    currency?: string;
    defaultUnit?: string;
  }): Promise<{ tailor: TailorAccount; requiresApproval: boolean }> {
    const res = await fetch('/api/tailors/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Registration failed');
    }
    return res.json();
  },

  async loginTailor(email: string): Promise<{ tailor: TailorAccount; status: string }> {
    const res = await fetch('/api/tailors/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Tailor account not found');
    }
    return res.json();
  },

  async publishOrder(order: PublicOrderData): Promise<void> {
    const res = await fetch('/api/public/orders/publish', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(order)
    });
    if (!res.ok) throw new Error('Failed to publish order for client tracking');
  },

  async trackOrder(orderNumber: string): Promise<PublicOrderData> {
    const res = await fetch(`/api/public/orders/track/${encodeURIComponent(orderNumber.trim())}`);
    if (!res.ok) {
      throw new Error('Order not found. Please verify the order number.');
    }
    return res.json();
  }
};
