export type ProductionStatus = 
  | 'New'
  | 'Confirmed'
  | 'Cutting'
  | 'Sewing'
  | 'Fitting'
  | 'Ready'
  | 'Delivered'
  | 'Cancelled';

export type PaymentMethod = 'Cash' | 'Bank Transfer' | 'POS' | 'Other';

export type PaymentStatus = 'Paid' | 'Partial' | 'Unpaid';

export type MeasurementUnit = 'inches' | 'cm';

export type ServiceTier = 'Standard' | 'Premium' | 'Royal_VIP';

export interface UserProfile {
  id: string;
  email: string;
  businessName: string;
  ownerName: string;
  phone: string;
  address: string;
  currency: string; // e.g. "₦", "$", "£", "€"
  defaultUnit: MeasurementUnit;
  serviceMode?: 'Local' | 'Premium' | 'Hybrid';
  isDemo: boolean;
  createdAt: string;
}

export interface Customer {
  id: string;
  userId: string;
  fullName: string;
  phoneNumber: string;
  email: string;
  address: string;
  gender: 'Female' | 'Male' | 'Other';
  clientTier?: 'Regular' | 'VIP';
  preferredStarch?: 'No Starch' | 'Soft' | 'Medium' | 'Crisp / Hard';
  dateOfBirth?: string;
  notes?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface MeasurementData {
  shoulder?: number;
  bust?: number;
  waist?: number;
  hip?: number;
  sleeveLength?: number;
  armhole?: number;
  bicep?: number;
  wrist?: number;
  blouseLength?: number;
  gownLength?: number;
  trouserLength?: number;
  thigh?: number;
  knee?: number;
  ankle?: number;
  neck?: number;
  chest?: number;
  backLength?: number;
  [customField: string]: number | undefined;
}

export interface MeasurementProfile {
  id: string;
  customerId: string;
  userId: string;
  profileName: string; // e.g., "Kaftan — October 2026", "Jalabiya — Wedding"
  unit: MeasurementUnit;
  measurements: MeasurementData;
  notes?: string;
  recordedAt: string;
  updatedAt: string;
}

export interface Order {
  id: string;
  userId: string;
  orderNumber: string; // e.g., "ST-2026-0001"
  customerId: string;
  outfitType: string;
  customOutfitType?: string;
  orderDescription: string;
  measurementProfileId?: string;
  
  // Fabric details
  fabricType: string;
  fabricColour: string;
  fabricSuppliedByCustomer: boolean;
  fabricCost: number;
  
  // Costs
  labourCost: number;
  additionalMaterialCost: number;
  otherCost: number;
  
  // Pricing & Accounting
  sellingPrice: number;
  amountPaid: number;
  totalCost: number;
  profit: number;
  balanceDue: number;
  
  deliveryDate: string;
  productionStatus: ProductionStatus;
  serviceTier?: ServiceTier;
  isExpress?: boolean;
  fittingAppointmentDate?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Payment {
  id: string;
  orderId: string;
  customerId: string;
  userId: string;
  amount: number;
  paymentDate: string;
  paymentMethod: PaymentMethod;
  note?: string;
  createdAt: string;
}

export type MaterialCategory = 
  | 'Thread'
  | 'Buttons'
  | 'Zippers'
  | 'Lining'
  | 'Interfacing'
  | 'Beads'
  | 'Stones'
  | 'Hooks'
  | 'Needles'
  | 'Other';

export interface Material {
  id: string;
  userId: string;
  name: string;
  category: MaterialCategory;
  quantity: number;
  unit: string; // e.g., "yards", "pieces", "spools", "packets"
  costPerUnit: number;
  lowStockThreshold: number;
  notes?: string;
  updatedAt: string;
}

export interface Quote {
  id: string;
  userId: string;
  title: string;
  customerName?: string;
  outfitType?: string;
  fabricCost: number;
  labourCost: number;
  materialsCost: number;
  transportCost: number;
  otherExpenses: number;
  profitPercentage: number;
  totalCost: number;
  sellingPrice: number;
  expectedProfit: number;
  notes?: string;
  createdAt: string;
}

export type NavigationTab = 
  | 'dashboard'
  | 'customers'
  | 'measurements'
  | 'orders'
  | 'payments'
  | 'calculator'
  | 'materials'
  | 'reports'
  | 'settings';
