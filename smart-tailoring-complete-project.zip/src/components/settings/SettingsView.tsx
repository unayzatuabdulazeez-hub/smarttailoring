import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { MeasurementUnit } from '../../types';
import { ConfirmModal } from '../common/ConfirmModal';
import {
  Settings,
  Building2,
  User,
  Phone,
  Mail,
  MapPin,
  Lock,
  LogOut,
  Download,
  Upload,
  RotateCcw,
  CheckCircle2,
  Sparkles,
  Rocket
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const {
    user,
    updateProfile,
    logout,
    resetDemoData,
    showToast,
    isDemo
  } = useApp();

  const [businessName, setBusinessName] = useState(user?.businessName || '');
  const [ownerName, setOwnerName] = useState(user?.ownerName || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [email, setEmail] = useState(user?.email || '');
  const [address, setAddress] = useState(user?.address || '');
  const [currency, setCurrency] = useState(user?.currency || '₦');
  const [defaultUnit, setDefaultUnit] = useState<MeasurementUnit>(user?.defaultUnit || 'inches');

  // Password change simulation
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  useEffect(() => {
    if (user) {
      setBusinessName(user.businessName);
      setOwnerName(user.ownerName);
      setPhone(user.phone);
      setEmail(user.email);
      setAddress(user.address);
      setCurrency(user.currency);
      setDefaultUnit(user.defaultUnit);
    }
  }, [user]);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      businessName: businessName.trim(),
      ownerName: ownerName.trim(),
      phone: phone.trim(),
      email: email.trim(),
      address: address.trim(),
      currency,
      defaultUnit
    });
  };

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      showToast('Password must be at least 6 characters.', 'error');
      return;
    }
    if (newPassword !== confirmPassword) {
      showToast('Passwords do not match.', 'error');
      return;
    }
    setNewPassword('');
    setConfirmPassword('');
    showToast('Account password updated successfully!', 'success');
  };

  const handleExportData = () => {
    if (!user) return;
    const storeKey = `smart_tailoring_data_${user.id}`;
    const raw = localStorage.getItem(storeKey) || '{}';
    const blob = new Blob([raw], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `smart_tailoring_backup_${user.businessName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Studio data backup downloaded.', 'success');
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold font-serif-display text-stone-900 tracking-tight">
          Atelier Settings & Preferences
        </h1>
        <p className="text-xs text-stone-500 mt-0.5">
          Configure studio branding, default measurement units, invoice details, and account security
        </p>
      </div>

      {/* Demo Mode Go Live Callout */}
      {isDemo && (
        <div className="p-4 bg-gradient-to-r from-amber-50 to-amber-100/70 border border-amber-300 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-200 text-amber-900 flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5 text-amber-700" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-stone-900">You are in Demo Mode</h4>
              <p className="text-xs text-stone-600">
                You are currently viewing sample demo data. Ready to create your real atelier account?
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={logout}
            className="px-4 py-2 bg-[#58111A] hover:bg-[#4A0E17] text-white text-xs font-bold rounded-xl shadow-xs transition-colors shrink-0 cursor-pointer flex items-center gap-1.5"
          >
            <Rocket className="w-3.5 h-3.5 text-amber-200" />
            <span>Go Live / Create My Atelier</span>
          </button>
        </div>
      )}

      {/* Business Profile Form */}
      <form onSubmit={handleSaveProfile} className="bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-5">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-[#58111A]" />
            <h3 className="font-serif-display font-bold text-base text-stone-900">
              Business Profile & Invoice Details
            </h3>
          </div>
          <span className="text-[11px] text-stone-400">Appears on printed client receipts</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
              Business / Atelier Name *
            </label>
            <input
              type="text"
              required
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
              Owner / Master Tailor Name *
            </label>
            <input
              type="text"
              required
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
              Studio Phone Number
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
              Business Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
              Workshop / Boutique Physical Address
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="e.g. Plot 14, Victoria Island, Lagos"
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
              Currency Symbol
            </label>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            >
              <option value="₦">₦ - Nigerian Naira (NGN)</option>
              <option value="$">$ - US Dollar (USD)</option>
              <option value="£">£ - British Pound (GBP)</option>
              <option value="€">€ - Euro (EUR)</option>
              <option value="GH₵">GH₵ - Ghanaian Cedi (GHS)</option>
              <option value="KSh">KSh - Kenyan Shilling (KES)</option>
              <option value="CFA">CFA - West African Franc</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
              Default Measurement Unit
            </label>
            <select
              value={defaultUnit}
              onChange={(e) => setDefaultUnit(e.target.value as MeasurementUnit)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            >
              <option value="inches">Inches (traditional)</option>
              <option value="cm">Centimeters (metric)</option>
            </select>
          </div>
        </div>

        <div className="pt-3 flex justify-end">
          <button
            type="submit"
            className="px-6 py-2.5 bg-[#58111A] hover:bg-[#4A0E17] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            Save Business Profile
          </button>
        </div>
      </form>

      {/* Security & Account Form */}
      <form onSubmit={handlePasswordChange} className="bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 border-b border-stone-100 pb-3">
          <Lock className="w-5 h-5 text-stone-700" />
          <h3 className="font-serif-display font-bold text-base text-stone-900">
            Account & Security
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
              New Password
            </label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
              Confirm Password
            </label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            type="submit"
            className="px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Update Password
          </button>
        </div>
      </form>

      {/* Data Management & Session */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <h3 className="font-serif-display font-bold text-base text-stone-900 border-b border-stone-100 pb-3">
          Data Management & Logout
        </h3>

        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs font-semibold text-stone-800">Export Business Backup</p>
            <p className="text-[11px] text-stone-500">Download a full JSON copy of all your customers, measurements, and orders.</p>
          </div>
          <button
            onClick={handleExportData}
            className="inline-flex items-center gap-2 px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Backup (.JSON)</span>
          </button>
        </div>

        {isDemo && (
          <div className="pt-3 border-t border-stone-100 flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-xs font-semibold text-amber-900">Reset Demo Data</p>
              <p className="text-[11px] text-stone-500">Restores Aisha, Fatima, Maryam, and demo inventory to initial state.</p>
            </div>
            <button
              onClick={() => setShowResetConfirm(true)}
              className="inline-flex items-center gap-2 px-4 py-2 bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Demo Atelier</span>
            </button>
          </div>
        )}

        <div className="pt-3 border-t border-stone-100 flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs font-semibold text-stone-800">Sign Out</p>
            <p className="text-[11px] text-stone-500">End active session on this device.</p>
          </div>
          <button
            onClick={() => setShowLogoutConfirm(true)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Log Out</span>
          </button>
        </div>
      </div>

      {/* Powered by Unaabs Smart Business credit */}
      <div className="py-4 text-center">
        <p className="text-xs font-semibold text-stone-500">
          Smart Tailoring · <span className="text-[#58111A]">Powered by Unaabs Smart Business</span>
        </p>
        <p className="text-[10px] text-stone-400 mt-0.5">
          Enterprise Bespoke Fashion & Atelier Management System
        </p>
      </div>

      {/* Logout confirmation */}
      <ConfirmModal
        isOpen={showLogoutConfirm}
        title="Log out from Smart Tailoring?"
        message="You can log back in anytime using your registered atelier email."
        confirmLabel="Log Out"
        onConfirm={() => {
          setShowLogoutConfirm(false);
          logout();
        }}
        onCancel={() => setShowLogoutConfirm(false)}
      />

      {/* Reset Demo confirmation */}
      <ConfirmModal
        isOpen={showResetConfirm}
        title="Reset Demo Data?"
        message="This will reload the initial sample Nigerian atelier dataset with Aisha Mohammed, Fatima Yusuf, and Maryam Bello."
        confirmLabel="Reset Data"
        onConfirm={() => {
          setShowResetConfirm(false);
          resetDemoData();
        }}
        onCancel={() => setShowResetConfirm(false)}
      />
    </div>
  );
};
