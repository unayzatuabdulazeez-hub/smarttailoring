import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { PaymentMethod } from '../../types';
import { EmptyState } from '../common/EmptyState';
import {
  CreditCard,
  Search,
  DollarSign,
  Calendar,
  User,
  ShoppingBag,
  TrendingUp,
  AlertCircle,
  Filter,
  CheckCircle2,
  Trash2
} from 'lucide-react';
import { ConfirmModal } from '../common/ConfirmModal';

interface PaymentsViewProps {
  onOpenOrder: (orderId: string) => void;
  onOpenCustomer: (customerId: string) => void;
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({ onOpenOrder, onOpenCustomer }) => {
  const {
    payments,
    orders,
    customers,
    formatCurrency,
    deletePayment,
    globalSearch
  } = useApp();

  const [search, setSearch] = useState('');
  const [methodFilter, setMethodFilter] = useState<string>('all');
  const [paymentToDelete, setPaymentToDelete] = useState<string | null>(null);

  // Lookup maps
  const customerMap = useMemo(() => {
    const map = new Map<string, string>();
    customers.forEach(c => map.set(c.id, c.fullName));
    return map;
  }, [customers]);

  const orderMap = useMemo(() => {
    const map = new Map<string, { orderNumber: string; outfitType: string; sellingPrice: number }>();
    orders.forEach(o => map.set(o.id, { orderNumber: o.orderNumber, outfitType: o.outfitType, sellingPrice: o.sellingPrice }));
    return map;
  }, [orders]);

  // Aggregate stats
  const totalInvoiced = orders.reduce((sum, o) => sum + o.sellingPrice, 0);
  const totalCollected = payments.reduce((sum, p) => sum + p.amount, 0);
  const totalOutstanding = orders.reduce((sum, o) => sum + o.balanceDue, 0);

  const activeSearch = globalSearch || search;

  const filteredPayments = useMemo(() => {
    return payments.filter(p => {
      const custName = customerMap.get(p.customerId) || '';
      const orderInfo = orderMap.get(p.orderId);
      const orderNum = orderInfo?.orderNumber || '';

      const matchesSearch =
        !activeSearch ||
        custName.toLowerCase().includes(activeSearch.toLowerCase()) ||
        orderNum.toLowerCase().includes(activeSearch.toLowerCase()) ||
        p.paymentMethod.toLowerCase().includes(activeSearch.toLowerCase()) ||
        (p.note && p.note.toLowerCase().includes(activeSearch.toLowerCase()));

      if (!matchesSearch) return false;

      if (methodFilter !== 'all' && p.paymentMethod !== methodFilter) {
        return false;
      }

      return true;
    }).sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());
  }, [payments, activeSearch, methodFilter, customerMap, orderMap]);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div>
        <h1 className="text-2xl font-bold font-serif-display text-stone-900 tracking-tight">
          Payment Ledger & Accounts
        </h1>
        <p className="text-xs text-stone-500 mt-0.5">
          Record client installments, monitor cashflow, and reconcile outstanding balances
        </p>
      </div>

      {/* Aggregate Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
          <span className="text-xs uppercase font-bold text-stone-400 tracking-wider block">
            Total Revenue Collected
          </span>
          <p className="text-2xl font-bold font-mono text-emerald-700 mt-1">
            {formatCurrency(totalCollected)}
          </p>
          <span className="text-[11px] text-stone-400 mt-1 block">From {payments.length} verified transactions</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
          <span className="text-xs uppercase font-bold text-stone-400 tracking-wider block">
            Outstanding Balances
          </span>
          <p className="text-2xl font-bold font-mono text-[#58111A] mt-1">
            {formatCurrency(totalOutstanding)}
          </p>
          <span className="text-[11px] text-stone-400 mt-1 block">To be collected upon fitting & delivery</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
          <span className="text-xs uppercase font-bold text-stone-400 tracking-wider block">
            Total Order Value
          </span>
          <p className="text-2xl font-bold font-mono text-stone-900 mt-1">
            {formatCurrency(totalInvoiced)}
          </p>
          <span className="text-[11px] text-stone-400 mt-1 block">Across {orders.length} bespoke clothing orders</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-8 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by client, order #, bank reference, or payment note..."
              className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>

          <div className="sm:col-span-4">
            <select
              value={methodFilter}
              onChange={(e) => setMethodFilter(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            >
              <option value="all">All Payment Methods</option>
              <option value="Bank Transfer">Bank Transfer</option>
              <option value="Cash">Cash</option>
              <option value="POS">POS / Card</option>
              <option value="Other">Other</option>
            </select>
          </div>
        </div>
      </div>

      {/* Payments Table / List */}
      {filteredPayments.length === 0 ? (
        <EmptyState
          icon={CreditCard}
          title="No payment records found"
          description="Payments recorded when creating orders or accepting installments will appear here in your master studio ledger."
        />
      ) : (
        <div className="bg-white rounded-2xl border border-stone-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 text-stone-500 font-semibold border-b border-stone-200">
                <tr>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Client</th>
                  <th className="py-3 px-4">Order Ref</th>
                  <th className="py-3 px-4">Method</th>
                  <th className="py-3 px-4">Note / Reference</th>
                  <th className="py-3 px-4 text-right">Amount</th>
                  <th className="py-3 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 text-stone-700">
                {filteredPayments.map((p) => {
                  const clientName = customerMap.get(p.customerId) || 'Walk-in Client';
                  const orderInfo = orderMap.get(p.orderId);

                  return (
                    <tr key={p.id} className="hover:bg-stone-50/70 transition-colors">
                      <td className="py-3 px-4 font-mono whitespace-nowrap text-stone-600">
                        {p.paymentDate}
                      </td>

                      <td className="py-3 px-4 font-medium text-stone-900">
                        <button
                          onClick={() => onOpenCustomer(p.customerId)}
                          className="hover:text-[#58111A] hover:underline cursor-pointer"
                        >
                          {clientName}
                        </button>
                      </td>

                      <td className="py-3 px-4 font-mono font-medium text-[#58111A]">
                        {orderInfo ? (
                          <button
                            onClick={() => onOpenOrder(p.orderId)}
                            className="hover:underline cursor-pointer"
                          >
                            {orderInfo.orderNumber} ({orderInfo.outfitType})
                          </button>
                        ) : (
                          '--'
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded bg-stone-100 text-stone-700 font-medium">
                          {p.paymentMethod}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-stone-500 max-w-xs truncate">
                        {p.note || '--'}
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-bold text-emerald-800 text-sm whitespace-nowrap">
                        {formatCurrency(p.amount)}
                      </td>

                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => setPaymentToDelete(p.id)}
                          className="p-1 text-stone-300 hover:text-rose-600 rounded transition-colors"
                          title="Delete entry"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmModal
        isOpen={!!paymentToDelete}
        title="Delete Payment Entry?"
        message="Are you sure you want to delete this payment transaction? The corresponding order's balance due will increase accordingly."
        confirmLabel="Delete Payment"
        onConfirm={() => {
          if (paymentToDelete) {
            deletePayment(paymentToDelete);
            setPaymentToDelete(null);
          }
        }}
        onCancel={() => setPaymentToDelete(null)}
      />
    </div>
  );
};
