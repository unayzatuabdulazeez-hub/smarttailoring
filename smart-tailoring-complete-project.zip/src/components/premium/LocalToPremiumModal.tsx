import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Crown,
  Sparkles,
  Scissors,
  CheckCircle2,
  TrendingUp,
  Award,
  Layers,
  ShoppingBag,
  Clock,
  ShieldCheck,
  X,
  ArrowRight,
  Star
} from 'lucide-react';

interface LocalToPremiumModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyTier?: (tier: 'Standard' | 'Premium' | 'Royal_VIP') => void;
}

export const LocalToPremiumModal: React.FC<LocalToPremiumModalProps> = ({
  isOpen,
  onClose,
  onApplyTier
}) => {
  const { user, updateProfile, showToast } = useApp();
  const [selectedMode, setSelectedMode] = useState<'Local' | 'Premium' | 'Hybrid'>(
    user?.serviceMode || 'Hybrid'
  );

  if (!isOpen) return null;

  const handleSaveServiceMode = () => {
    updateProfile({ serviceMode: selectedMode });
    showToast(
      `Service mode set to ${
        selectedMode === 'Hybrid'
          ? 'Hybrid (Local + Premium)'
          : selectedMode === 'Premium'
          ? 'Premium Atelier'
          : 'Local Tailor'
      }!`,
      'success'
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden border border-stone-200 flex flex-col max-h-[90vh]">
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-[#58111A] via-[#6d1722] to-[#3a0b11] text-white p-6 relative">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-400/20 text-amber-300 border border-amber-300/30 flex items-center justify-center shadow-inner">
              <Crown className="w-6 h-6 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold tracking-widest uppercase bg-amber-400/20 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-300/30">
                  Unaabs Master Tailoring
                </span>
              </div>
              <h3 className="font-serif-display font-bold text-2xl leading-tight mt-1">
                Local Tailor to Premium Service Hub
              </h3>
              <p className="text-xs text-amber-100/80 mt-0.5">
                Empowering neighborhood tailors to deliver luxury couture and double their profit margins.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-stone-300 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Atelier Mode Selection */}
          <div>
            <label className="block text-xs font-bold text-stone-500 uppercase tracking-wider mb-2.5">
              Select Your Atelier Operating Mode:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Option 1: Local */}
              <div
                onClick={() => setSelectedMode('Local')}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  selectedMode === 'Local'
                    ? 'border-[#58111A] bg-stone-50/90 shadow-xs'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="w-8 h-8 rounded-xl bg-stone-200 text-stone-800 flex items-center justify-center">
                    <Scissors className="w-4 h-4" />
                  </div>
                  <input
                    type="radio"
                    checked={selectedMode === 'Local'}
                    onChange={() => setSelectedMode('Local')}
                    className="accent-[#58111A]"
                  />
                </div>
                <h4 className="font-bold text-sm text-stone-900">Local Workshop</h4>
                <p className="text-[11px] text-stone-500 mt-1 leading-relaxed">
                  Fast everyday sewing, simple cash/transfer logs, alterations, and standard Kaftans.
                </p>
              </div>

              {/* Option 2: Hybrid (Recommended) */}
              <div
                onClick={() => setSelectedMode('Hybrid')}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all relative ${
                  selectedMode === 'Hybrid'
                    ? 'border-amber-500 bg-amber-50/50 shadow-md ring-2 ring-amber-400/20'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <span className="absolute -top-2.5 right-3 bg-amber-500 text-stone-950 text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full tracking-wider shadow-2xs">
                  Most Popular
                </span>
                <div className="flex items-center justify-between mb-2">
                  <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center">
                    <Star className="w-4 h-4 text-amber-700" />
                  </div>
                  <input
                    type="radio"
                    checked={selectedMode === 'Hybrid'}
                    onChange={() => setSelectedMode('Hybrid')}
                    className="accent-amber-600"
                  />
                </div>
                <h4 className="font-bold text-sm text-stone-900">Hybrid Atelier</h4>
                <p className="text-[11px] text-stone-600 mt-1 leading-relaxed">
                  Serve both local neighborhood walk-ins AND high-paying VIP clients with tiered pricing.
                </p>
              </div>

              {/* Option 3: Premium Haute */}
              <div
                onClick={() => setSelectedMode('Premium')}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                  selectedMode === 'Premium'
                    ? 'border-[#58111A] bg-[#58111A]/5 shadow-xs'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-900 flex items-center justify-center">
                    <Crown className="w-4 h-4 text-purple-700" />
                  </div>
                  <input
                    type="radio"
                    checked={selectedMode === 'Premium'}
                    onChange={() => setSelectedMode('Premium')}
                    className="accent-[#58111A]"
                  />
                </div>
                <h4 className="font-bold text-sm text-stone-900">Premium Couture</h4>
                <p className="text-[11px] text-stone-500 mt-1 leading-relaxed">
                  Exclusive luxury brocades, VIP fitting stages, branded garment bags, and maximum margins.
                </p>
              </div>
            </div>
          </div>

          {/* 3 Tier Breakdown Table */}
          <div className="border border-stone-200 rounded-2xl overflow-hidden bg-stone-50/50">
            <div className="p-3 bg-stone-100/80 border-b border-stone-200">
              <span className="text-xs font-bold text-stone-800 uppercase tracking-wider">
                How Service Tiers Transform Local Tailoring
              </span>
            </div>

            <div className="divide-y divide-stone-200 text-xs">
              <div className="p-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="font-semibold text-stone-900 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-stone-400" />
                  <span>1. Standard Local Tier</span>
                </div>
                <div className="sm:col-span-2 text-stone-600 space-y-1">
                  <p>Standard stitching with polyester thread, regular interfacing, simple folding.</p>
                  <p className="text-[11px] text-stone-500 font-mono">Suggested Price: ₦7,000 – ₦15,000 / outfit</p>
                </div>
              </div>

              <div className="p-4 grid grid-cols-1 sm:grid-cols-3 gap-3 bg-amber-50/30">
                <div className="font-bold text-amber-900 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <span>2. Unaabs Premium Tier</span>
                </div>
                <div className="sm:col-span-2 text-stone-700 space-y-1">
                  <p>
                    French seams, German canvas woven interfacing, custom buttons, scheduled basting fitting session, and starch finishing.
                  </p>
                  <p className="text-[11px] text-amber-800 font-mono font-semibold">Suggested Price: ₦18,000 – ₦35,000 / outfit (+100% margin)</p>
                </div>
              </div>

              <div className="p-4 grid grid-cols-1 sm:grid-cols-3 gap-3 bg-purple-50/20">
                <div className="font-bold text-purple-950 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-purple-600" />
                  <span>3. Royal VIP Bespoke</span>
                </div>
                <div className="sm:col-span-2 text-stone-700 space-y-1">
                  <p>
                    Full hand-finishing, custom computerized embroidery, 2 fitting consultations, wooden hanger, luxury zippered garment suit bag, express 48hr turnaround.
                  </p>
                  <p className="text-[11px] text-purple-900 font-mono font-semibold">Suggested Price: ₦45,000 – ₦120,000+ / outfit</p>
                </div>
              </div>
            </div>
          </div>

          {/* 4 Practical Rules for Local Tailors to Level Up */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-stone-400 uppercase tracking-wider">
              5 Steps for Local Tailors to Offer Premium Service Today:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-white border border-stone-200 rounded-xl flex items-start gap-2.5 shadow-2xs">
                <ShoppingBag className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-stone-900 font-semibold">Ditch Black Nylon Bags</strong>
                  <p className="text-[11px] text-stone-500 mt-0.5">
                    Package finished Kaftans and Abayas in clear zippered garment bags with your atelier card. Clients happily pay double for professional presentation.
                  </p>
                </div>
              </div>

              <div className="p-3 bg-white border border-stone-200 rounded-xl flex items-start gap-2.5 shadow-2xs">
                <Clock className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-stone-900 font-semibold">Fitting Date Guarantee</strong>
                  <p className="text-[11px] text-stone-500 mt-0.5">
                    Set a formal 15-minute fitting appointment 3 days before final delivery to eliminate last-minute adjustments.
                  </p>
                </div>
              </div>

              <div className="p-3 bg-white border border-stone-200 rounded-xl flex items-start gap-2.5 shadow-2xs">
                <Sparkles className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-stone-900 font-semibold">Starch Level Preference</strong>
                  <p className="text-[11px] text-stone-500 mt-0.5">
                    Record each client's starch preference (Soft, Medium, Crisp Hard). Delivering properly pressed garments builds unbeatable customer loyalty.
                  </p>
                </div>
              </div>

              <div className="p-3 bg-white border border-stone-200 rounded-xl flex items-start gap-2.5 shadow-2xs">
                <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block text-stone-900 font-semibold">Digital Printable Receipts</strong>
                  <p className="text-[11px] text-stone-500 mt-0.5">
                    Provide clear itemized bills with deposit balance receipts instead of scraps of notebook paper.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2.5 bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Cancel
          </button>

          <button
            onClick={handleSaveServiceMode}
            className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#58111A] hover:bg-[#4A0E17] text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <span>Save Atelier Mode</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
