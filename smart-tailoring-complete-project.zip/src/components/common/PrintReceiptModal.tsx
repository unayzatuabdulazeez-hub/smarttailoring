import React from 'react';
import { useApp } from '../../context/AppContext';
import { Printer, X, Scissors, Check, Calendar, Phone, Mail, MapPin } from 'lucide-react';
import { ProductionStatusBadge, PaymentStatusBadge } from './StatusBadge';

export const PrintReceiptModal: React.FC = () => {
  const { printOrder, setPrintOrder, user, getCustomer, getMeasurementProfile, formatCurrency, getOrderPayments } = useApp();

  if (!printOrder) return null;

  const customer = getCustomer(printOrder.customerId);
  const measurement = printOrder.measurementProfileId ? getMeasurementProfile(printOrder.measurementProfileId) : undefined;
  const payments = getOrderPayments(printOrder.id);
  const paymentStatus = printOrder.balanceDue <= 0 ? 'Paid' : printOrder.amountPaid > 0 ? 'Partial' : 'Unpaid';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      {/* Container */}
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden border border-stone-200 print:shadow-none print:border-none print:w-full print:max-w-full">
        {/* Modal Controls Bar (Hidden during print) */}
        <div className="no-print bg-stone-900 text-white px-6 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-medium">
            <Printer className="w-4 h-4 text-amber-400" />
            <span>Print Preview: {printOrder.orderNumber}</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-[#C5A059] hover:bg-[#b08d48] text-stone-900 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              Print Receipt
            </button>
            <button
              onClick={() => setPrintOrder(null)}
              className="text-stone-300 hover:text-white p-1 rounded-md transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="p-8 md:p-10 font-sans text-stone-800 bg-[#FCFBF8] print:bg-white print:p-6" id="printable-receipt">
          {/* Header */}
          <div className="border-b-2 border-[#58111A] pb-6 flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-[#58111A] text-amber-300 flex items-center justify-center">
                  <Scissors className="w-4 h-4" />
                </div>
                <h1 className="text-2xl font-bold tracking-tight text-[#58111A] font-serif-display">
                  {user?.businessName || 'Smart Tailoring Atelier'}
                </h1>
              </div>
              <p className="text-xs text-stone-500 mt-1 uppercase tracking-wider font-semibold">
                Bespoke Tailoring & Couture Invoice
              </p>
              
              <div className="mt-3 space-y-0.5 text-xs text-stone-600">
                {user?.ownerName && <p className="font-medium text-stone-800">Proprietor: {user.ownerName}</p>}
                {user?.phone && (
                  <p className="flex items-center gap-1.5">
                    <Phone className="w-3 h-3 text-stone-400" />
                    {user.phone}
                  </p>
                )}
                {user?.email && (
                  <p className="flex items-center gap-1.5">
                    <Mail className="w-3 h-3 text-stone-400" />
                    {user.email}
                  </p>
                )}
                {user?.address && (
                  <p className="flex items-center gap-1.5">
                    <MapPin className="w-3 h-3 text-stone-400" />
                    {user.address}
                  </p>
                )}
              </div>
            </div>

            <div className="text-right">
              <span className="text-xs uppercase tracking-widest text-stone-400 font-bold">Order Number</span>
              <p className="text-xl font-mono font-bold text-stone-900">{printOrder.orderNumber}</p>
              <div className="mt-2 space-y-1 text-xs text-stone-500">
                <p>Order Date: <span className="font-medium text-stone-700">{new Date(printOrder.createdAt).toLocaleDateString()}</span></p>
                <p className="flex items-center justify-end gap-1 font-semibold text-emerald-800">
                  <Calendar className="w-3 h-3" />
                  Target Delivery: {new Date(printOrder.deliveryDate).toLocaleDateString()}
                </p>
                {printOrder.fittingAppointmentDate && (
                  <p className="flex items-center justify-end gap-1 font-semibold text-amber-900">
                    <Calendar className="w-3 h-3 text-amber-600" />
                    Scheduled Fitting: {new Date(printOrder.fittingAppointmentDate).toLocaleDateString()}
                  </p>
                )}
              </div>
              <div className="mt-2.5 flex items-center justify-end gap-1.5 flex-wrap">
                {printOrder.serviceTier === 'Royal_VIP' ? (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-900 border border-purple-300">
                    💎 Royal VIP Bespoke
                  </span>
                ) : printOrder.serviceTier === 'Premium' ? (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                    👑 Unaabs Premium
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-stone-100 text-stone-700 border border-stone-200">
                    🌟 Standard Local
                  </span>
                )}
                <ProductionStatusBadge status={printOrder.productionStatus} size="sm" />
                <PaymentStatusBadge status={paymentStatus} size="sm" />
              </div>
            </div>
          </div>

          {/* Customer & Outfit Grid */}
          <div className="grid grid-cols-2 gap-6 my-6 text-sm">
            <div className="p-4 bg-white rounded-xl border border-stone-200">
              <h4 className="text-xs uppercase font-bold text-stone-400 tracking-wider mb-2">Customer Details</h4>
              <p className="font-bold text-base text-stone-900">{customer?.fullName || 'Walk-in Client'}</p>
              <p className="text-xs text-stone-600 mt-0.5">{customer?.phoneNumber || 'No phone recorded'}</p>
              {customer?.email && <p className="text-xs text-stone-500">{customer.email}</p>}
              {customer?.address && <p className="text-xs text-stone-500 mt-1">{customer.address}</p>}
            </div>

            <div className="p-4 bg-white rounded-xl border border-stone-200">
              <h4 className="text-xs uppercase font-bold text-stone-400 tracking-wider mb-2">Garment & Fabric Details</h4>
              <p className="font-bold text-base text-[#58111A]">
                {printOrder.outfitType === 'Custom' ? (printOrder.customOutfitType || 'Custom Outfit') : printOrder.outfitType}
              </p>
              <p className="text-xs text-stone-700 mt-1">
                <span className="font-medium">Fabric:</span> {printOrder.fabricType || 'Bespoke fabric'} ({printOrder.fabricColour || 'Standard'})
              </p>
              <p className="text-xs text-stone-600 mt-0.5">
                Fabric Source: {printOrder.fabricSuppliedByCustomer ? 'Provided by Customer' : 'Sourced by Atelier'}
              </p>
              {printOrder.orderDescription && (
                <p className="text-xs text-stone-500 italic mt-2 line-clamp-2 border-t border-stone-100 pt-1.5">
                  "{printOrder.orderDescription}"
                </p>
              )}
            </div>
          </div>

          {/* Measurements Summary (if linked) */}
          {measurement && (
            <div className="mb-6 p-4 bg-white rounded-xl border border-stone-200">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs uppercase font-bold text-stone-400 tracking-wider">
                  Measurements Profile: {measurement.profileName}
                </h4>
                <span className="text-[11px] text-stone-500 font-medium">Unit: {measurement.unit}</span>
              </div>
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 text-xs">
                {Object.entries(measurement.measurements)
                  .filter(([_, val]) => typeof val === 'number' && val > 0)
                  .map(([key, val]) => (
                    <div key={key} className="bg-stone-50 p-1.5 rounded border border-stone-100 text-center">
                      <span className="block text-[10px] text-stone-500 capitalize truncate">
                        {key.replace(/([A-Z])/g, ' $1')}
                      </span>
                      <span className="font-bold text-stone-800 font-mono">{val}</span>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* Financial Calculation Table */}
          <div className="mb-6">
            <h4 className="text-xs uppercase font-bold text-stone-400 tracking-wider mb-2">Financial Breakdown</h4>
            <div className="bg-white rounded-xl border border-stone-200 overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-stone-50 text-stone-500 text-xs border-b border-stone-200">
                    <th className="py-2 px-4 text-left font-medium">Description</th>
                    <th className="py-2 px-4 text-right font-medium">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 text-stone-700">
                  <tr>
                    <td className="py-2.5 px-4 font-medium">
                      Bespoke Tailoring: {printOrder.outfitType === 'Custom' ? printOrder.customOutfitType : printOrder.outfitType}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono font-medium">{formatCurrency(printOrder.sellingPrice)}</td>
                  </tr>
                </tbody>
                <tfoot>
                  <tr className="border-t border-stone-200 bg-stone-50/50">
                    <td className="py-2 px-4 text-sm font-semibold text-stone-800">Total Order Price</td>
                    <td className="py-2 px-4 text-right text-base font-bold text-stone-900 font-mono">
                      {formatCurrency(printOrder.sellingPrice)}
                    </td>
                  </tr>
                  <tr className="text-emerald-700">
                    <td className="py-2 px-4 text-sm font-medium">Total Paid to Date</td>
                    <td className="py-2 px-4 text-right font-semibold font-mono">
                      {formatCurrency(printOrder.amountPaid)}
                    </td>
                  </tr>
                  <tr className="border-t-2 border-stone-900 bg-stone-100">
                    <td className="py-2.5 px-4 text-sm font-bold text-[#58111A]">Balance Due Upon Delivery</td>
                    <td className="py-2.5 px-4 text-right text-lg font-bold text-[#58111A] font-mono">
                      {formatCurrency(printOrder.balanceDue)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Payment Receipts History */}
          {payments.length > 0 && (
            <div className="mb-6">
              <h4 className="text-xs uppercase font-bold text-stone-400 tracking-wider mb-2">Payment Receipts</h4>
              <div className="bg-white rounded-xl border border-stone-200 p-3 space-y-1.5 text-xs">
                {payments.map((p, idx) => (
                  <div key={p.id} className="flex items-center justify-between text-stone-600 border-b border-stone-50 pb-1 last:border-0 last:pb-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-stone-800">Installment #{idx + 1}</span>
                      <span className="text-stone-400">·</span>
                      <span>{p.paymentDate}</span>
                      <span className="text-stone-400">·</span>
                      <span className="text-stone-500 font-medium">via {p.paymentMethod}</span>
                    </div>
                    <span className="font-bold text-emerald-800 font-mono">{formatCurrency(p.amount)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Notes & Tailoring Terms */}
          {printOrder.notes && (
            <div className="mb-6 text-xs text-stone-600 bg-amber-50/60 p-3.5 rounded-xl border border-amber-200/60">
              <span className="font-bold text-amber-900 block mb-0.5">Atelier Fitting Notes:</span>
              <p>{printOrder.notes}</p>
            </div>
          )}

          {/* Signatures & Footer */}
          <div className="mt-8 pt-6 border-t border-stone-200 grid grid-cols-2 gap-8 text-xs text-stone-500">
            <div>
              <div className="border-b border-stone-300 pb-10"></div>
              <p className="mt-1 font-medium text-stone-700">Client Signature / Confirmation</p>
            </div>
            <div>
              <div className="border-b border-stone-300 pb-10"></div>
              <p className="mt-1 font-medium text-stone-700">Tailor / Atelier Authorized Signature</p>
            </div>
          </div>

          <div className="mt-6 text-center text-[11px] text-stone-400 font-medium">
            Smart Tailoring · Powered by Unaabs Smart Business
          </div>
        </div>
      </div>
    </div>
  );
};
