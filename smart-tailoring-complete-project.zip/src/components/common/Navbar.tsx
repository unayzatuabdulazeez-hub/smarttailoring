import React from 'react';
import { useApp } from '../../context/AppContext';
import { Scissors, Search, Plus, User, LogOut, Sparkles, RotateCcw, Mic, Radio, Crown, Rocket, Download } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface NavbarProps {
  onOpenNewOrder: () => void;
  onOpenAuth: () => void;
  onOpenTranscribe?: () => void;
  onOpenLiveVoice?: () => void;
  onOpenPremiumHub?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenNewOrder,
  onOpenAuth,
  onOpenTranscribe,
  onOpenLiveVoice,
  onOpenPremiumHub,
}) => {
  const { user, isDemo, logout, globalSearch, setGlobalSearch, resetDemoData, setActiveTab } = useApp();

  return (
    <header className="sticky top-0 z-30 bg-[#FDFBF7]/90 backdrop-blur-md border-b border-stone-200/80 px-4 lg:px-8 py-3 transition-colors no-print">
      <div className="flex items-center justify-between gap-4 max-w-7xl mx-auto">
        {/* Zone 1: Single text wordmark with subtle scissors icon */}
        <div className="flex items-center gap-2.5">
          <div 
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-[#58111A] text-amber-300 flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
              <Scissors className="w-4 h-4" />
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-[#58111A] font-serif-display leading-none">
                Smart Tailoring
              </span>
              <span className="hidden sm:block text-[10px] text-stone-500 font-medium tracking-wide">
                Your tailoring business, smarter
              </span>
            </div>
          </div>

          {/* Demo Mode Badge with Go Live */}
          {isDemo && (
            <div className="flex items-center gap-1.5 ml-2 px-2.5 py-1 rounded-full bg-amber-100/90 border border-amber-300 text-amber-900 text-[11px] font-semibold">
              <Sparkles className="w-3 h-3 text-amber-600" />
              <span>DEMO</span>
              <button
                onClick={resetDemoData}
                title="Reset sample data"
                className="hover:text-amber-950 p-0.5 ml-0.5 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-2.5 h-2.5" />
              </button>
              <button
                onClick={onOpenAuth}
                className="ml-1 px-2.5 py-0.5 rounded-full bg-[#58111A] text-white hover:bg-[#4A0E17] text-[10px] font-bold shadow-2xs transition-colors cursor-pointer"
              >
                Go Live
              </button>
            </div>
          )}
        </div>

        {/* Zone 2: Global Search Input */}
        <div className="hidden md:flex flex-1 max-w-md mx-4">
          <div className="relative w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={globalSearch}
              onChange={(e) => setGlobalSearch(e.target.value)}
              placeholder="Search customers, order #, or outfits..."
              className="w-full pl-9 pr-4 py-1.5 bg-white border border-stone-200 rounded-xl text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A] transition-all shadow-2xs"
            />
          </div>
        </div>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {user ? (
            <>
              {/* Live Voice Assistant (gemini-3.8-live) */}
              {onOpenLiveVoice && (
                <button
                  onClick={onOpenLiveVoice}
                  className="inline-flex items-center gap-1 px-2.5 sm:px-3 py-1.5 bg-gradient-to-r from-[#58111A] to-[#801B28] hover:from-[#450C13] hover:to-[#6E1622] text-amber-200 text-xs font-semibold rounded-xl shadow-xs transition-all cursor-pointer border border-amber-300/30"
                  title="Talk with Unaabs Voice Assistant (gemini-3.8-live)"
                >
                  <Radio className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
                  <span className="hidden sm:inline">Voice Assistant</span>
                </button>
              )}

              {/* Speech-to-Text Transcribe (gemini-3.5-transcribe) */}
              {onOpenTranscribe && (
                <button
                  onClick={onOpenTranscribe}
                  className="inline-flex items-center gap-1 px-2 sm:px-2.5 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                  title="Dictate with gemini-3.5-transcribe"
                >
                  <Mic className="w-3.5 h-3.5 text-stone-600" />
                  <span className="hidden md:inline">Transcribe</span>
                </button>
              )}

              {/* Local to Premium Hub */}
              {onOpenPremiumHub && (
                <button
                  onClick={onOpenPremiumHub}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-950 border border-amber-300 text-xs font-bold rounded-xl transition-all cursor-pointer shadow-2xs"
                  title="Local to Premium Atelier Hub"
                >
                  <Crown className="w-3.5 h-3.5 text-amber-600" />
                  <span className="hidden lg:inline">Premium Hub</span>
                </button>
              )}

              {isDemo && (
                <button
                  onClick={onOpenAuth}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-stone-950 font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer"
                  title="Create your real tailoring business account"
                >
                  <Rocket className="w-3.5 h-3.5 text-stone-950" />
                  <span className="hidden sm:inline">Go Live</span>
                  <span className="sm:hidden">Go Live</span>
                </button>
              )}

              <PWAInstallButton variant="nav" />

              <button
                onClick={onOpenNewOrder}
                className="inline-flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 bg-[#58111A] hover:bg-[#4A0E17] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">New Order</span>
                <span className="sm:hidden">Order</span>
              </button>

              <a
                href="/download-project.zip"
                download="smart-tailoring-complete-project.zip"
                title="Download complete project ZIP to deploy manually"
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl border border-stone-300 shadow-2xs transition-all"
              >
                <Download className="w-3.5 h-3.5 text-stone-600" />
                <span>Download ZIP</span>
              </a>

              <div className="flex items-center gap-2 border-l border-stone-200 pl-2 sm:pl-3">
                <button
                  onClick={() => setActiveTab('settings')}
                  className="flex items-center gap-2 p-1 rounded-lg text-stone-700 hover:text-stone-900 hover:bg-stone-100 transition-colors"
                  title="Atelier Profile"
                >
                  <div className="w-7 h-7 rounded-full bg-stone-200 text-stone-700 flex items-center justify-center font-bold text-xs">
                    {user.businessName.charAt(0) || <User className="w-3.5 h-3.5" />}
                  </div>
                  <span className="hidden lg:inline text-xs font-medium text-stone-800 truncate max-w-[130px]">
                    {user.businessName}
                  </span>
                </button>

                <button
                  onClick={logout}
                  className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                  title="Log out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={onOpenAuth}
                className="px-3 py-1.5 text-xs font-semibold text-stone-700 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
              >
                Log In
              </button>
              <button
                onClick={onOpenAuth}
                className="px-3.5 py-1.5 bg-[#58111A] hover:bg-[#4A0E17] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
              >
                Get Started
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
