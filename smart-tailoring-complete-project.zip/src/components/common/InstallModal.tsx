import React, { useState } from 'react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import {
  Download,
  X,
  Smartphone,
  Monitor,
  Share2,
  PlusSquare,
  CheckCircle2,
  Sparkles,
  Scissors,
  Copy,
  Check,
  AlertTriangle,
  ExternalLink
} from 'lucide-react';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallModal: React.FC<InstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, install, isIOS, isAndroid } = usePWAInstall();
  const [activeDevice, setActiveDevice] = useState<'ios' | 'android' | 'desktop'>(
    isIOS ? 'ios' : isAndroid ? 'android' : 'desktop'
  );
  const [copiedLink, setCopiedLink] = useState(false);

  const userAgent = typeof window !== 'undefined' ? window.navigator.userAgent.toLowerCase() : '';
  const isInAppBrowser = /fban|fbav|instagram|whatsapp|wv|gsa|line|micromessenger/.test(userAgent);

  const cleanAppUrl = 'https://ais-pre-gkzy7fknfzt7f2vh5ws5lv-305535611626.europe-west2.run.app';

  const handleCopyLink = () => {
    navigator.clipboard.writeText(cleanAppUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  if (!isOpen) return null;

  const handleNativeInstall = async () => {
    const success = await install();
    if (success) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden border border-stone-200">
        {/* Header */}
        <div className="bg-[#58111A] text-white p-6 relative">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/20 text-amber-300 flex items-center justify-center">
              <Scissors className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif-display font-bold text-xl leading-tight">
                Install Smart Tailoring
              </h3>
              <p className="text-xs text-amber-200/80 mt-0.5">
                Install as a standalone app on your phone, tablet, or PC
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-stone-300 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Quick 1-Click Install Button if supported by current browser session */}
          {isInstallable && (
            <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-center justify-between gap-3">
              <div>
                <h4 className="font-bold text-emerald-950 text-xs">Ready for 1-Click Install</h4>
                <p className="text-[11px] text-emerald-800 mt-0.5">Add Smart Tailoring to your home screen now.</p>
              </div>
              <button
                onClick={handleNativeInstall}
                className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs transition-colors shrink-0 cursor-pointer"
              >
                Install Now
              </button>
            </div>
          )}

          {/* Device Tabs */}
          <div>
            <label className="block text-xs font-bold text-stone-400 uppercase tracking-wider mb-2">
              Select Your Device for Instructions:
            </label>
            <div className="grid grid-cols-3 gap-2 bg-stone-100 p-1 rounded-xl text-xs font-semibold">
              <button
                onClick={() => setActiveDevice('android')}
                className={`py-2 rounded-lg transition-all cursor-pointer ${
                  activeDevice === 'android'
                    ? 'bg-white text-[#58111A] shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Android
              </button>
              <button
                onClick={() => setActiveDevice('ios')}
                className={`py-2 rounded-lg transition-all cursor-pointer ${
                  activeDevice === 'ios'
                    ? 'bg-white text-[#58111A] shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                iPhone / iPad
              </button>
              <button
                onClick={() => setActiveDevice('desktop')}
                className={`py-2 rounded-lg transition-all cursor-pointer ${
                  activeDevice === 'desktop'
                    ? 'bg-white text-[#58111A] shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                PC / Laptop
              </button>
            </div>
          </div>

          {/* Step by step guide */}
          <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3 text-xs text-stone-700">
            {activeDevice === 'android' && (
              <div className="space-y-3">
                {isInAppBrowser && (
                  <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-xs text-amber-900 flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="block font-bold">In-App Browser Detected</strong>
                      <p className="text-[11px] text-amber-800 mt-0.5 leading-relaxed">
                        You opened this link inside an app (WhatsApp/Gmail/Messenger). In-app browsers block app installations.
                        Please tap the <strong>three dots (⋮)</strong> at the very top of your screen and select <strong>"Open in Chrome"</strong>.
                      </p>
                    </div>
                  </div>
                )}

                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#58111A] text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                    1
                  </span>
                  <p>
                    Open <strong>Google Chrome</strong> app on your Android phone and visit this direct link:
                  </p>
                </div>

                {/* Direct Link Copier */}
                <div className="p-2.5 bg-white border border-stone-200 rounded-xl flex items-center justify-between gap-2 text-[11px]">
                  <span className="font-mono text-stone-700 truncate select-all">
                    {cleanAppUrl}
                  </span>
                  <button
                    onClick={handleCopyLink}
                    className="inline-flex items-center gap-1 px-3 py-1 bg-stone-900 hover:bg-stone-800 text-white rounded-lg font-semibold shrink-0 cursor-pointer transition-colors"
                  >
                    {copiedLink ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy URL</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#58111A] text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                    2
                  </span>
                  <p>
                    In Chrome, tap the <strong>three dots (⋮)</strong> menu in the upper right corner of your browser.
                  </p>
                </div>

                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#58111A] text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                    3
                  </span>
                  <p>
                    Select <strong>"Install app"</strong> (or <strong>"Add to Home screen"</strong>), then tap <strong>Install</strong> when prompted.
                  </p>
                </div>
              </div>
            )}

            {activeDevice === 'ios' && (
              <div className="space-y-2.5">
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#58111A] text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                    1
                  </span>
                  <p>
                    Open this app in <strong>Safari</strong> on your iPhone or iPad.
                  </p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#58111A] text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                    2
                  </span>
                  <p>
                    Tap the <strong>Share button</strong> (the square icon with an arrow pointing upwards at the bottom of the screen).
                  </p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#58111A] text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                    3
                  </span>
                  <p>
                    Scroll down and tap <strong>"Add to Home Screen"</strong>, then tap <strong>Add</strong>.
                  </p>
                </div>
              </div>
            )}

            {activeDevice === 'desktop' && (
              <div className="space-y-2.5">
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#58111A] text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                    1
                  </span>
                  <p>
                    Open this app in <strong>Google Chrome</strong> or <strong>Microsoft Edge</strong> on your laptop/desktop.
                  </p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#58111A] text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                    2
                  </span>
                  <p>
                    Look at the right side of your URL address bar for the <strong>Install icon</strong> (computer monitor with a down arrow).
                  </p>
                </div>
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-[#58111A] text-white font-bold flex items-center justify-center shrink-0 text-[10px]">
                    3
                  </span>
                  <p>
                    Click <strong>Install</strong> to launch Smart Tailoring in its own distraction-free standalone desktop window.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Benefits */}
          <div className="grid grid-cols-2 gap-2 text-[11px] text-stone-600">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Full-screen experience</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Works without typing URLs</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Lightning-fast loading</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>Private studio storage</span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
