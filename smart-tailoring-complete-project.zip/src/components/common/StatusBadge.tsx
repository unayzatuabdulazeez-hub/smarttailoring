import React from 'react';
import { ProductionStatus, PaymentStatus } from '../../types';
import { CheckCircle2, Clock, AlertCircle, Sparkles } from 'lucide-react';

interface ProductionBadgeProps {
  status: ProductionStatus;
  className?: string;
  size?: 'sm' | 'md';
}

export const ProductionStatusBadge: React.FC<ProductionBadgeProps> = ({ status, className = '', size = 'md' }) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs';

  let colorClasses = '';
  switch (status) {
    case 'New':
      colorClasses = 'bg-stone-100 text-stone-700 border border-stone-200';
      break;
    case 'Confirmed':
      colorClasses = 'bg-sky-50 text-sky-800 border border-sky-200';
      break;
    case 'Cutting':
      colorClasses = 'bg-amber-50 text-amber-900 border border-amber-200';
      break;
    case 'Sewing':
      colorClasses = 'bg-[#58111A]/10 text-[#58111A] border border-[#58111A]/20';
      break;
    case 'Fitting':
      colorClasses = 'bg-orange-50 text-orange-800 border border-orange-200';
      break;
    case 'Ready':
      colorClasses = 'bg-emerald-50 text-emerald-800 border border-emerald-300 font-semibold';
      break;
    case 'Delivered':
      colorClasses = 'bg-teal-900 text-teal-50 border border-teal-800';
      break;
    case 'Cancelled':
      colorClasses = 'bg-rose-50 text-rose-800 border border-rose-200';
      break;
    default:
      colorClasses = 'bg-stone-100 text-stone-700 border border-stone-200';
  }

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-md font-medium tracking-wide whitespace-nowrap ${sizeClasses} ${colorClasses} ${className}`}>
      {status === 'Ready' && <Sparkles className="w-3 h-3 text-emerald-600" />}
      {status}
    </span>
  );
};

interface PaymentBadgeProps {
  status: PaymentStatus;
  className?: string;
  size?: 'sm' | 'md';
}

export const PaymentStatusBadge: React.FC<PaymentBadgeProps> = ({ status, className = '', size = 'md' }) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs';

  if (status === 'Paid') {
    return (
      <span className={`inline-flex items-center gap-1 rounded-md font-medium bg-emerald-50 text-emerald-800 border border-emerald-200 whitespace-nowrap ${sizeClasses} ${className}`}>
        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
        Paid
      </span>
    );
  }

  if (status === 'Partial') {
    return (
      <span className={`inline-flex items-center gap-1 rounded-md font-medium bg-amber-50 text-amber-800 border border-amber-200 whitespace-nowrap ${sizeClasses} ${className}`}>
        <Clock className="w-3 h-3 text-amber-600" />
        Partial
      </span>
    );
  }

  return (
    <span className={`inline-flex items-center gap-1 rounded-md font-medium bg-rose-50 text-rose-800 border border-rose-200 whitespace-nowrap ${sizeClasses} ${className}`}>
      <AlertCircle className="w-3 h-3 text-rose-600" />
      Unpaid
    </span>
  );
};
