import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { NavigationTab } from '../../types';
import {
  LayoutDashboard,
  Users,
  Ruler,
  ShoppingBag,
  CreditCard,
  Calculator,
  Layers,
  BarChart3,
  Settings,
  ChevronRight,
  Menu,
  X,
  Sparkles,
  Crown,
  Rocket,
  ShieldCheck
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface SidebarProps {
  onOpenNewOrder: () => void;
  onOpenPremiumHub?: () => void;
  onOpenAuth?: () => void;
  onOpenAdmin?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onOpenNewOrder, onOpenPremiumHub, onOpenAuth, onOpenAdmin }) => {
  const { activeTab, setActiveTab, orders, materials, isDemo, enterDemoMode, resetDemoData, user } = useApp();
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  // Active counts
  const activeOrdersCount = orders.filter(o => o.productionStatus !== 'Delivered' && o.productionStatus !== 'Cancelled').length;
  const lowStockCount = materials.filter(m => m.quantity <= m.lowStockThreshold).length;

  const navItems: { tab: NavigationTab; label: string; icon: React.ElementType; badge?: number; badgeColor?: string }[] = [
    { tab: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { tab: 'customers', label: 'Customers', icon: Users },
    { tab: 'measurements', label: 'Measurements', icon: Ruler },
    { tab: 'orders', label: 'Orders', icon: ShoppingBag, badge: activeOrdersCount > 0 ? activeOrdersCount : undefined, badgeColor: 'bg-[#58111A] text-white' },
    { tab: 'payments', label: 'Payments', icon: CreditCard },
    { tab: 'calculator', label: 'Pricing Calculator', icon: Calculator },
    { tab: 'materials', label: 'Materials & Stock', icon: Layers, badge: lowStockCount > 0 ? lowStockCount : undefined, badgeColor: 'bg-amber-600 text-white' },
    { tab: 'reports', label: 'Reports & Analytics', icon: BarChart3 },
    { tab: 'settings', label: 'Settings', icon: Settings }
  ];

  const handleSelectTab = (tab: NavigationTab) => {
    setActiveTab(tab);
    setMobileDrawerOpen(false);
  };

  return (
    <>
      {/* Desktop Sidebar (visible on md+) */}
      <aside className="hidden md:flex flex-col w-64 bg-[#FBF9F5] border-r border-stone-200/80 p-4 shrink-0 min-h-[calc(100vh-61px)] select-none no-print">
        <div className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.tab;
            return (
              <button
                key={item.tab}
                onClick={() => handleSelectTab(item.tab)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#58111A] text-white shadow-xs font-bold'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-amber-300' : 'text-stone-500'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-bold ${item.badgeColor || 'bg-stone-200 text-stone-800'}`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Demo Mode helper card if in demo */}
        {isDemo && (
          <div className="mt-auto pt-4">
            <div className="p-3.5 bg-amber-50/80 border border-amber-200 rounded-xl text-xs">
              <div className="flex items-center gap-1.5 font-bold text-amber-900">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                <span>Demo Atelier Data</span>
              </div>
              <p className="mt-1 text-stone-600 text-[11px] leading-relaxed">
                Test orders for Aisha, Fatima & Maryam. Feel free to add customers and track payments!
              </p>
              <div className="flex gap-2 mt-2.5">
                <button
                  onClick={resetDemoData}
                  className="flex-1 py-1.5 text-center text-[10px] font-semibold text-amber-950 bg-amber-200/80 hover:bg-amber-300/80 rounded-lg transition-colors cursor-pointer"
                >
                  Reset Demo
                </button>
                {onOpenAuth && (
                  <button
                    onClick={onOpenAuth}
                    className="flex-1 py-1.5 text-center text-[10px] font-bold text-white bg-[#58111A] hover:bg-[#4A0E17] rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1 shadow-2xs"
                  >
                    <Rocket className="w-2.5 h-2.5" />
                    <span>Go Live</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Local to Premium Service Hub */}
        {onOpenPremiumHub && (
          <div className="pt-2">
            <button
              onClick={onOpenPremiumHub}
              className="w-full flex items-center justify-between p-2.5 bg-gradient-to-r from-amber-50 to-purple-50 hover:from-amber-100 hover:to-purple-100 border border-amber-300/80 rounded-xl text-xs font-semibold text-amber-950 transition-all cursor-pointer shadow-2xs"
            >
              <div className="flex items-center gap-2">
                <Crown className="w-4 h-4 text-amber-600" />
                <div className="text-left">
                  <span className="block font-bold">Premium Atelier Hub</span>
                  <span className="block text-[10px] text-amber-800/80 font-normal">Double tailoring profits</span>
                </div>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-amber-700" />
            </button>
          </div>
        )}

        {/* App Owner Platform Console */}
        {onOpenAdmin && (
          <div className="pt-2">
            <button
              onClick={onOpenAdmin}
              className="w-full flex items-center justify-between p-2 rounded-xl text-stone-600 hover:text-stone-900 hover:bg-stone-100 text-xs font-semibold transition-colors cursor-pointer border border-dashed border-stone-200"
              title="Open App Owner Administration & Tailor Approval Console"
            >
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-[#58111A]" />
                <span>Owner Admin</span>
              </div>
              <span className="text-[9px] bg-stone-100 text-stone-600 px-1.5 py-0.5 rounded font-mono font-bold">
                Console
              </span>
            </button>
          </div>
        )}

        {/* Install App on Device CTA */}
        <div className="mt-auto pt-3">
          <PWAInstallButton variant="sidebar" />
        </div>

        {/* Quick business footer */}
        <div className="pt-3 border-t border-stone-200/80 text-[11px] text-stone-500">
          <p className="font-semibold text-stone-800 truncate">{user?.businessName}</p>
          <p className="text-[10px] text-stone-400">Currency: {user?.currency || '₦'} · Unit: {user?.defaultUnit || 'inches'}</p>
          <p className="text-[10px] text-[#C5A059] font-semibold mt-1">Powered by Unaabs Smart Business</p>
        </div>
      </aside>

      {/* Mobile Bottom Navigation Bar (visible below md) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-stone-200 py-1.5 px-3 flex items-center justify-around no-print">
        <button
          onClick={() => handleSelectTab('dashboard')}
          className={`flex flex-col items-center gap-0.5 py-1 px-2 rounded-lg text-[10px] font-medium transition-colors ${
            activeTab === 'dashboard' ? 'text-[#58111A] font-bold' : 'text-stone-500'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Home</span>
        </button>

        <button
          onClick={() => handleSelectTab('orders')}
          className={`relative flex flex-col items-center gap-0.5 py-1 px-2 rounded-lg text-[10px] font-medium transition-colors ${
            activeTab === 'orders' ? 'text-[#58111A] font-bold' : 'text-stone-500'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Orders</span>
          {activeOrdersCount > 0 && (
            <span className="absolute -top-1 right-2 w-4 h-4 bg-[#58111A] text-white rounded-full text-[9px] flex items-center justify-center font-bold">
              {activeOrdersCount}
            </span>
          )}
        </button>

        {/* Center Quick Action button */}
        <button
          onClick={onOpenNewOrder}
          className="w-10 h-10 -mt-4 bg-[#58111A] text-amber-300 rounded-full shadow-lg flex items-center justify-center border-2 border-white"
          title="New Order"
        >
          <span className="text-xl font-bold leading-none">+</span>
        </button>

        <button
          onClick={() => handleSelectTab('customers')}
          className={`flex flex-col items-center gap-0.5 py-1 px-2 rounded-lg text-[10px] font-medium transition-colors ${
            activeTab === 'customers' ? 'text-[#58111A] font-bold' : 'text-stone-500'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Clients</span>
        </button>

        <button
          onClick={() => setMobileDrawerOpen(true)}
          className={`flex flex-col items-center gap-0.5 py-1 px-2 rounded-lg text-[10px] font-medium transition-colors ${
            mobileDrawerOpen ? 'text-[#58111A] font-bold' : 'text-stone-500'
          }`}
        >
          <Menu className="w-4 h-4" />
          <span>Menu</span>
        </button>
      </nav>

      {/* Mobile Drawer Overlay */}
      {mobileDrawerOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex justify-end">
          <div className="bg-[#FCFBF8] w-4/5 max-w-xs h-full p-5 shadow-2xl flex flex-col justify-between overflow-y-auto">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-stone-200">
                <span className="font-serif-display font-bold text-base text-[#58111A]">Menu & Workspace</span>
                <button
                  onClick={() => setMobileDrawerOpen(false)}
                  className="p-1 rounded-lg text-stone-400 hover:text-stone-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-4 space-y-1">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.tab;
                  return (
                    <button
                      key={item.tab}
                      onClick={() => handleSelectTab(item.tab)}
                      className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold ${
                        isActive
                          ? 'bg-[#58111A] text-white'
                          : 'text-stone-700 hover:bg-stone-100'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </div>
                      {item.badge !== undefined && (
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${item.badgeColor || 'bg-stone-200'}`}>
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-stone-200 text-xs text-stone-500 space-y-3">
              {onOpenPremiumHub && (
                <button
                  onClick={() => {
                    setMobileDrawerOpen(false);
                    onOpenPremiumHub();
                  }}
                  className="w-full flex items-center justify-between p-2.5 bg-amber-50 hover:bg-amber-100 border border-amber-300 rounded-xl text-xs font-bold text-amber-950 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Crown className="w-4 h-4 text-amber-600" />
                    <span>Premium Atelier Hub</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-amber-700" />
                </button>
              )}
              {isDemo && onOpenAuth && (
                <button
                  onClick={() => {
                    setMobileDrawerOpen(false);
                    onOpenAuth();
                  }}
                  className="w-full flex items-center justify-center gap-2 p-2.5 bg-gradient-to-r from-amber-500 to-[#58111A] text-white font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer"
                >
                  <Rocket className="w-4 h-4 text-amber-200" />
                  <span>Go Live / Create My Atelier</span>
                </button>
              )}
              {onOpenAdmin && (
                <button
                  onClick={() => {
                    setMobileDrawerOpen(false);
                    onOpenAdmin();
                  }}
                  className="w-full flex items-center justify-between p-2.5 bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-xl text-xs font-semibold text-stone-800 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#58111A]" />
                    <span>Owner Admin Console</span>
                  </div>
                  <span className="text-[10px] bg-stone-200/80 px-1.5 py-0.5 rounded text-stone-700">Approve Tailors</span>
                </button>
              )}
              <PWAInstallButton variant="sidebar" />
              <div>
                <p className="font-semibold text-stone-800">{user?.businessName}</p>
                <p className="text-[10px] text-[#C5A059] font-semibold mt-0.5">Powered by Unaabs Smart Business</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
