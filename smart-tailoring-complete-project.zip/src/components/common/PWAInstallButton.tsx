import React, { useState } from 'react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { InstallModal } from './InstallModal';
import { Download, Smartphone } from 'lucide-react';

interface PWAInstallButtonProps {
  variant?: 'nav' | 'sidebar' | 'banner' | 'landing';
  className?: string;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ variant = 'nav', className = '' }) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);

  // If already running in standalone mode, do not show button
  if (isInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (!success) {
        setShowModal(true);
      }
    } else {
      setShowModal(true);
    }
  };

  return (
    <>
      {variant === 'nav' && (
        <button
          onClick={handleClick}
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#C5A059]/15 hover:bg-[#C5A059]/25 text-[#58111A] border border-[#C5A059]/40 text-xs font-semibold rounded-xl transition-all cursor-pointer ${className}`}
          title="Install Smart Tailoring to your phone or desktop"
        >
          <Download className="w-3.5 h-3.5 text-[#58111A]" />
          <span className="hidden sm:inline">Install App</span>
          <span className="sm:hidden">Install</span>
        </button>
      )}

      {variant === 'sidebar' && (
        <button
          onClick={handleClick}
          className={`w-full flex items-center justify-between p-3 bg-amber-50/80 hover:bg-amber-100/80 border border-amber-200/90 text-amber-950 rounded-xl text-xs font-semibold transition-all cursor-pointer ${className}`}
        >
          <div className="flex items-center gap-2.5">
            <Smartphone className="w-4 h-4 text-amber-700" />
            <div className="text-left">
              <span className="block font-bold">Install on Device</span>
              <span className="block text-[10px] text-amber-800/80 font-normal">Add to home screen</span>
            </div>
          </div>
          <Download className="w-3.5 h-3.5 text-amber-700" />
        </button>
      )}

      {variant === 'landing' && (
        <button
          onClick={handleClick}
          className={`inline-flex items-center gap-2 px-5 py-3.5 bg-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm rounded-xl shadow-xs transition-all cursor-pointer ${className}`}
        >
          <Download className="w-4 h-4" />
          <span>Install on Your Device</span>
        </button>
      )}

      <InstallModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
      />
    </>
  );
};
