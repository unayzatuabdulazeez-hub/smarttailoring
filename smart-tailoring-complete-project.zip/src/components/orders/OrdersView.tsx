import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Order, ProductionStatus, PaymentStatus } from '../../types';
import { ProductionStatusBadge, PaymentStatusBadge } from '../common/StatusBadge';
import { EmptyState } from '../common/EmptyState';
import {
  ShoppingBag,
  Search,
  Plus,
  Filter,
  Calendar,
  ChevronRight,
  ArrowUpDown,
  CreditCard,
  Printer
} from 'lucide-react';

interface OrdersViewProps {
  onOpenNewOrder: () => void;
  onSelectOrder: (orderId: string) => void;
}

export const OrdersView: React.FC<OrdersViewProps> = ({ onOpenNewOrder, onSelectOrder }) => {
  const { orders, customers, formatCurrency, setPrintOrder, globalSearch } = useApp();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [paymentFilter, setPaymentFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'date-desc' | 'date-asc' | 'price-desc' | 'delivery'>('date-desc');

  // Customer map for fast lookup
  const customerMap = useMemo(() => {
    const map = new Map<string, string>();
    customers.forEach(c => map.set(c.id, c.fullName));
    return map;
  }, [customers]);

  const activeSearch = globalSearch || search;

  const filteredOrders = useMemo(() => {
    return orders.filter(order => {
      // Text search
      const customerName = customerMap.get(order.customerId) || '';
      const matchesSearch =
        !activeSearch ||
        order.orderNumber.toLowerCase().includes(activeSearch.toLowerCase()) ||
        customerName.toLowerCase().includes(activeSearch.toLowerCase()) ||
        order.outfitType.toLowerCase().includes(activeSearch.toLowerCase()) ||
        (order.fabricType && order.fabricType.toLowerCase().includes(activeSearch.toLowerCase()));

      if (!matchesSearch) return false;

      // Status filter
      if (statusFilter !== 'all' && order.productionStatus !== statusFilter) {
        return false;
      }

      // Payment filter
      const pStatus: PaymentStatus = order.balanceDue <= 0 ? 'Paid' : order.amountPaid > 0 ? 'Partial' : 'Unpaid';
      if (paymentFilter !== 'all' && pStatus !== paymentFilter) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'date-desc') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sortBy === 'date-asc') return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      if (sortBy === 'price-desc') return b.sellingPrice - a.sellingPrice;
      if (sortBy === 'delivery') return new Date(a.deliveryDate).getTime() - new Date(b.deliveryDate).getTime();
      return 0;
    });
  }, [orders, activeSearch, statusFilter, paymentFilter, sortBy, customerMap]);

  return (
    <div className="space-y-6">
      {/* Top action bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-serif-display text-stone-900 tracking-tight">
            Orders & Production
          </h1>
          <p className="text-xs text-stone-500 mt-0.5">
            Track cutting, sewing, fittings, balances, and client delivery deadlines ({filteredOrders.length} orders)
          </p>
        </div>

        <button
          onClick={onOpenNewOrder}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#58111A] hover:bg-[#4A0E17] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Order</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          {/* Search */}
          <div className="sm:col-span-5 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by order #, client name, or outfit..."
              className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>

          {/* Status Filter */}
          <div className="sm:col-span-3">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            >
              <option value="all">All Stages</option>
              <option value="New">New</option>
              <option value="Confirmed">Confirmed</option>
              <option value="Cutting">Cutting</option>
              <option value="Sewing">Sewing</option>
              <option value="Fitting">Fitting</option>
              <option value="Ready">Ready</option>
              <option value="Delivered">Delivered</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>

          {/* Payment Status Filter */}
          <div className="sm:col-span-2">
            <select
              value={paymentFilter}
              onChange={(e) => setPaymentFilter(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            >
              <option value="all">All Payments</option>
              <option value="Paid">Fully Paid</option>
              <option value="Partial">Partial Deposit</option>
              <option value="Unpaid">Unpaid</option>
            </select>
          </div>

          {/* Sorting */}
          <div className="sm:col-span-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            >
              <option value="date-desc">Newest First</option>
              <option value="date-asc">Oldest First</option>
              <option value="delivery">Delivery Date</option>
              <option value="price-desc">Highest Price</option>
            </select>
          </div>
        </div>
      </div>

      {/* Orders List / Table */}
      {filteredOrders.length === 0 ? (
        <EmptyState
          icon={ShoppingBag}
          title={orders.length === 0 ? "No orders recorded yet" : "No orders matching your filters"}
          description={
            orders.length === 0
              ? "Create your first bespoke clothing order to start tracking fabric, cutting, and fitting stages."
              : "Try adjusting your search query, production status, or payment status filters."
          }
          actionLabel={orders.length === 0 ? "Create First Order" : undefined}
          onAction={orders.length === 0 ? onOpenNewOrder : undefined}
        />
      ) : (
        <div className="space-y-3">
          {filteredOrders.map((order) => {
            const customerName = customerMap.get(order.customerId) || 'Walk-in Client';
            const paymentStatus: PaymentStatus =
              order.balanceDue <= 0 ? 'Paid' : order.amountPaid > 0 ? 'Partial' : 'Unpaid';
            const isDueSoon =
              new Date(order.deliveryDate).getTime() - new Date().getTime() <= 3 * 24 * 60 * 60 * 1000 &&
              order.productionStatus !== 'Delivered';

            return (
              <div
                key={order.id}
                onClick={() => onSelectOrder(order.id)}
                className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 shadow-2xs hover:border-[#58111A]/40 hover:shadow-md transition-all cursor-pointer group"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  {/* Left: Order number & garment */}
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono font-bold text-stone-900 text-sm">
                        {order.orderNumber}
                      </span>
                      <span className="text-stone-300">·</span>
                      <span className="font-semibold text-stone-900 text-sm">
                        {customerName}
                      </span>
                      <ProductionStatusBadge status={order.productionStatus} size="sm" />
                      <PaymentStatusBadge status={paymentStatus} size="sm" />
                    </div>

                    <div className="flex items-center gap-3 text-xs text-stone-500 flex-wrap">
                      <span className="font-medium text-[#58111A]">
                        {order.outfitType === 'Custom' ? (order.customOutfitType || 'Custom') : order.outfitType}
                      </span>
                      {order.fabricType && (
                        <>
                          <span>·</span>
                          <span>{order.fabricType} ({order.fabricColour || 'Standard'})</span>
                        </>
                      )}
                      <span>·</span>
                      <span className={`flex items-center gap-1 ${isDueSoon ? 'text-amber-800 font-bold' : ''}`}>
                        <Calendar className="w-3 h-3" />
                        Delivery: {new Date(order.deliveryDate).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  {/* Right: Financials & Action */}
                  <div className="flex items-center justify-between sm:justify-end gap-6 pt-2 sm:pt-0 border-t sm:border-t-0 border-stone-100">
                    <div className="text-left sm:text-right">
                      <span className="text-xs font-mono font-bold text-stone-900 block">
                        {formatCurrency(order.sellingPrice)}
                      </span>
                      <span className="text-[11px] font-mono text-stone-500">
                        {order.balanceDue > 0 ? (
                          <span className="text-[#58111A] font-semibold">Bal: {formatCurrency(order.balanceDue)}</span>
                        ) : (
                          <span className="text-emerald-700 font-medium">Fully Settled</span>
                        )}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setPrintOrder(order);
                        }}
                        className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100 transition-colors"
                        title="Print Invoice"
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                      <ChevronRight className="w-4 h-4 text-stone-400 group-hover:text-[#58111A] group-hover:translate-x-0.5 transition-all" />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
