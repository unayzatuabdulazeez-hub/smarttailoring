import React, { useState } from 'react';
import { Order, PaymentMethod } from '../../types';
import { useApp } from '../../context/AppContext';
import { X, CreditCard, DollarSign, Calendar, FileText } from 'lucide-react';

interface RecordPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
}

export const RecordPaymentModal: React.FC<RecordPaymentModalProps> = ({
  isOpen,
  onClose,
  order
}) => {
  const { addPayment, formatCurrency } = useApp();

  const [amount, setAmount] = useState<number>(order?.balanceDue || 0);
  const [paymentDate, setPaymentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Bank Transfer');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');

  if (!isOpen || !order) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount <= 0) {
      setError('Payment amount must be greater than zero.');
      return;
    }
    if (amount > order.balanceDue) {
      setError(`Payment amount cannot exceed the remaining balance due of ${formatCurrency(order.balanceDue)}.`);
      return;
    }

    addPayment({
      orderId: order.id,
      customerId: order.customerId,
      amount,
      paymentDate,
      paymentMethod,
      note: note.trim()
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-stone-200">
        {/* Header */}
        <div className="bg-[#58111A] text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-amber-300" />
            <div>
              <h3 className="font-serif-display font-bold text-lg leading-tight">Record Payment</h3>
              <p className="text-[11px] text-amber-200/80">Order: {order.orderNumber}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-stone-300 hover:text-white p-1 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Balance Status card */}
        <div className="bg-stone-50 border-b border-stone-200 p-4 grid grid-cols-3 gap-2 text-center text-xs">
          <div>
            <span className="text-[10px] text-stone-500 uppercase font-semibold block">Total Price</span>
            <span className="font-bold text-stone-800 font-mono">{formatCurrency(order.sellingPrice)}</span>
          </div>
          <div>
            <span className="text-[10px] text-stone-500 uppercase font-semibold block">Already Paid</span>
            <span className="font-bold text-emerald-800 font-mono">{formatCurrency(order.amountPaid)}</span>
          </div>
          <div>
            <span className="text-[10px] text-stone-500 uppercase font-semibold block">Remaining Balance</span>
            <span className="font-bold text-[#58111A] font-mono">{formatCurrency(order.balanceDue)}</span>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-medium">
              {error}
            </div>
          )}

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-stone-700 uppercase tracking-wider">
                Payment Amount *
              </label>
              <button
                type="button"
                onClick={() => setAmount(order.balanceDue)}
                className="text-xs text-[#58111A] hover:underline font-semibold"
              >
                Pay Full Balance ({formatCurrency(order.balanceDue)})
              </button>
            </div>
            <input
              type="number"
              required
              min="1"
              max={order.balanceDue}
              value={amount || ''}
              onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
              placeholder="0"
              className="w-full px-3 py-2 bg-stone-50 border-2 border-stone-300 rounded-xl text-lg font-bold font-mono text-emerald-800 focus:outline-none focus:border-emerald-600"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                Payment Date *
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                <input
                  type="date"
                  required
                  value={paymentDate}
                  onChange={(e) => setPaymentDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                Payment Method *
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
              >
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Cash">Cash</option>
                <option value="POS">POS / Card</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
              Payment Note / Reference
            </label>
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="e.g. GTBank transfer ref: 948271, 2nd installment"
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>

          <div className="pt-3 flex items-center justify-end gap-3 border-t border-stone-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-stone-600 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-sm font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              Confirm Payment
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
