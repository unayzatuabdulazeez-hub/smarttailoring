import React, { useState, useEffect } from 'react';
import { Customer, Order, MeasurementProfile, ProductionStatus, ServiceTier } from '../../types';
import { useApp } from '../../context/AppContext';
import { CustomerFormModal } from '../customers/CustomerFormModal';
import { LocalToPremiumModal } from '../premium/LocalToPremiumModal';
import { AudioTranscribeModal } from '../voice/AudioTranscribeModal';
import {
  X,
  ShoppingBag,
  Plus,
  Sparkles,
  User,
  Calendar,
  DollarSign,
  Scissors,
  Info,
  Crown,
  Mic,
  Clock,
  Award
} from 'lucide-react';

interface OrderFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderToEdit?: Order | null;
  initialCustomerId?: string;
  initialQuoteData?: {
    customerName?: string;
    outfitType?: string;
    fabricCost: number;
    labourCost: number;
    materialsCost: number;
    otherExpenses: number;
    sellingPrice: number;
    notes?: string;
  };
}

export const OrderFormModal: React.FC<OrderFormModalProps> = ({
  isOpen,
  onClose,
  orderToEdit,
  initialCustomerId,
  initialQuoteData
}) => {
  const { customers, measurements, addOrder, updateOrder, formatCurrency } = useApp();

  const [customerId, setCustomerId] = useState(initialCustomerId || '');
  const [outfitType, setOutfitType] = useState('Kaftan');
  const [customOutfitType, setCustomOutfitType] = useState('');
  const [orderDescription, setOrderDescription] = useState('');
  const [measurementProfileId, setMeasurementProfileId] = useState('');

  // Fabric
  const [fabricType, setFabricType] = useState('');
  const [fabricColour, setFabricColour] = useState('');
  const [fabricSuppliedByCustomer, setFabricSuppliedByCustomer] = useState(false);
  const [fabricCost, setFabricCost] = useState<number>(0);

  // Costs
  const [labourCost, setLabourCost] = useState<number>(0);
  const [additionalMaterialCost, setAdditionalMaterialCost] = useState<number>(0);
  const [otherCost, setOtherCost] = useState<number>(0);

  // Price & Payment
  const [sellingPrice, setSellingPrice] = useState<number>(0);
  const [amountPaid, setAmountPaid] = useState<number>(0);
  const [deliveryDate, setDeliveryDate] = useState('');
  const [productionStatus, setProductionStatus] = useState<ProductionStatus>('New');
  const [serviceTier, setServiceTier] = useState<ServiceTier>('Standard');
  const [isExpress, setIsExpress] = useState(false);
  const [fittingAppointmentDate, setFittingAppointmentDate] = useState('');
  const [notes, setNotes] = useState('');

  // Helper modals
  const [showAddCustomerModal, setShowAddCustomerModal] = useState(false);
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [showDictateModal, setShowDictateModal] = useState(false);
  const [error, setError] = useState('');

  // Customer's available measurements
  const availableMeasurements = measurements.filter(m => m.customerId === customerId);

  useEffect(() => {
    if (orderToEdit) {
      setCustomerId(orderToEdit.customerId);
      setOutfitType(orderToEdit.outfitType);
      setCustomOutfitType(orderToEdit.customOutfitType || '');
      setOrderDescription(orderToEdit.orderDescription || '');
      setMeasurementProfileId(orderToEdit.measurementProfileId || '');
      setFabricType(orderToEdit.fabricType || '');
      setFabricColour(orderToEdit.fabricColour || '');
      setFabricSuppliedByCustomer(orderToEdit.fabricSuppliedByCustomer);
      setFabricCost(orderToEdit.fabricCost || 0);
      setLabourCost(orderToEdit.labourCost || 0);
      setAdditionalMaterialCost(orderToEdit.additionalMaterialCost || 0);
      setOtherCost(orderToEdit.otherCost || 0);
      setSellingPrice(orderToEdit.sellingPrice || 0);
      setAmountPaid(orderToEdit.amountPaid || 0);
      setDeliveryDate(orderToEdit.deliveryDate || '');
      setProductionStatus(orderToEdit.productionStatus || 'New');
      setServiceTier(orderToEdit.serviceTier || 'Standard');
      setIsExpress(!!orderToEdit.isExpress);
      setFittingAppointmentDate(orderToEdit.fittingAppointmentDate || '');
      setNotes(orderToEdit.notes || '');
    } else if (initialQuoteData) {
      if (initialCustomerId) setCustomerId(initialCustomerId);
      if (initialQuoteData.outfitType) setOutfitType(initialQuoteData.outfitType);
      setFabricCost(initialQuoteData.fabricCost || 0);
      setLabourCost(initialQuoteData.labourCost || 0);
      setAdditionalMaterialCost(initialQuoteData.materialsCost || 0);
      setOtherCost(initialQuoteData.otherExpenses || 0);
      setSellingPrice(initialQuoteData.sellingPrice || 0);
      setNotes(initialQuoteData.notes || '');
      setServiceTier('Standard');
      setIsExpress(false);
      setFittingAppointmentDate('');
      // Default delivery date to 10 days out
      const tenDaysOut = new Date();
      tenDaysOut.setDate(tenDaysOut.getDate() + 10);
      setDeliveryDate(tenDaysOut.toISOString().split('T')[0]);
    } else {
      setCustomerId(initialCustomerId || (customers[0]?.id || ''));
      setOutfitType('Kaftan');
      setCustomOutfitType('');
      setOrderDescription('');
      setMeasurementProfileId('');
      setFabricType('');
      setFabricColour('');
      setFabricSuppliedByCustomer(false);
      setFabricCost(0);
      setLabourCost(0);
      setAdditionalMaterialCost(0);
      setOtherCost(0);
      setSellingPrice(0);
      setAmountPaid(0);
      setServiceTier('Standard');
      setIsExpress(false);
      setFittingAppointmentDate('');
      // Default delivery date to 10 days out
      const defaultDate = new Date();
      defaultDate.setDate(defaultDate.getDate() + 10);
      setDeliveryDate(defaultDate.toISOString().split('T')[0]);
      setProductionStatus('New');
      setNotes('');
    }
    setError('');
  }, [orderToEdit, initialCustomerId, initialQuoteData, isOpen, customers]);

  // When customer changes, auto-select their first measurement profile if available
  useEffect(() => {
    if (customerId && !measurementProfileId) {
      const first = measurements.find(m => m.customerId === customerId);
      if (first) {
        setMeasurementProfileId(first.id);
      }
    }
  }, [customerId, measurementProfileId, measurements]);

  if (!isOpen) return null;

  // Real-time calculated properties
  const totalCost = Number(fabricCost || 0) + 
                    Number(labourCost || 0) + 
                    Number(additionalMaterialCost || 0) + 
                    Number(otherCost || 0);
  const profit = Number(sellingPrice || 0) - totalCost;
  const balanceDue = Math.max(0, Number(sellingPrice || 0) - Number(amountPaid || 0));

  const outfitOptions = [
    'Kaftan',
    'Jalabiya',
    'Abaya',
    'Gown',
    'Two-piece',
    'Three-piece',
    'Trouser',
    'Shirt',
    'Skirt',
    'Native wear',
    'Custom'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerId) {
      setError('Please select a customer for this order.');
      return;
    }
    if (sellingPrice <= 0) {
      setError('Selling price must be greater than 0.');
      return;
    }
    if (amountPaid > sellingPrice) {
      setError('Amount paid cannot exceed selling price.');
      return;
    }
    if (!deliveryDate) {
      setError('Please set a promised delivery date.');
      return;
    }

    if (orderToEdit) {
      updateOrder(orderToEdit.id, {
        customerId,
        outfitType,
        customOutfitType: outfitType === 'Custom' ? customOutfitType : undefined,
        orderDescription: orderDescription.trim(),
        measurementProfileId: measurementProfileId || undefined,
        fabricType: fabricType.trim(),
        fabricColour: fabricColour.trim(),
        fabricSuppliedByCustomer,
        fabricCost: Number(fabricCost || 0),
        labourCost: Number(labourCost || 0),
        additionalMaterialCost: Number(additionalMaterialCost || 0),
        otherCost: Number(otherCost || 0),
        sellingPrice: Number(sellingPrice || 0),
        deliveryDate,
        productionStatus,
        serviceTier,
        isExpress,
        fittingAppointmentDate: fittingAppointmentDate || undefined,
        notes: notes.trim()
      });
      onClose();
    } else {
      addOrder({
        customerId,
        outfitType,
        customOutfitType: outfitType === 'Custom' ? customOutfitType : undefined,
        orderDescription: orderDescription.trim(),
        measurementProfileId: measurementProfileId || undefined,
        fabricType: fabricType.trim(),
        fabricColour: fabricColour.trim(),
        fabricSuppliedByCustomer,
        fabricCost: Number(fabricCost || 0),
        labourCost: Number(labourCost || 0),
        additionalMaterialCost: Number(additionalMaterialCost || 0),
        otherCost: Number(otherCost || 0),
        sellingPrice: Number(sellingPrice || 0),
        amountPaid: Number(amountPaid || 0),
        deliveryDate,
        productionStatus,
        serviceTier,
        isExpress,
        fittingAppointmentDate: fittingAppointmentDate || undefined,
        notes: notes.trim()
      });
      onClose();
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
        <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl overflow-hidden border border-stone-200 my-8">
          {/* Header */}
          <div className="bg-[#58111A] text-white px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-amber-300" />
              <div>
                <h3 className="font-serif-display font-bold text-lg leading-tight">
                  {orderToEdit ? `Edit Order ${orderToEdit.orderNumber}` : 'Create Bespoke Order'}
                </h3>
                <p className="text-[11px] text-amber-200/80">Record garment specs, fabric, fittings, and payments</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-stone-300 hover:text-white p-1 rounded-md transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[82vh] overflow-y-auto">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-medium">
                {error}
              </div>
            )}

            {/* Section 1: Customer & Garment Type */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              <div className="md:col-span-7">
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-stone-700 uppercase tracking-wider">
                    Customer *
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowAddCustomerModal(true)}
                    className="inline-flex items-center gap-1 text-xs text-[#58111A] hover:text-[#4A0E17] font-semibold cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Add New Customer</span>
                  </button>
                </div>
                <select
                  required
                  value={customerId}
                  onChange={(e) => setCustomerId(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                >
                  <option value="">-- Select Customer --</option>
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.fullName} · {c.phoneNumber}
                    </option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-5">
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Outfit Type *
                </label>
                <select
                  value={outfitType}
                  onChange={(e) => setOutfitType(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                >
                  {outfitOptions.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Service Tier Selector: Standard Local vs Premium vs Royal VIP */}
            <div className="p-3.5 bg-gradient-to-r from-stone-50 via-amber-50/40 to-purple-50/30 rounded-2xl border border-stone-200">
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-stone-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Crown className="w-3.5 h-3.5 text-amber-600" />
                  <span>Atelier Service Level</span>
                </label>
                <button
                  type="button"
                  onClick={() => setShowPremiumModal(true)}
                  className="text-[11px] text-[#58111A] hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-amber-600" />
                  <span>Premium Service Guide</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div
                  onClick={() => setServiceTier('Standard')}
                  className={`p-2.5 rounded-xl border cursor-pointer text-xs transition-all ${
                    serviceTier === 'Standard'
                      ? 'border-[#58111A] bg-white shadow-2xs font-semibold text-stone-900 ring-1 ring-[#58111A]/20'
                      : 'border-stone-200 bg-white/60 text-stone-600 hover:border-stone-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold">🌟 Standard Local</span>
                    <input
                      type="radio"
                      name="orderServiceTier"
                      checked={serviceTier === 'Standard'}
                      onChange={() => setServiceTier('Standard')}
                      className="accent-[#58111A]"
                    />
                  </div>
                  <p className="text-[10px] text-stone-500 mt-0.5">Reliable daily tailoring</p>
                </div>

                <div
                  onClick={() => setServiceTier('Premium')}
                  className={`p-2.5 rounded-xl border cursor-pointer text-xs transition-all ${
                    serviceTier === 'Premium'
                      ? 'border-amber-500 bg-amber-50/80 shadow-2xs font-bold text-amber-950 ring-1 ring-amber-400/30'
                      : 'border-stone-200 bg-white/60 text-stone-600 hover:border-stone-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold">👑 Unaabs Premium</span>
                    <input
                      type="radio"
                      name="orderServiceTier"
                      checked={serviceTier === 'Premium'}
                      onChange={() => setServiceTier('Premium')}
                      className="accent-amber-600"
                    />
                  </div>
                  <p className="text-[10px] text-amber-800/80 mt-0.5">Canvas, French seams, VIP fitting</p>
                </div>

                <div
                  onClick={() => setServiceTier('Royal_VIP')}
                  className={`p-2.5 rounded-xl border cursor-pointer text-xs transition-all ${
                    serviceTier === 'Royal_VIP'
                      ? 'border-purple-600 bg-purple-50/80 shadow-2xs font-bold text-purple-950 ring-1 ring-purple-400/30'
                      : 'border-stone-200 bg-white/60 text-stone-600 hover:border-stone-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold">💎 Royal VIP Bespoke</span>
                    <input
                      type="radio"
                      name="orderServiceTier"
                      checked={serviceTier === 'Royal_VIP'}
                      onChange={() => setServiceTier('Royal_VIP')}
                      className="accent-purple-600"
                    />
                  </div>
                  <p className="text-[10px] text-purple-800/80 mt-0.5">Custom embroidery, luxury bag</p>
                </div>
              </div>

              {serviceTier !== 'Standard' && (
                <div className="mt-3 pt-2.5 border-t border-stone-200/80 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-amber-600" />
                      <span>Scheduled Fitting Appointment</span>
                    </label>
                    <input
                      type="date"
                      value={fittingAppointmentDate}
                      onChange={(e) => setFittingAppointmentDate(e.target.value)}
                      className="w-full px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs text-stone-900"
                    />
                  </div>
                  <div className="flex items-center gap-2 pt-5">
                    <label className="flex items-center gap-2 text-xs font-semibold text-stone-800 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={isExpress}
                        onChange={(e) => setIsExpress(e.target.checked)}
                        className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4"
                      />
                      <span>VIP Express Turnaround (48h)</span>
                    </label>
                  </div>
                </div>
              )}
            </div>

            {outfitType === 'Custom' && (
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Specify Custom Outfit Name *
                </label>
                <input
                  type="text"
                  required
                  value={customOutfitType}
                  onChange={(e) => setCustomOutfitType(e.target.value)}
                  placeholder="e.g. Bridal Kimono Cape, Senator Trench Coat"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                />
              </div>
            )}

            {/* Measurement Profile Linking */}
            <div className="p-4 bg-stone-50/80 rounded-xl border border-stone-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                <label className="text-xs font-bold text-stone-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Scissors className="w-4 h-4 text-[#58111A]" />
                  <span>Attach Saved Measurement Profile</span>
                </label>
                {customerId && availableMeasurements.length === 0 && (
                  <span className="text-xs text-amber-700 font-medium">
                    No measurements saved yet for this customer
                  </span>
                )}
              </div>

              <select
                value={measurementProfileId}
                onChange={(e) => setMeasurementProfileId(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
              >
                <option value="">-- None / Measure Later --</option>
                {availableMeasurements.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.profileName} ({m.unit}) — Recorded {new Date(m.recordedAt).toLocaleDateString()}
                  </option>
                ))}
              </select>
            </div>

            {/* Description & Voice Dictation */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-stone-700 uppercase tracking-wider">
                  Order Description & Styling Specifications
                </label>
                <button
                  type="button"
                  onClick={() => setShowDictateModal(true)}
                  className="inline-flex items-center gap-1 text-xs text-[#58111A] hover:text-[#4A0E17] font-semibold cursor-pointer px-2.5 py-1 rounded-lg bg-amber-100/70 hover:bg-amber-100 transition-colors border border-amber-300/40"
                  title="Dictate with gemini-3.5-transcribe"
                >
                  <Mic className="w-3.5 h-3.5 text-[#58111A]" />
                  <span>Dictate Notes (AI)</span>
                </button>
              </div>
              <textarea
                rows={2}
                value={orderDescription}
                onChange={(e) => setOrderDescription(e.target.value)}
                placeholder="Style details, embroidery patterns, neck cut (mandarin, round, v-neck), sleeve type, special trims..."
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
              />
            </div>

            {/* Section 2: Fabric Information */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-stone-400 uppercase tracking-wider border-b border-stone-200 pb-1">
                Fabric & Material Information
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Fabric Type
                  </label>
                  <input
                    type="text"
                    value={fabricType}
                    onChange={(e) => setFabricType(e.target.value)}
                    placeholder="e.g. Guinea Brocade, Damask, Silk"
                    className="w-full px-3 py-1.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Fabric Colour
                  </label>
                  <input
                    type="text"
                    value={fabricColour}
                    onChange={(e) => setFabricColour(e.target.value)}
                    placeholder="e.g. Deep Wine, Emerald, Ivory"
                    className="w-full px-3 py-1.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Fabric Source
                  </label>
                  <select
                    value={fabricSuppliedByCustomer ? 'yes' : 'no'}
                    onChange={(e) => {
                      const byCustomer = e.target.value === 'yes';
                      setFabricSuppliedByCustomer(byCustomer);
                      if (byCustomer) setFabricCost(0);
                    }}
                    className="w-full px-3 py-1.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900"
                  >
                    <option value="no">Atelier Provided</option>
                    <option value="yes">Supplied by Customer</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Section 3: Cost Accounting & Profit */}
            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-4">
              <h4 className="text-xs font-bold text-stone-800 uppercase tracking-wider flex items-center justify-between">
                <span>Cost & Pricing Breakdown</span>
                <span className="text-[11px] text-stone-500 font-normal">Auto-calculated profit & balance</span>
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <label className="block text-stone-600 font-semibold mb-1">Fabric Cost</label>
                  <input
                    type="number"
                    min="0"
                    disabled={fabricSuppliedByCustomer}
                    value={fabricCost || ''}
                    onChange={(e) => setFabricCost(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full px-2.5 py-1.5 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900 disabled:bg-stone-100 disabled:text-stone-400"
                  />
                </div>

                <div>
                  <label className="block text-stone-600 font-semibold mb-1">Labour Cost</label>
                  <input
                    type="number"
                    min="0"
                    value={labourCost || ''}
                    onChange={(e) => setLabourCost(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full px-2.5 py-1.5 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                  />
                </div>

                <div>
                  <label className="block text-stone-600 font-semibold mb-1">Trims & Materials</label>
                  <input
                    type="number"
                    min="0"
                    value={additionalMaterialCost || ''}
                    onChange={(e) => setAdditionalMaterialCost(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full px-2.5 py-1.5 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                  />
                </div>

                <div>
                  <label className="block text-stone-600 font-semibold mb-1">Logistics / Other</label>
                  <input
                    type="number"
                    min="0"
                    value={otherCost || ''}
                    onChange={(e) => setOtherCost(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full px-2.5 py-1.5 bg-white border border-stone-300 rounded-lg font-mono font-bold text-stone-900"
                  />
                </div>
              </div>

              {/* Price & Deposit Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-stone-200">
                <div>
                  <label className="block text-xs font-bold text-[#58111A] uppercase tracking-wider mb-1">
                    Selling Price (Billed to Client) *
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={sellingPrice || ''}
                    onChange={(e) => setSellingPrice(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-white border-2 border-[#58111A]/40 rounded-xl text-base font-bold font-mono text-[#58111A] focus:outline-none focus:border-[#58111A]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                    Amount Paid / Initial Deposit
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={amountPaid || ''}
                    onChange={(e) => setAmountPaid(parseFloat(e.target.value) || 0)}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-white border border-stone-300 rounded-xl text-base font-bold font-mono text-emerald-800 focus:outline-none focus:border-emerald-600"
                  />
                </div>
              </div>

              {/* Dynamic Calculation Summary Card */}
              <div className="bg-stone-900 text-white p-3.5 rounded-xl grid grid-cols-3 gap-2 text-center text-xs">
                <div>
                  <span className="block text-[10px] text-stone-400 uppercase font-semibold">Total Cost</span>
                  <span className="text-sm font-bold font-mono text-stone-200">{formatCurrency(totalCost)}</span>
                </div>
                <div>
                  <span className="block text-[10px] text-emerald-400 uppercase font-semibold">Expected Profit</span>
                  <span className={`text-sm font-bold font-mono ${profit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {formatCurrency(profit)}
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] text-amber-300 uppercase font-semibold">Balance Due</span>
                  <span className="text-sm font-bold font-mono text-amber-300">{formatCurrency(balanceDue)}</span>
                </div>
              </div>
            </div>

            {/* Section 4: Production Status & Delivery */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Promised Delivery Date *
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="date"
                    required
                    value={deliveryDate}
                    onChange={(e) => setDeliveryDate(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Production Stage
                </label>
                <select
                  value={productionStatus}
                  onChange={(e) => setProductionStatus(e.target.value as ProductionStatus)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                >
                  <option value="New">New</option>
                  <option value="Confirmed">Confirmed</option>
                  <option value="Cutting">Cutting</option>
                  <option value="Sewing">Sewing</option>
                  <option value="Fitting">Fitting</option>
                  <option value="Ready">Ready</option>
                  <option value="Delivered">Delivered</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                Fitting & Internal Workshop Notes
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Important reminders: urgent delivery, matching pocket square, button holes color..."
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
              />
            </div>

            <div className="pt-4 flex items-center justify-end gap-3 border-t border-stone-100">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-sm font-medium text-stone-600 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2 text-sm font-semibold text-white bg-[#58111A] hover:bg-[#4A0E17] rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                {orderToEdit ? 'Save Order Updates' : 'Confirm & Save Order'}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Quick Add Customer inline modal */}
      {showAddCustomerModal && (
        <CustomerFormModal
          isOpen={showAddCustomerModal}
          onClose={() => setShowAddCustomerModal(false)}
          onCustomerCreated={(newCust) => {
            setCustomerId(newCust.id);
          }}
        />
      )}

      {/* Local to Premium Guide Modal */}
      {showPremiumModal && (
        <LocalToPremiumModal
          isOpen={showPremiumModal}
          onClose={() => setShowPremiumModal(false)}
          onApplyTier={(tier) => {
            setServiceTier(tier);
            setShowPremiumModal(false);
          }}
        />
      )}

      {/* Voice Dictate Modal */}
      {showDictateModal && (
        <AudioTranscribeModal
          isOpen={showDictateModal}
          onClose={() => setShowDictateModal(false)}
          targetFieldLabel="Order Description"
          onApplyTranscription={(text) => {
            setOrderDescription((prev) => (prev ? `${prev} ${text}` : text));
          }}
        />
      )}
    </>
  );
};
