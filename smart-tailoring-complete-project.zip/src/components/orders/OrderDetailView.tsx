import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductionStatus, PaymentStatus } from '../../types';
import { ProductionStatusBadge, PaymentStatusBadge } from '../common/StatusBadge';
import { ConfirmModal } from '../common/ConfirmModal';
import {
  ArrowLeft,
  Calendar,
  CreditCard,
  Printer,
  Edit,
  Trash2,
  Scissors,
  User,
  Phone,
  Mail,
  MapPin,
  CheckCircle2,
  ChevronRight,
  TrendingUp,
  Share2,
  MessageCircle,
  Copy,
  ExternalLink,
  Check,
  X
} from 'lucide-react';
import { PlatformClient, PublicOrderData } from '../../services/platformClient';

interface OrderDetailViewProps {
  orderId: string;
  onBack: () => void;
  onEditOrder: () => void;
  onRecordPayment: () => void;
}

export const OrderDetailView: React.FC<OrderDetailViewProps> = ({
  orderId,
  onBack,
  onEditOrder,
  onRecordPayment
}) => {
  const {
    getOrder,
    getCustomer,
    getMeasurementProfile,
    updateOrderStatus,
    deleteOrder,
    setPrintOrder,
    getOrderPayments,
    deletePayment,
    formatCurrency,
    setSelectedCustomerId,
    setActiveTab,
    user,
    showToast
  } = useApp();

  const [sharing, setSharing] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [paymentToDelete, setPaymentToDelete] = useState<string | null>(null);
  const [showShareModal, setShowShareModal] = useState(false);
  const [generatedTrackingUrl, setGeneratedTrackingUrl] = useState('');
  const [generatedWhatsAppUrl, setGeneratedWhatsAppUrl] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);

  const order = getOrder(orderId);
  if (!order) {
    return (
      <div className="p-8 text-center">
        <p className="text-stone-500">Order not found.</p>
        <button onClick={onBack} className="mt-4 px-4 py-2 bg-stone-100 rounded-lg text-xs font-semibold">
          Return to Orders
        </button>
      </div>
    );
  }

  const customer = getCustomer(order.customerId);
  const measurement = order.measurementProfileId ? getMeasurementProfile(order.measurementProfileId) : undefined;
  const payments = getOrderPayments(order.id);
  const paymentStatus: PaymentStatus = order.balanceDue <= 0 ? 'Paid' : order.amountPaid > 0 ? 'Partial' : 'Unpaid';

  const statusWorkflow: ProductionStatus[] = [
    'New',
    'Confirmed',
    'Cutting',
    'Sewing',
    'Fitting',
    'Ready',
    'Delivered'
  ];

  const currentStatusIndex = statusWorkflow.indexOf(order.productionStatus);

  const handleStatusChange = (newStatus: ProductionStatus) => {
    updateOrderStatus(order.id, newStatus);
  };

  const handleConfirmDelete = () => {
    deleteOrder(order.id);
    onBack();
  };

  const handleViewCustomer = () => {
    if (customer) {
      setSelectedCustomerId(customer.id);
      setActiveTab('customers');
    }
  };

  const handleShareTracking = async () => {
    setSharing(true);
    try {
      const publicData: PublicOrderData = {
        orderNumber: order.orderNumber,
        tailorId: user?.id || 'atelier',
        tailorBusinessName: user?.businessName || 'Atelier Bespoke',
        tailorOwnerName: user?.ownerName || 'Master Tailor',
        tailorPhone: user?.phone || '',
        tailorCurrency: user?.currency || '₦',
        tailorAddress: user?.address || '',
        bankDetails: user?.address ? `Atelier: ${user.businessName}` : undefined,
        customerName: customer?.fullName || 'Valued Client',
        customerPhone: customer?.phoneNumber || '',
        outfitType: order.outfitType,
        customOutfitType: order.customOutfitType,
        fabricType: order.fabricType,
        fabricColour: order.fabricColour,
        serviceTier: order.serviceTier || 'Standard',
        productionStatus: order.productionStatus,
        orderDescription: order.orderDescription,
        deliveryDate: order.deliveryDate,
        fittingAppointmentDate: order.fittingAppointmentDate,
        totalCost: order.totalCost,
        amountPaid: order.amountPaid,
        balanceDue: order.balanceDue,
        updatedAt: new Date().toISOString()
      };

      await PlatformClient.publishOrder(publicData);
      const trackingUrl = `${window.location.origin}/?track=${encodeURIComponent(order.orderNumber)}`;

      const whatsappText = encodeURIComponent(
        `Hello ${customer?.fullName || 'Client'}, your order #${order.orderNumber} (${order.outfitType}) at ${user?.businessName} is currently "${order.productionStatus}". Track your garment, fitting date, and payment status live here: ${trackingUrl}`
      );

      const phoneClean = customer?.phoneNumber ? customer.phoneNumber.replace(/[^0-9]/g, '') : '';
      const whatsappUrl = phoneClean
        ? `https://wa.me/${phoneClean}?text=${whatsappText}`
        : `https://wa.me/?text=${whatsappText}`;

      setGeneratedTrackingUrl(trackingUrl);
      setGeneratedWhatsAppUrl(whatsappUrl);
      setCopiedLink(false);

      try {
        await navigator.clipboard.writeText(trackingUrl);
        setCopiedLink(true);
      } catch (_) {}

      setShowShareModal(true);
      showToast('Live tracking link created and copied!', 'success');
    } catch (err: any) {
      showToast('Could not publish live tracking: ' + err.message, 'error');
    } finally {
      setSharing(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top action bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 bg-white hover:bg-stone-100 border border-stone-200 rounded-xl text-stone-600 transition-colors cursor-pointer"
            title="Back to Orders"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-2xl font-bold font-serif-display text-stone-900 tracking-tight">
                {order.orderNumber}
              </h1>
              <ProductionStatusBadge status={order.productionStatus} />
              <PaymentStatusBadge status={paymentStatus} />
              {order.serviceTier === 'Royal_VIP' ? (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-900 border border-purple-300">
                  💎 Royal VIP
                </span>
              ) : order.serviceTier === 'Premium' ? (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                  👑 Unaabs Premium
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-medium bg-stone-100 text-stone-700 border border-stone-200">
                  🌟 Standard Local
                </span>
              )}
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              Created {new Date(order.createdAt).toLocaleDateString()} · Promised Delivery: <span className="font-semibold text-stone-800">{new Date(order.deliveryDate).toLocaleDateString()}</span>
              {order.fittingAppointmentDate && (
                <span className="ml-2 text-amber-800 font-semibold">
                  · Fitting: {new Date(order.fittingAppointmentDate).toLocaleDateString()}
                </span>
              )}
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {order.balanceDue > 0 && (
            <button
              onClick={onRecordPayment}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Record Payment</span>
            </button>
          )}

          <button
            onClick={() => setPrintOrder(order)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-stone-50 border border-stone-300 text-stone-700 text-xs font-semibold rounded-xl shadow-2xs transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-stone-500" />
            <span>Print Invoice</span>
          </button>

          <button
            disabled={sharing}
            onClick={handleShareTracking}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
            title="Publish & Share Live Tracking Link with Client on WhatsApp"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>{sharing ? 'Publishing...' : 'Share Tracking (WhatsApp)'}</span>
          </button>

          <button
            onClick={onEditOrder}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            <Edit className="w-3.5 h-3.5 text-stone-500" />
            <span>Edit</span>
          </button>

          <button
            onClick={() => setShowDeleteModal(true)}
            className="p-2 text-stone-400 hover:text-rose-600 rounded-xl hover:bg-rose-50 transition-colors"
            title="Delete Order"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Production Status Progress Flow */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs">
        <h4 className="text-xs font-bold text-stone-400 uppercase tracking-wider mb-3">
          Production Pipeline Stage
        </h4>
        <div className="flex items-center overflow-x-auto pb-2 scrollbar-none gap-2">
          {statusWorkflow.map((st, idx) => {
            const isCompleted = currentStatusIndex >= idx;
            const isCurrent = order.productionStatus === st;
            return (
              <button
                key={st}
                onClick={() => handleStatusChange(st)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                  isCurrent
                    ? 'bg-[#58111A] text-white font-bold shadow-xs'
                    : isCompleted
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
                    : 'bg-stone-50 text-stone-500 border border-stone-200 hover:bg-stone-100'
                }`}
              >
                {isCompleted && !isCurrent ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <span className={`w-2 h-2 rounded-full ${isCurrent ? 'bg-amber-300' : 'bg-stone-300'}`} />
                )}
                <span>{st}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Grid: Details & Accounting */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Customer & Garment (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Customer Card */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold text-stone-400 uppercase tracking-wider flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-stone-500" />
                <span>Client Information</span>
              </h3>
              <button
                onClick={handleViewCustomer}
                className="text-xs text-[#58111A] hover:underline font-semibold flex items-center gap-1"
              >
                <span>View Full Profile</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>

            <div className="flex items-start justify-between">
              <div>
                <p className="text-base font-bold text-stone-900">{customer?.fullName || 'Walk-in Client'}</p>
                <div className="mt-1 space-y-0.5 text-xs text-stone-600">
                  {customer?.phoneNumber && (
                    <p className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-stone-400" />
                      {customer.phoneNumber}
                    </p>
                  )}
                  {customer?.email && (
                    <p className="flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-stone-400" />
                      {customer.email}
                    </p>
                  )}
                  {customer?.address && (
                    <p className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-stone-400" />
                      {customer.address}
                    </p>
                  )}
                </div>
              </div>

              {customer?.notes && (
                <div className="max-w-[200px] p-2 bg-amber-50/70 rounded-lg border border-amber-200/60 text-[11px] text-amber-900">
                  <span className="font-bold block">Client Preference:</span>
                  <p className="line-clamp-2">{customer.notes}</p>
                </div>
              )}
            </div>
          </div>

          {/* Garment & Fabric Info */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
            <h3 className="text-xs font-bold text-stone-400 uppercase tracking-wider flex items-center gap-1.5">
              <Scissors className="w-3.5 h-3.5 text-stone-500" />
              <span>Garment & Fabric Specifications</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3 bg-stone-50 rounded-xl">
                <span className="text-[10px] text-stone-500 uppercase font-semibold block">Outfit Type</span>
                <span className="text-sm font-bold text-[#58111A]">
                  {order.outfitType === 'Custom' ? (order.customOutfitType || 'Custom Outfit') : order.outfitType}
                </span>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl">
                <span className="text-[10px] text-stone-500 uppercase font-semibold block">Fabric Material</span>
                <span className="text-sm font-bold text-stone-800">
                  {order.fabricType || 'Not specified'}
                </span>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl">
                <span className="text-[10px] text-stone-500 uppercase font-semibold block">Fabric Colour</span>
                <span className="text-sm font-bold text-stone-800">
                  {order.fabricColour || 'Not specified'}
                </span>
              </div>
            </div>

            <div className="text-xs text-stone-600 bg-stone-50/60 p-3 rounded-xl border border-stone-200/60">
              <span className="font-semibold text-stone-800">Fabric Source: </span>
              {order.fabricSuppliedByCustomer ? (
                <span className="text-stone-700">Supplied by Client (Zero fabric cost to studio)</span>
              ) : (
                <span className="text-stone-700">Procured by Studio (Fabric Cost: {formatCurrency(order.fabricCost)})</span>
              )}
            </div>

            {order.orderDescription && (
              <div>
                <span className="text-xs font-bold text-stone-700 block mb-1">Style Details & Customization:</span>
                <p className="text-xs text-stone-600 leading-relaxed bg-stone-50 p-3 rounded-xl">
                  {order.orderDescription}
                </p>
              </div>
            )}

            {order.notes && (
              <div className="p-3 bg-amber-50/80 rounded-xl border border-amber-200 text-xs text-amber-900">
                <span className="font-bold block mb-0.5">Workshop / Fitting Notes:</span>
                <p>{order.notes}</p>
              </div>
            )}
          </div>

          {/* Measurements Profile Breakdown */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold text-stone-400 uppercase tracking-wider flex items-center gap-1.5">
                <Scissors className="w-3.5 h-3.5 text-stone-500" />
                <span>Anatomical Measurements</span>
              </h3>
              {measurement && (
                <span className="text-xs font-medium text-stone-600">
                  {measurement.profileName} ({measurement.unit})
                </span>
              )}
            </div>

            {measurement ? (
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2 text-xs">
                {Object.entries(measurement.measurements)
                  .filter(([_, val]) => typeof val === 'number' && val > 0)
                  .map(([key, val]) => (
                    <div key={key} className="p-2 bg-stone-50 rounded-lg text-center border border-stone-100">
                      <span className="block text-[10px] text-stone-500 capitalize truncate">
                        {key.replace(/([A-Z])/g, ' $1')}
                      </span>
                      <span className="font-bold text-stone-900 font-mono text-sm">
                        {val}
                        <span className="text-[10px] text-stone-400 font-sans ml-0.5">
                          {measurement.unit === 'inches' ? '"' : 'cm'}
                        </span>
                      </span>
                    </div>
                  ))}
              </div>
            ) : (
              <p className="text-xs text-stone-400 italic">No measurement profile attached to this order.</p>
            )}
          </div>
        </div>

        {/* Right Column: Pricing & Financials (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Financial Breakdown Card */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
            <h3 className="text-xs font-bold text-stone-400 uppercase tracking-wider flex items-center justify-between">
              <span>Financial Ledger</span>
              <PaymentStatusBadge status={paymentStatus} size="sm" />
            </h3>

            {/* Big numbers summary */}
            <div className="bg-[#58111A] text-white p-4 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-amber-200/80 font-medium">Selling Price:</span>
                <span className="text-xl font-bold font-mono">{formatCurrency(order.sellingPrice)}</span>
              </div>
              <div className="flex items-center justify-between border-t border-white/10 pt-2 text-emerald-300">
                <span className="text-xs font-medium">Amount Paid:</span>
                <span className="text-base font-bold font-mono">{formatCurrency(order.amountPaid)}</span>
              </div>
              <div className="flex items-center justify-between border-t border-white/10 pt-2">
                <span className="text-xs font-medium text-amber-300">Balance Due:</span>
                <span className="text-lg font-bold font-mono text-amber-300">{formatCurrency(order.balanceDue)}</span>
              </div>
            </div>

            {/* Cost & Profit Analysis */}
            <div className="p-3.5 bg-stone-50 rounded-xl space-y-2 text-xs">
              <div className="flex items-center justify-between text-stone-600">
                <span>Fabric Cost:</span>
                <span className="font-mono">{formatCurrency(order.fabricCost)}</span>
              </div>
              <div className="flex items-center justify-between text-stone-600">
                <span>Labour Cost:</span>
                <span className="font-mono">{formatCurrency(order.labourCost)}</span>
              </div>
              <div className="flex items-center justify-between text-stone-600">
                <span>Trims & Material Cost:</span>
                <span className="font-mono">{formatCurrency(order.additionalMaterialCost)}</span>
              </div>
              <div className="flex items-center justify-between text-stone-600">
                <span>Other Expenses:</span>
                <span className="font-mono">{formatCurrency(order.otherCost)}</span>
              </div>

              <div className="border-t border-stone-200 pt-2 flex items-center justify-between font-semibold text-stone-800">
                <span>Total Production Cost:</span>
                <span className="font-mono">{formatCurrency(order.totalCost)}</span>
              </div>

              <div className="border-t border-stone-200 pt-2 flex items-center justify-between font-bold text-emerald-800">
                <span className="flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Studio Net Profit:</span>
                </span>
                <span className="font-mono text-sm">{formatCurrency(order.profit)}</span>
              </div>
            </div>
          </div>

          {/* Payment Receipts List */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-stone-400 uppercase tracking-wider">
                Installment Receipts ({payments.length})
              </h3>
              {order.balanceDue > 0 && (
                <button
                  onClick={onRecordPayment}
                  className="text-xs text-emerald-700 hover:text-emerald-800 font-bold cursor-pointer"
                >
                  + Add Payment
                </button>
              )}
            </div>

            {payments.length === 0 ? (
              <p className="text-xs text-stone-400 py-3 text-center">No payments logged yet.</p>
            ) : (
              <div className="space-y-2">
                {payments.map((p, idx) => (
                  <div
                    key={p.id}
                    className="p-3 bg-stone-50 rounded-xl border border-stone-100 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-stone-800 font-mono">{formatCurrency(p.amount)}</span>
                        <span className="text-[10px] text-stone-500 font-medium bg-stone-200/80 px-1.5 py-0.5 rounded">
                          {p.paymentMethod}
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 mt-0.5">
                        {p.paymentDate} {p.note && `· "${p.note}"`}
                      </p>
                    </div>

                    <button
                      onClick={() => setPaymentToDelete(p.id)}
                      className="text-stone-300 hover:text-rose-600 p-1 transition-colors"
                      title="Delete payment record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Delete Order Confirmation */}
      <ConfirmModal
        isOpen={showDeleteModal}
        title="Delete Order?"
        message={`Are you sure you want to permanently delete order ${order.orderNumber}? This will also delete all payment history associated with this order.`}
        confirmLabel="Delete Order"
        onConfirm={handleConfirmDelete}
        onCancel={() => setShowDeleteModal(false)}
      />

      {/* Delete Payment Confirmation */}
      <ConfirmModal
        isOpen={!!paymentToDelete}
        title="Delete Payment Record?"
        message="Are you sure you want to delete this payment record? The order balance will automatically increase by the payment amount."
        confirmLabel="Delete Payment"
        onConfirm={() => {
          if (paymentToDelete) {
            deletePayment(paymentToDelete);
            setPaymentToDelete(null);
          }
        }}
        onCancel={() => setPaymentToDelete(null)}
      />

      {/* Share Live Tracking Link Modal */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden border border-stone-200">
            <div className="bg-[#58111A] text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-400/20 text-amber-300 flex items-center justify-center">
                  <Share2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-serif-display font-bold text-base">Client Live Tracking Link</h3>
                  <p className="text-[11px] text-amber-200/80">Order #{order.orderNumber} for {customer?.fullName || 'Client'}</p>
                </div>
              </div>
              <button
                onClick={() => setShowShareModal(false)}
                className="text-stone-300 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-xs text-stone-600 leading-relaxed">
                Every tailor can share a personalized live tracking link with their clients. The client can open it on any smartphone without an account to see their garment's real-time production stage, delivery date, and payment balance.
              </p>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
                  Live Tracking URL
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={generatedTrackingUrl}
                    className="flex-1 px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-mono text-stone-800 select-all"
                  />
                  <button
                    onClick={async () => {
                      await navigator.clipboard.writeText(generatedTrackingUrl);
                      setCopiedLink(true);
                      showToast('Copied to clipboard!', 'success');
                    }}
                    className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ${
                      copiedLink
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-stone-800 hover:bg-stone-900 text-white'
                    }`}
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedLink ? 'Copied!' : 'Copy Link'}</span>
                  </button>
                </div>
              </div>

              <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {generatedWhatsAppUrl && (
                  <a
                    href={generatedWhatsAppUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors shadow-xs"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Send via WhatsApp</span>
                  </a>
                )}
                <a
                  href={generatedTrackingUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-center gap-2 px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold rounded-xl transition-colors border border-stone-200"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Preview Client Portal</span>
                </a>
              </div>
            </div>

            <div className="p-4 bg-stone-50 border-t border-stone-200 flex justify-end">
              <button
                onClick={() => setShowShareModal(false)}
                className="px-4 py-2 bg-white hover:bg-stone-100 text-stone-700 text-xs font-semibold rounded-xl border border-stone-200 transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
