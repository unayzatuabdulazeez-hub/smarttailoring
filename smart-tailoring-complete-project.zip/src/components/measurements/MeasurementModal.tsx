import React, { useState, useEffect } from 'react';
import { Customer, MeasurementProfile, MeasurementUnit, MeasurementData } from '../../types';
import { useApp } from '../../context/AppContext';
import { X, Ruler, Plus, Trash2, Calendar, FileText, Info } from 'lucide-react';

interface MeasurementModalProps {
  isOpen: boolean;
  onClose: () => void;
  customerId?: string;
  measurementToEdit?: MeasurementProfile | null;
  onMeasurementCreated?: (created: MeasurementProfile) => void;
}

export const MeasurementModal: React.FC<MeasurementModalProps> = ({
  isOpen,
  onClose,
  customerId: initialCustomerId,
  measurementToEdit,
  onMeasurementCreated
}) => {
  const { customers, user, addMeasurementProfile, updateMeasurementProfile } = useApp();

  const [customerId, setCustomerId] = useState<string>(initialCustomerId || '');
  const [profileName, setProfileName] = useState('');
  const [unit, setUnit] = useState<MeasurementUnit>(user?.defaultUnit || 'inches');
  const [notes, setNotes] = useState('');
  const [measurements, setMeasurements] = useState<MeasurementData>({});
  const [customFields, setCustomFields] = useState<{ name: string; value: string }[]>([]);
  const [error, setError] = useState('');

  useEffect(() => {
    if (measurementToEdit) {
      setCustomerId(measurementToEdit.customerId);
      setProfileName(measurementToEdit.profileName);
      setUnit(measurementToEdit.unit);
      setNotes(measurementToEdit.notes || '');
      setMeasurements({ ...measurementToEdit.measurements });
      // Check for custom keys
      const standardKeys = [
        'shoulder', 'bust', 'waist', 'hip', 'sleeveLength', 'armhole', 'bicep',
        'wrist', 'blouseLength', 'gownLength', 'trouserLength', 'thigh', 'knee',
        'ankle', 'neck', 'chest', 'backLength'
      ];
      const custom: { name: string; value: string }[] = [];
      Object.entries(measurementToEdit.measurements).forEach(([k, v]) => {
        if (!standardKeys.includes(k) && v !== undefined) {
          custom.push({ name: k, value: String(v) });
        }
      });
      setCustomFields(custom);
    } else {
      setCustomerId(initialCustomerId || (customers[0]?.id || ''));
      setProfileName('');
      setUnit(user?.defaultUnit || 'inches');
      setNotes('');
      setMeasurements({});
      setCustomFields([]);
    }
    setError('');
  }, [measurementToEdit, initialCustomerId, customers, user, isOpen]);

  if (!isOpen) return null;

  const handleFieldChange = (field: keyof MeasurementData, val: string) => {
    const num = val === '' ? undefined : parseFloat(val);
    setMeasurements(prev => ({
      ...prev,
      [field]: isNaN(num as number) ? undefined : num
    }));
  };

  const addCustomField = () => {
    setCustomFields(prev => [...prev, { name: '', value: '' }]);
  };

  const removeCustomField = (index: number) => {
    setCustomFields(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleCustomFieldChange = (index: number, key: 'name' | 'value', val: string) => {
    setCustomFields(prev => {
      const copy = [...prev];
      copy[index][key] = val;
      return copy;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerId) {
      setError('Please select or specify a customer.');
      return;
    }
    if (!profileName.trim()) {
      setError('Please enter a profile name (e.g. Kaftan, Wedding Jalabiya, Fitted Suit).');
      return;
    }

    // Merge custom fields
    const finalMeasurements: MeasurementData = { ...measurements };
    customFields.forEach(cf => {
      if (cf.name.trim() && cf.value.trim()) {
        const parsed = parseFloat(cf.value);
        if (!isNaN(parsed)) {
          finalMeasurements[cf.name.trim()] = parsed;
        }
      }
    });

    if (measurementToEdit) {
      updateMeasurementProfile(measurementToEdit.id, {
        customerId,
        profileName: profileName.trim(),
        unit,
        measurements: finalMeasurements,
        notes: notes.trim()
      });
      onClose();
    } else {
      const created = addMeasurementProfile({
        customerId,
        profileName: profileName.trim(),
        unit,
        measurements: finalMeasurements,
        notes: notes.trim()
      });
      if (onMeasurementCreated) {
        onMeasurementCreated(created);
      }
      onClose();
    }
  };

  const standardMeasurementInputs: { key: keyof MeasurementData; label: string; placeholder: string; category: string }[] = [
    // Upper Body
    { key: 'shoulder', label: 'Shoulder', placeholder: '15.5', category: 'Upper Body' },
    { key: 'bust', label: 'Bust / Chest', placeholder: '38', category: 'Upper Body' },
    { key: 'waist', label: 'Waist', placeholder: '32', category: 'Upper Body' },
    { key: 'hip', label: 'Hip', placeholder: '42', category: 'Upper Body' },
    { key: 'neck', label: 'Neck Circumference', placeholder: '15.5', category: 'Upper Body' },
    { key: 'chest', label: 'Chest (Men)', placeholder: '40', category: 'Upper Body' },
    { key: 'backLength', label: 'Back Length', placeholder: '16.5', category: 'Upper Body' },

    // Sleeves & Arms
    { key: 'sleeveLength', label: 'Sleeve Length', placeholder: '23.5', category: 'Arms & Sleeves' },
    { key: 'armhole', label: 'Armhole', placeholder: '17', category: 'Arms & Sleeves' },
    { key: 'bicep', label: 'Bicep / Round Sleeve', placeholder: '13', category: 'Arms & Sleeves' },
    { key: 'wrist', label: 'Wrist / Cuff', placeholder: '7.5', category: 'Arms & Sleeves' },

    // Lengths & Lower Body
    { key: 'blouseLength', label: 'Blouse / Top Length', placeholder: '25', category: 'Garment Lengths' },
    { key: 'gownLength', label: 'Gown / Kaftan Length', placeholder: '58', category: 'Garment Lengths' },
    { key: 'trouserLength', label: 'Trouser Length', placeholder: '41', category: 'Trouser / Lower' },
    { key: 'thigh', label: 'Thigh (Lap)', placeholder: '25', category: 'Trouser / Lower' },
    { key: 'knee', label: 'Knee', placeholder: '18', category: 'Trouser / Lower' },
    { key: 'ankle', label: 'Ankle / Bottom Hem', placeholder: '14', category: 'Trouser / Lower' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden border border-stone-200 my-8">
        {/* Header */}
        <div className="bg-[#58111A] text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Ruler className="w-5 h-5 text-amber-300" />
            <h3 className="font-serif-display font-bold text-lg">
              {measurementToEdit ? 'Edit Measurement Profile' : 'New Measurement Profile'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-stone-300 hover:text-white p-1 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-medium">
              {error}
            </div>
          )}

          {/* Top Profile Config */}
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
            <div className="sm:col-span-5">
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                Customer *
              </label>
              <select
                required
                disabled={!!measurementToEdit}
                value={customerId}
                onChange={(e) => setCustomerId(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
              >
                <option value="">-- Select Customer --</option>
                {customers.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.fullName} ({c.phoneNumber})
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-4">
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                Profile Name *
              </label>
              <input
                type="text"
                required
                value={profileName}
                onChange={(e) => setProfileName(e.target.value)}
                placeholder="e.g. Kaftan — Oct 2026"
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
              />
            </div>

            <div className="sm:col-span-3">
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                Measurement Unit
              </label>
              <div className="flex bg-stone-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setUnit('inches')}
                  className={`flex-1 py-1 text-xs font-semibold rounded-lg transition-colors ${
                    unit === 'inches' ? 'bg-white text-[#58111A] shadow-xs' : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Inches (")
                </button>
                <button
                  type="button"
                  onClick={() => setUnit('cm')}
                  className={`flex-1 py-1 text-xs font-semibold rounded-lg transition-colors ${
                    unit === 'cm' ? 'bg-white text-[#58111A] shadow-xs' : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  cm
                </button>
              </div>
            </div>
          </div>

          {/* Quick Info bar */}
          <div className="flex items-center gap-2 p-2.5 bg-amber-50/70 border border-amber-200/70 rounded-xl text-xs text-amber-900">
            <Info className="w-4 h-4 text-amber-600 shrink-0" />
            <span>Enter anatomical measurements in <strong>{unit}</strong>. Leave any unused field blank.</span>
          </div>

          {/* Input Grid */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-stone-400 uppercase tracking-wider border-b border-stone-200 pb-1">
              Body Dimensions ({unit})
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {standardMeasurementInputs.map(item => (
                <div key={item.key} className="bg-stone-50/70 p-2.5 rounded-xl border border-stone-200 focus-within:border-[#58111A] focus-within:bg-white transition-all">
                  <label className="block text-[11px] font-semibold text-stone-700 mb-1 truncate">
                    {item.label}
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      value={measurements[item.key] ?? ''}
                      onChange={(e) => handleFieldChange(item.key, e.target.value)}
                      placeholder={item.placeholder}
                      className="w-full pr-6 py-1 bg-transparent text-sm font-bold font-mono text-stone-900 focus:outline-none"
                    />
                    <span className="absolute right-1 top-1/2 -translate-y-1/2 text-[10px] text-stone-400 font-sans">
                      {unit === 'inches' ? 'in' : 'cm'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Custom Measurement Fields */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between border-b border-stone-200 pb-1">
              <h4 className="text-xs font-bold text-stone-400 uppercase tracking-wider">
                Specialized / Custom Measurements
              </h4>
              <button
                type="button"
                onClick={addCustomField}
                className="inline-flex items-center gap-1 text-xs text-[#58111A] hover:text-[#4A0E17] font-semibold cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Custom Field</span>
              </button>
            </div>

            {customFields.map((cf, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <input
                  type="text"
                  value={cf.name}
                  onChange={(e) => handleCustomFieldChange(idx, 'name', e.target.value)}
                  placeholder="e.g. Cap circumference, Waist to Knee"
                  className="flex-1 px-3 py-1.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900"
                />
                <input
                  type="number"
                  step="0.1"
                  value={cf.value}
                  onChange={(e) => handleCustomFieldChange(idx, 'value', e.target.value)}
                  placeholder="Value"
                  className="w-24 px-3 py-1.5 bg-stone-50 border border-stone-300 rounded-xl text-xs font-mono font-bold text-stone-900"
                />
                <button
                  type="button"
                  onClick={() => removeCustomField(idx)}
                  className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          {/* Measurement Notes */}
          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
              Fit & Tailoring Notes
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Prefers loose around arms, extra 2 inch seam allowance, posture adjustment..."
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-stone-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-stone-600 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-sm font-semibold text-white bg-[#58111A] hover:bg-[#4A0E17] rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              {measurementToEdit ? 'Save Changes' : 'Save Measurement Profile'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
