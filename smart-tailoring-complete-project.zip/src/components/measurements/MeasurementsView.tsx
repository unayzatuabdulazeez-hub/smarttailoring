import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { MeasurementProfile } from '../../types';
import { EmptyState } from '../common/EmptyState';
import { MeasurementModal } from './MeasurementModal';
import { ConfirmModal } from '../common/ConfirmModal';
import {
  Ruler,
  Search,
  Plus,
  Copy,
  Edit,
  Trash2,
  User,
  Calendar,
  Layers,
  ChevronRight
} from 'lucide-react';

interface MeasurementsViewProps {
  onSelectCustomer: (customerId: string) => void;
}

export const MeasurementsView: React.FC<MeasurementsViewProps> = ({ onSelectCustomer }) => {
  const {
    measurements,
    customers,
    duplicateMeasurementProfile,
    deleteMeasurementProfile,
    globalSearch
  } = useApp();

  const [search, setSearch] = useState('');
  const [customerFilter, setCustomerFilter] = useState<string>('all');
  const [unitFilter, setUnitFilter] = useState<string>('all');

  // Modals
  const [showModal, setShowModal] = useState(false);
  const [profileToEdit, setProfileToEdit] = useState<MeasurementProfile | null>(null);
  const [profileToDelete, setProfileToDelete] = useState<string | null>(null);

  const customerMap = useMemo(() => {
    const map = new Map<string, string>();
    customers.forEach(c => map.set(c.id, c.fullName));
    return map;
  }, [customers]);

  const activeSearch = globalSearch || search;

  const filteredMeasurements = useMemo(() => {
    return measurements.filter(m => {
      const custName = customerMap.get(m.customerId) || '';
      const matchesSearch =
        !activeSearch ||
        m.profileName.toLowerCase().includes(activeSearch.toLowerCase()) ||
        custName.toLowerCase().includes(activeSearch.toLowerCase()) ||
        (m.notes && m.notes.toLowerCase().includes(activeSearch.toLowerCase()));

      if (!matchesSearch) return false;

      if (customerFilter !== 'all' && m.customerId !== customerFilter) {
        return false;
      }

      if (unitFilter !== 'all' && m.unit !== unitFilter) {
        return false;
      }

      return true;
    });
  }, [measurements, activeSearch, customerFilter, unitFilter, customerMap]);

  return (
    <div className="space-y-6">
      {/* Top action bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-serif-display text-stone-900 tracking-tight">
            Measurement Vault
          </h1>
          <p className="text-xs text-stone-500 mt-0.5">
            Organized anatomical measurement profiles across all clients ({filteredMeasurements.length} profiles)
          </p>
        </div>

        <button
          onClick={() => {
            setProfileToEdit(null);
            setShowModal(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#58111A] hover:bg-[#4A0E17] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Measurement Profile</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by profile name (Kaftan, Jalabiya) or client..."
              className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>

          <div className="sm:col-span-4">
            <select
              value={customerFilter}
              onChange={(e) => setCustomerFilter(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            >
              <option value="all">All Clients</option>
              {customers.map(c => (
                <option key={c.id} value={c.id}>{c.fullName}</option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-2">
            <select
              value={unitFilter}
              onChange={(e) => setUnitFilter(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            >
              <option value="all">All Units</option>
              <option value="inches">Inches (")</option>
              <option value="cm">Centimeters (cm)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Profiles Grid */}
      {filteredMeasurements.length === 0 ? (
        <EmptyState
          icon={Ruler}
          title={measurements.length === 0 ? "No measurements stored yet" : "No measurements match your filters"}
          description={
            measurements.length === 0
              ? "Create your first client measurement profile with complete shoulder, bust, waist, and length measurements."
              : "Try adjusting your search keywords or resetting filters."
          }
          actionLabel={measurements.length === 0 ? "Take Measurements" : undefined}
          onAction={measurements.length === 0 ? () => { setProfileToEdit(null); setShowModal(true); } : undefined}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMeasurements.map((m) => {
            const customerName = customerMap.get(m.customerId) || 'Unknown Client';

            return (
              <div
                key={m.id}
                className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs hover:border-[#58111A]/40 hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <h3 className="font-bold text-stone-900 text-sm font-serif-display">
                        {m.profileName}
                      </h3>
                      <button
                        onClick={() => onSelectCustomer(m.customerId)}
                        className="text-xs text-[#58111A] hover:underline font-semibold flex items-center gap-1 mt-0.5"
                      >
                        <User className="w-3 h-3 text-[#58111A]" />
                        <span>{customerName}</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => duplicateMeasurementProfile(m.id)}
                        className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100 transition-colors"
                        title="Duplicate Profile"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          setProfileToEdit(m);
                          setShowModal(true);
                        }}
                        className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100 transition-colors"
                        title="Edit Profile"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setProfileToDelete(m.id)}
                        className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                        title="Delete Profile"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Anatomical values preview */}
                  <div className="grid grid-cols-3 gap-2 text-xs pt-2">
                    {Object.entries(m.measurements)
                      .filter(([_, val]) => typeof val === 'number' && val > 0)
                      .slice(0, 9)
                      .map(([key, val]) => (
                        <div key={key} className="bg-stone-50 p-1.5 rounded-lg border border-stone-100">
                          <span className="block text-[10px] text-stone-500 capitalize truncate">
                            {key.replace(/([A-Z])/g, ' $1')}
                          </span>
                          <span className="font-bold text-stone-900 font-mono text-xs">
                            {val}
                            <span className="text-[9px] text-stone-400 ml-0.5">{m.unit === 'inches' ? '"' : 'cm'}</span>
                          </span>
                        </div>
                      ))}
                  </div>

                  {m.notes && (
                    <p className="text-[11px] text-stone-500 italic mt-3 line-clamp-2 border-t border-stone-100 pt-2">
                      "{m.notes}"
                    </p>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-400 font-medium">
                  <span>Unit: <strong className="text-stone-600">{m.unit}</strong></span>
                  <span>{new Date(m.recordedAt).toLocaleDateString()}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Measurement Modal */}
      {showModal && (
        <MeasurementModal
          isOpen={showModal}
          onClose={() => {
            setShowModal(false);
            setProfileToEdit(null);
          }}
          measurementToEdit={profileToEdit}
        />
      )}

      {/* Delete Confirmation */}
      <ConfirmModal
        isOpen={!!profileToDelete}
        title="Delete Measurement Profile?"
        message="Are you sure you want to delete this measurement profile? Active orders will keep their historical record."
        confirmLabel="Delete Profile"
        onConfirm={() => {
          if (profileToDelete) {
            deleteMeasurementProfile(profileToDelete);
            setProfileToDelete(null);
          }
        }}
        onCancel={() => setProfileToDelete(null)}
      />
    </div>
  );
};
