import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  Square,
  Copy,
  Check,
  X,
  FileAudio,
  Sparkles,
  Loader2,
  RefreshCw,
  ArrowRight
} from 'lucide-react';

interface AudioTranscribeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyTranscription?: (text: string) => void;
  targetFieldLabel?: string;
}

export const AudioTranscribeModal: React.FC<AudioTranscribeModalProps> = ({
  isOpen,
  onClose,
  onApplyTranscription,
  targetFieldLabel
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  const handleStopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch (_) {}
    }
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setIsRecording(false);
  };

  useEffect(() => {
    if (!isOpen) {
      handleStopRecording();
      setTranscription('');
      setError('');
      setRecordingDuration(0);
    }
    return () => {
      handleStopRecording();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  async function processAndTranscribe(audioBlob: Blob, mimeType: string) {
    setIsTranscribing(true);
    setError('');

    try {
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];

        const response = await fetch('/api/transcribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            audioData: base64Data,
            mimeType: mimeType || 'audio/webm'
          })
        });

        if (!response.ok) {
          const errData = await response.json().catch(() => ({}));
          throw new Error(errData.error || `Server responded with ${response.status}`);
        }

        const data = await response.json();
        setTranscription(data.transcription || 'No transcription returned.');
        setIsTranscribing(false);
      };
    } catch (err: any) {
      console.error('Transcription failed:', err);
      setError(err.message || 'Failed to transcribe audio. Please try again.');
      setIsTranscribing(false);
    }
  }

  const handleStartRecording = async () => {
    setError('');
    setTranscription('');
    audioChunksRef.current = [];

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/mp4'
      });
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        stream.getTracks().forEach((track) => track.stop());
        const audioBlob = new Blob(audioChunksRef.current, {
          type: mediaRecorder.mimeType || 'audio/webm'
        });
        await processAndTranscribe(audioBlob, mediaRecorder.mimeType || 'audio/webm');
      };

      mediaRecorder.start(250);
      setIsRecording(true);
      setRecordingDuration(0);

      timerRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.error('Microphone access error:', err);
      setError('Could not access microphone. Please allow microphone permissions in your browser.');
    }
  };

  const handleCopy = () => {
    if (transcription) {
      navigator.clipboard.writeText(transcription);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleApply = () => {
    if (onApplyTranscription && transcription) {
      onApplyTranscription(transcription);
      onClose();
    }
  };

  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const remainder = sec % 60;
    return `${mins}:${remainder < 10 ? '0' : ''}${remainder}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden border border-stone-200">
        {/* Header */}
        <div className="bg-[#58111A] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center">
              <FileAudio className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-serif-display font-bold text-lg leading-tight">
                Voice Audio Transcribe
              </h3>
              <p className="text-[11px] text-amber-200/80">
                Powered by model <span className="font-mono font-semibold">gemini-3.5-transcribe</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-stone-300 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800">
              {error}
            </div>
          )}

          {/* Recording Status / Controller */}
          <div className="bg-stone-50 border border-stone-200 rounded-2xl p-6 text-center space-y-4">
            {isRecording ? (
              <div className="space-y-3">
                <div className="relative inline-flex items-center justify-center">
                  <span className="w-16 h-16 rounded-full bg-rose-500/20 animate-ping absolute" />
                  <div className="w-16 h-16 rounded-full bg-rose-600 text-white flex items-center justify-center relative shadow-md">
                    <Mic className="w-8 h-8" />
                  </div>
                </div>

                <div>
                  <span className="font-mono text-xl font-bold text-rose-600 block">
                    {formatSeconds(recordingDuration)}
                  </span>
                  <p className="text-xs text-stone-600 mt-1">
                    Recording spoken tailoring notes...
                  </p>
                </div>

                <button
                  onClick={handleStopRecording}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>Stop & Transcribe</span>
                </button>
              </div>
            ) : isTranscribing ? (
              <div className="py-6 space-y-3">
                <Loader2 className="w-10 h-10 text-[#58111A] animate-spin mx-auto" />
                <p className="text-xs font-semibold text-stone-700">
                  Transcribing with gemini-3.5-transcribe...
                </p>
                <p className="text-[11px] text-stone-400">
                  Extracting tailoring terms, measurements, and customer notes
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="w-14 h-14 rounded-full bg-[#58111A]/10 text-[#58111A] flex items-center justify-center mx-auto">
                  <Mic className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-stone-900">
                    Dictate Tailoring Notes
                  </h4>
                  <p className="text-xs text-stone-500 max-w-sm mx-auto mt-0.5">
                    Speak client measurements, fitting notes, fabric specs, or special embroidery requests into your microphone.
                  </p>
                </div>

                <button
                  onClick={handleStartRecording}
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#58111A] hover:bg-[#4A0E17] text-white rounded-xl text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                >
                  <Mic className="w-4 h-4" />
                  <span>Start Microphone Recording</span>
                </button>
              </div>
            )}
          </div>

          {/* Transcription Results Card */}
          {transcription && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-stone-400 uppercase tracking-wider">
                  Accurate Spoken Transcription
                </span>
                <button
                  onClick={handleCopy}
                  className="inline-flex items-center gap-1 text-xs text-[#58111A] hover:underline font-semibold cursor-pointer"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-600">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Text</span>
                    </>
                  )}
                </button>
              </div>

              <div className="p-4 bg-white border border-stone-200 rounded-2xl shadow-2xs">
                <p className="text-sm text-stone-800 leading-relaxed whitespace-pre-wrap">
                  {transcription}
                </p>
              </div>

              {onApplyTranscription && (
                <div className="pt-2 flex justify-end">
                  <button
                    onClick={handleApply}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    <span>Insert into {targetFieldLabel || 'Form'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Quick Guidance / Example Phrases */}
          <div className="p-3 bg-amber-50/70 border border-amber-200/60 rounded-xl text-[11px] text-amber-900 space-y-1">
            <span className="font-bold flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Dictation Tips for Master Tailors:</span>
            </span>
            <p className="text-amber-800/90 leading-relaxed">
              Try saying: "Bust 38, Waist 32, Hip 44, Gown length 60 inches. Client prefers loose sleeves with gold buttons."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
