import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  PhoneOff,
  Sparkles,
  Volume2,
  X,
  Radio,
  Scissors,
  Loader2,
  AlertCircle
} from 'lucide-react';

interface LiveVoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LiveVoiceAssistantModal: React.FC<LiveVoiceAssistantModalProps> = ({
  isOpen,
  onClose
}) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [captions, setCaptions] = useState<string>('');
  const [error, setError] = useState<string>('');

  const wsRef = useRef<WebSocket | null>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const isMutedRef = useRef(false);

  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  useEffect(() => {
    if (isOpen) {
      startLiveSession();
    } else {
      endLiveSession();
    }
    return () => {
      endLiveSession();
    };
  }, [isOpen]);

  async function startLiveSession() {
    setError('');
    setIsConnecting(true);
    setCaptions('Connecting to Unaabs Tailoring Voice Assistant (gemini-3.8-live)...');

    try {
      // 1. Initialize microphone stream
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        }
      });
      mediaStreamRef.current = stream;

      // 2. Output AudioContext (24kHz as required by Gemini Live output)
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      outputAudioContextRef.current = new AudioCtx({ sampleRate: 24000 });
      nextStartTimeRef.current = outputAudioContextRef.current.currentTime;

      // 3. Connect WebSocket to backend proxy
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/api/live-stream`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log('Connected to Live API WebSocket');
        setIsConnected(true);
        setIsConnecting(false);
        setCaptions('Voice session active. Speak freely — ask about measurements, fabrics, pricing, or styling...');
        startAudioCapture(stream);
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === 'audio' && msg.data) {
            setIsSpeaking(true);
            playAudioChunk(msg.data);
          } else if (msg.type === 'text' && msg.data) {
            setCaptions((prev) => `${prev} ${msg.data}`);
          } else if (msg.type === 'interrupted') {
            stopAudioPlayback();
            setIsSpeaking(false);
          } else if (msg.type === 'turnComplete') {
            setIsSpeaking(false);
          } else if (msg.type === 'error') {
            setError(msg.message || 'Live session error');
          }
        } catch (err) {
          console.error('Error handling message from Live API:', err);
        }
      };

      ws.onerror = (err) => {
        console.error('WebSocket error:', err);
        setError('Connection to Live voice server failed. Please check network.');
        setIsConnecting(false);
      };

      ws.onclose = () => {
        setIsConnected(false);
        setIsConnecting(false);
      };
    } catch (err: any) {
      console.error('Failed to start Live session:', err);
      setError(err.message || 'Could not access microphone.');
      setIsConnecting(false);
    }
  };

  function startAudioCapture(stream: MediaStream) {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const inputCtx = new AudioCtx();
      inputAudioContextRef.current = inputCtx;

      const source = inputCtx.createMediaStreamSource(stream);
      // Buffer size 2048
      const processor = inputCtx.createScriptProcessor(2048, 1, 1);
      processorRef.current = processor;

      processor.onaudioprocess = (e) => {
        if (isMutedRef.current || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) {
          return;
        }

        const inputData = e.inputBuffer.getChannelData(0);
        // Resample inputData to 16000Hz PCM
        const pcm16Data = downsampleAndConvertToPCM16(inputData, inputCtx.sampleRate, 16000);
        if (pcm16Data.length > 0) {
          const base64Audio = arrayBufferToBase64(pcm16Data.buffer);
          wsRef.current.send(
            JSON.stringify({
              type: 'audio',
              data: base64Audio
            })
          );
          setIsListening(true);
        }
      };

      source.connect(processor);
      processor.connect(inputCtx.destination);
    } catch (err) {
      console.error('Audio capture initialization error:', err);
    }
  }

  function downsampleAndConvertToPCM16(
    buffer: Float32Array,
    inputSampleRate: number,
    outputSampleRate: number
  ): Int16Array {
    if (inputSampleRate === outputSampleRate) {
      const result = new Int16Array(buffer.length);
      for (let i = 0; i < buffer.length; i++) {
        const s = Math.max(-1, Math.min(1, buffer[i]));
        result[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
      }
      return result;
    }

    const sampleRateRatio = inputSampleRate / outputSampleRate;
    const newLength = Math.round(buffer.length / sampleRateRatio);
    const result = new Int16Array(newLength);
    let offsetResult = 0;
    let offsetBuffer = 0;

    while (offsetResult < result.length) {
      const nextOffsetBuffer = Math.round((offsetResult + 1) * sampleRateRatio);
      let accum = 0;
      let count = 0;
      for (let i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i++) {
        accum += buffer[i];
        count++;
      }
      const val = count > 0 ? accum / count : 0;
      const s = Math.max(-1, Math.min(1, val));
      result[offsetResult] = s < 0 ? s * 0x8000 : s * 0x7fff;
      offsetResult++;
      offsetBuffer = nextOffsetBuffer;
    }

    return result;
  }

  function arrayBufferToBase64(buffer: ArrayBufferLike): string {
    let binary = '';
    const bytes = new Uint8Array(buffer as ArrayBuffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  function playAudioChunk(base64Data: string) {
    const audioCtx = outputAudioContextRef.current;
    if (!audioCtx) return;

    try {
      const binaryString = window.atob(base64Data);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Convert 16-bit PCM to Float32
      const int16Array = new Int16Array(bytes.buffer);
      const float32Array = new Float32Array(int16Array.length);
      for (let i = 0; i < int16Array.length; i++) {
        float32Array[i] = int16Array[i] / 32768.0;
      }

      const audioBuffer = audioCtx.createBuffer(1, float32Array.length, 24000);
      audioBuffer.getChannelData(0).set(float32Array);

      const source = audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioCtx.destination);

      const currentTime = audioCtx.currentTime;
      const startTime = Math.max(currentTime, nextStartTimeRef.current);
      source.start(startTime);
      nextStartTimeRef.current = startTime + audioBuffer.duration;

      source.onended = () => {
        if (audioCtx.currentTime >= nextStartTimeRef.current - 0.05) {
          setIsSpeaking(false);
        }
      };
    } catch (err) {
      console.error('Audio chunk playback error:', err);
    }
  }

  function stopAudioPlayback() {
    const audioCtx = outputAudioContextRef.current;
    if (audioCtx) {
      nextStartTimeRef.current = audioCtx.currentTime;
    }
  }

  function endLiveSession() {
    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch (_) {}
      wsRef.current = null;
    }

    if (processorRef.current) {
      try {
        processorRef.current.disconnect();
      } catch (_) {}
      processorRef.current = null;
    }

    if (inputAudioContextRef.current) {
      try {
        inputAudioContextRef.current.close();
      } catch (_) {}
      inputAudioContextRef.current = null;
    }

    if (outputAudioContextRef.current) {
      try {
        outputAudioContextRef.current.close();
      } catch (_) {}
      outputAudioContextRef.current = null;
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }

    setIsConnected(false);
    setIsConnecting(false);
    setIsSpeaking(false);
    setIsListening(false);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-[#181113] text-white rounded-3xl max-w-md w-full shadow-2xl overflow-hidden border border-white/10 flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-[#58111A] to-[#30080E]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center">
              <Radio className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <h3 className="font-serif-display font-bold text-base leading-tight">
                Unaabs Voice Assistant
              </h3>
              <p className="text-[11px] text-amber-200/80">
                Real-Time Live API · Model <span className="font-mono font-semibold">gemini-3.8-live</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Central Visualizer Area */}
        <div className="p-8 text-center flex flex-col items-center justify-center space-y-6 min-h-[260px]">
          {isConnecting ? (
            <div className="space-y-3">
              <Loader2 className="w-12 h-12 text-amber-400 animate-spin mx-auto" />
              <p className="text-xs text-stone-300">Connecting to gemini-3.8-live session...</p>
            </div>
          ) : error ? (
            <div className="space-y-3 text-rose-300">
              <AlertCircle className="w-10 h-10 mx-auto text-rose-400" />
              <p className="text-xs font-medium">{error}</p>
              <button
                onClick={startLiveSession}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-semibold cursor-pointer"
              >
                Reconnect
              </button>
            </div>
          ) : (
            <div className="space-y-5">
              {/* Animated Orb / Audio Reactive Ring */}
              <div className="relative inline-flex items-center justify-center">
                {isSpeaking && (
                  <>
                    <span className="w-28 h-28 rounded-full bg-amber-400/30 animate-ping absolute" />
                    <span className="w-24 h-24 rounded-full bg-amber-500/20 animate-pulse absolute" />
                  </>
                )}
                {isListening && !isSpeaking && (
                  <span className="w-24 h-24 rounded-full bg-emerald-500/20 animate-pulse absolute" />
                )}

                <div
                  className={`w-20 h-20 rounded-full flex items-center justify-center relative shadow-xl transition-all duration-300 ${
                    isSpeaking
                      ? 'bg-gradient-to-tr from-amber-500 to-amber-300 text-stone-950 scale-110'
                      : isMuted
                      ? 'bg-stone-800 text-stone-400'
                      : 'bg-gradient-to-tr from-[#58111A] to-[#801B28] text-white'
                  }`}
                >
                  {isSpeaking ? (
                    <Volume2 className="w-9 h-9 animate-bounce" />
                  ) : isMuted ? (
                    <MicOff className="w-8 h-8" />
                  ) : (
                    <Mic className="w-8 h-8" />
                  )}
                </div>
              </div>

              <div>
                <span className="inline-block px-3 py-1 rounded-full text-[11px] font-semibold tracking-wide uppercase border border-white/10 bg-white/5">
                  {isSpeaking ? (
                    <span className="text-amber-300 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                      Unaabs is Speaking...
                    </span>
                  ) : isMuted ? (
                    <span className="text-stone-400">Microphone Muted</span>
                  ) : (
                    <span className="text-emerald-400 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      Listening to you...
                    </span>
                  )}
                </span>
              </div>
            </div>
          )}

          {/* Captions Display Box */}
          <div className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-xs text-stone-300 max-h-24 overflow-y-auto leading-relaxed text-left">
            <span className="text-[10px] uppercase font-bold text-amber-300/80 block mb-1">
              Live Session Activity
            </span>
            <p className="line-clamp-3">{captions || 'Say hello to begin voice consultation...'}</p>
          </div>
        </div>

        {/* Bottom Voice Controls */}
        <div className="p-4 bg-white/5 border-t border-white/10 flex items-center justify-center gap-4">
          <button
            onClick={() => setIsMuted((prev) => !prev)}
            className={`p-3.5 rounded-2xl transition-all cursor-pointer ${
              isMuted
                ? 'bg-rose-600 hover:bg-rose-700 text-white'
                : 'bg-white/10 hover:bg-white/20 text-white'
            }`}
            title={isMuted ? 'Unmute microphone' : 'Mute microphone'}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <button
            onClick={onClose}
            className="px-6 py-3 bg-rose-600/90 hover:bg-rose-600 text-white font-semibold text-xs rounded-2xl flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
          >
            <PhoneOff className="w-4 h-4" />
            <span>End Call</span>
          </button>
        </div>
      </div>
    </div>
  );
};
