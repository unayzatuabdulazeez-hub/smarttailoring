import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Quote } from '../../types';
import { ConfirmModal } from '../common/ConfirmModal';
import {
  Calculator,
  RotateCcw,
  BookmarkPlus,
  ArrowRight,
  TrendingUp,
  Percent,
  DollarSign,
  Trash2,
  FileCheck,
  Check
} from 'lucide-react';

interface PricingCalculatorViewProps {
  onConvertToOrder: (quote: Quote) => void;
}

export const PricingCalculatorView: React.FC<PricingCalculatorViewProps> = ({ onConvertToOrder }) => {
  const { quotes, addQuote, deleteQuote, formatCurrency } = useApp();

  const [mode, setMode] = useState<'cost-plus' | 'target-price'>('cost-plus');

  // Input states
  const [fabricCost, setFabricCost] = useState<number>(0);
  const [labourCost, setLabourCost] = useState<number>(0);
  const [materialsCost, setMaterialsCost] = useState<number>(0);
  const [transportCost, setTransportCost] = useState<number>(0);
  const [otherExpenses, setOtherExpenses] = useState<number>(0);

  // Mode 1: Cost + Profit %
  const [profitPercentage, setProfitPercentage] = useState<number>(40);

  // Mode 2: Target Selling Price
  const [targetPrice, setTargetPrice] = useState<number>(0);

  // Quote Metadata
  const [quoteTitle, setQuoteTitle] = useState('');
  const [clientName, setClientName] = useState('');
  const [outfitType, setOutfitType] = useState('Kaftan');
  const [notes, setNotes] = useState('');

  const [quoteToDelete, setQuoteToDelete] = useState<string | null>(null);

  // Calculations
  const totalCost = Number(fabricCost || 0) + 
                    Number(labourCost || 0) + 
                    Number(materialsCost || 0) + 
                    Number(transportCost || 0) + 
                    Number(otherExpenses || 0);

  let sellingPrice = 0;
  let expectedProfit = 0;
  let calculatedMargin = 0;

  if (mode === 'cost-plus') {
    const markupMultiplier = 1 + (Number(profitPercentage || 0) / 100);
    sellingPrice = Math.round(totalCost * markupMultiplier);
    expectedProfit = sellingPrice - totalCost;
    calculatedMargin = sellingPrice > 0 ? Math.round((expectedProfit / sellingPrice) * 100) : 0;
  } else {
    sellingPrice = Number(targetPrice || 0);
    expectedProfit = sellingPrice - totalCost;
    calculatedMargin = sellingPrice > 0 ? Math.round((expectedProfit / sellingPrice) * 100) : 0;
  }

  const handleReset = () => {
    setFabricCost(0);
    setLabourCost(0);
    setMaterialsCost(0);
    setTransportCost(0);
    setOtherExpenses(0);
    setProfitPercentage(40);
    setTargetPrice(0);
    setQuoteTitle('');
    setClientName('');
    setNotes('');
  };

  const handleSaveQuote = (e: React.FormEvent) => {
    e.preventDefault();
    const title = quoteTitle.trim() || `${outfitType} for ${clientName.trim() || 'Client'}`;
    addQuote({
      title,
      customerName: clientName.trim() || undefined,
      outfitType,
      fabricCost,
      labourCost,
      materialsCost,
      transportCost,
      otherExpenses,
      profitPercentage: mode === 'cost-plus' ? profitPercentage : calculatedMargin,
      totalCost,
      sellingPrice,
      expectedProfit,
      notes: notes.trim()
    });
    setQuoteTitle('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold font-serif-display text-stone-900 tracking-tight">
          Tailoring Pricing Calculator
        </h1>
        <p className="text-xs text-stone-500 mt-0.5">
          Eliminate under-pricing. Calculate real studio production costs, artisan wages, and target margins.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Calculator Form (7 cols) */}
        <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-6">
          {/* Mode Switcher */}
          <div className="flex bg-stone-100 p-1 rounded-xl">
            <button
              type="button"
              onClick={() => setMode('cost-plus')}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                mode === 'cost-plus'
                  ? 'bg-white text-[#58111A] shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              1. Cost + Desired Profit %
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('target-price');
                if (targetPrice === 0 && sellingPrice > 0) setTargetPrice(sellingPrice);
              }}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                mode === 'target-price'
                  ? 'bg-white text-[#58111A] shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              2. Target Selling Price
            </button>
          </div>

          {/* Section: Direct Costs */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-stone-400 uppercase tracking-wider">
              Production Cost Inputs
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Fabric Cost
                </label>
                <input
                  type="number"
                  min="0"
                  value={fabricCost || ''}
                  onChange={(e) => setFabricCost(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Labour / Cutting & Sewing Cost
                </label>
                <input
                  type="number"
                  min="0"
                  value={labourCost || ''}
                  onChange={(e) => setLabourCost(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Accessories, Buttons & Trims
                </label>
                <input
                  type="number"
                  min="0"
                  value={materialsCost || ''}
                  onChange={(e) => setMaterialsCost(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Logistics & Transportation
                </label>
                <input
                  type="number"
                  min="0"
                  value={transportCost || ''}
                  onChange={(e) => setTransportCost(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Other Studio Overhead / Contingency
                </label>
                <input
                  type="number"
                  min="0"
                  value={otherExpenses || ''}
                  onChange={(e) => setOtherExpenses(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm font-mono font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                />
              </div>
            </div>
          </div>

          {/* Mode specific input */}
          <div className="pt-2 border-t border-stone-200">
            {mode === 'cost-plus' ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-[#58111A] uppercase tracking-wider">
                    Desired Profit Markup (%)
                  </label>
                  <span className="font-mono font-bold text-sm text-[#58111A]">{profitPercentage}%</span>
                </div>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="10"
                    max="150"
                    step="5"
                    value={profitPercentage}
                    onChange={(e) => setProfitPercentage(parseInt(e.target.value))}
                    className="flex-1 accent-[#58111A]"
                  />
                  <input
                    type="number"
                    min="0"
                    value={profitPercentage}
                    onChange={(e) => setProfitPercentage(parseFloat(e.target.value) || 0)}
                    className="w-20 px-2 py-1 bg-stone-50 border border-stone-300 rounded-lg text-xs font-mono font-bold text-right"
                  />
                </div>
                <div className="flex gap-2 pt-1">
                  {[25, 35, 45, 60, 80].map(pct => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => setProfitPercentage(pct)}
                      className={`px-2 py-1 rounded text-[11px] font-semibold transition-colors ${
                        profitPercentage === pct ? 'bg-[#58111A] text-white' : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                      }`}
                    >
                      +{pct}%
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-bold text-[#58111A] uppercase tracking-wider mb-1">
                  Target Customer Selling Price
                </label>
                <input
                  type="number"
                  min="0"
                  value={targetPrice || ''}
                  onChange={(e) => setTargetPrice(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full px-3 py-2 bg-stone-50 border-2 border-[#58111A]/40 rounded-xl text-lg font-bold font-mono text-[#58111A] focus:outline-none focus:border-[#58111A]"
                />
              </div>
            )}
          </div>

          {/* Reset Action */}
          <div className="pt-2 flex justify-end">
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-stone-500 hover:text-stone-800 rounded-lg hover:bg-stone-100 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Values</span>
            </button>
          </div>
        </div>

        {/* Right: Results & Save as Quote (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Output Dashboard */}
          <div className="bg-[#58111A] text-white p-6 rounded-2xl shadow-md space-y-4">
            <h3 className="text-xs uppercase tracking-widest text-amber-200/80 font-bold">
              Pricing Summary
            </h3>

            <div className="space-y-3">
              <div className="flex items-center justify-between text-amber-100/70 text-xs">
                <span>Total Production Cost:</span>
                <span className="font-mono text-sm font-semibold">{formatCurrency(totalCost)}</span>
              </div>

              <div className="flex items-center justify-between border-t border-white/10 pt-3">
                <div>
                  <span className="text-xs text-amber-300 font-bold uppercase block">Recommended Price</span>
                  <span className="text-2xl font-bold font-mono text-white">{formatCurrency(sellingPrice)}</span>
                </div>

                <div className="text-right">
                  <span className="text-xs text-emerald-300 font-bold uppercase block">Net Profit</span>
                  <span className={`text-xl font-bold font-mono ${expectedProfit >= 0 ? 'text-emerald-300' : 'text-rose-400'}`}>
                    {formatCurrency(expectedProfit)}
                  </span>
                </div>
              </div>

              <div className="border-t border-white/10 pt-3 flex items-center justify-between text-xs text-stone-300">
                <span>Effective Profit Margin:</span>
                <span className="font-mono font-bold text-amber-300 text-sm">{calculatedMargin}%</span>
              </div>
            </div>
          </div>

          {/* Save as Client Quote Box */}
          <form onSubmit={handleSaveQuote} className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-3">
            <h4 className="text-xs font-bold text-stone-800 uppercase tracking-wider flex items-center gap-1.5">
              <BookmarkPlus className="w-4 h-4 text-[#58111A]" />
              <span>Save as Draft Quote</span>
            </h4>

            <div>
              <label className="block text-[11px] font-semibold text-stone-600 mb-1">Quote Title</label>
              <input
                type="text"
                value={quoteTitle}
                onChange={(e) => setQuoteTitle(e.target.value)}
                placeholder="e.g. 3-Piece Silk Brocade Kaftan"
                className="w-full px-3 py-1.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-1">Client Name</label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="e.g. Amina Danjuma"
                  className="w-full px-3 py-1.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-stone-600 mb-1">Outfit Type</label>
                <select
                  value={outfitType}
                  onChange={(e) => setOutfitType(e.target.value)}
                  className="w-full px-3 py-1.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900"
                >
                  <option value="Kaftan">Kaftan</option>
                  <option value="Jalabiya">Jalabiya</option>
                  <option value="Abaya">Abaya</option>
                  <option value="Gown">Gown</option>
                  <option value="Two-piece">Two-piece</option>
                  <option value="Three-piece">Three-piece</option>
                  <option value="Native wear">Native wear</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={sellingPrice <= 0}
              className="w-full py-2 bg-stone-900 hover:bg-stone-800 disabled:bg-stone-300 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              Save Quote to Archive
            </button>
          </form>

          {/* Saved Quotes List */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-3">
            <h4 className="text-xs font-bold text-stone-400 uppercase tracking-wider">
              Saved Quotes Archive ({quotes.length})
            </h4>

            {quotes.length === 0 ? (
              <p className="text-xs text-stone-400 py-3 text-center">No quotes saved yet.</p>
            ) : (
              <div className="space-y-2">
                {quotes.map(q => (
                  <div key={q.id} className="p-3 bg-stone-50 rounded-xl border border-stone-100 flex items-center justify-between text-xs">
                    <div>
                      <h5 className="font-bold text-stone-900">{q.title}</h5>
                      <p className="text-[11px] text-stone-500 mt-0.5">
                        Price: <strong className="font-mono text-stone-800">{formatCurrency(q.sellingPrice)}</strong> (Profit: {formatCurrency(q.expectedProfit)})
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => onConvertToOrder(q)}
                        className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                        title="Convert to active order"
                      >
                        <span>Convert</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => setQuoteToDelete(q.id)}
                        className="p-1 text-stone-300 hover:text-rose-600 rounded transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <ConfirmModal
        isOpen={!!quoteToDelete}
        title="Delete Saved Quote?"
        message="Are you sure you want to remove this calculation quote from your archive?"
        confirmLabel="Delete Quote"
        onConfirm={() => {
          if (quoteToDelete) {
            deleteQuote(quoteToDelete);
            setQuoteToDelete(null);
          }
        }}
        onCancel={() => setQuoteToDelete(null)}
      />
    </div>
  );
};
