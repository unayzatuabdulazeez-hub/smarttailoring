import React, { useState, useEffect } from 'react';
import {
  PlatformClient,
  TailorAccount,
  PlatformSettings
} from '../../services/platformClient';
import {
  ShieldCheck,
  Users,
  CheckCircle2,
  Clock,
  XCircle,
  AlertTriangle,
  Settings,
  Phone,
  Mail,
  Building2,
  Sparkles,
  RefreshCw,
  LogOut,
  Sliders,
  Bell,
  Search,
  ExternalLink,
  ChevronRight,
  Crown
} from 'lucide-react';

interface PlatformAdminViewProps {
  onExitAdmin: () => void;
  adminEmail: string;
}

export const PlatformAdminView: React.FC<PlatformAdminViewProps> = ({
  onExitAdmin,
  adminEmail
}) => {
  const [tailors, setTailors] = useState<TailorAccount[]>([]);
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'requests' | 'settings'>('requests');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState('');

  // Settings form state
  const [requireApproval, setRequireApproval] = useState(true);
  const [whatsappSupport, setWhatsappSupport] = useState('');
  const [announcement, setAnnouncement] = useState('');
  const [isSavingSettings, setIsSavingSettings] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      const data = await PlatformClient.getAdminTailors();
      setTailors(data.tailors);
      setSettings(data.settings);
      setRequireApproval(data.settings.requireApproval);
      setWhatsappSupport(data.settings.whatsappSupport);
      setAnnouncement(data.settings.announcement);
    } catch (err: any) {
      console.error('Error loading admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const showNotice = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 4000);
  };

  const handleUpdateStatus = async (
    tailorId: string,
    status: 'pending' | 'approved' | 'rejected' | 'suspended',
    planTier?: 'Standard' | 'Premium' | 'VIP'
  ) => {
    setActionLoading(tailorId);
    try {
      const updated = await PlatformClient.updateTailorStatus(tailorId, status, planTier);
      setTailors((prev) => prev.map((t) => (t.id === tailorId ? updated : t)));
      showNotice(
        status === 'approved'
          ? `Tailor "${updated.businessName}" approved! They can now log in.`
          : `Tailor status updated to ${status}.`
      );
    } catch (err: any) {
      showNotice(err.message || 'Failed to update status');
    } finally {
      setActionLoading(null);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSettings(true);
    try {
      const updated = await PlatformClient.updatePlatformSettings({
        requireApproval,
        whatsappSupport,
        announcement
      });
      setSettings(updated);
      showNotice('Platform settings updated successfully.');
    } catch (err: any) {
      alert(err.message || 'Failed to save settings');
    } finally {
      setIsSavingSettings(false);
    }
  };

  const pendingCount = tailors.filter((t) => t.status === 'pending').length;
  const approvedCount = tailors.filter((t) => t.status === 'approved').length;
  const rejectedCount = tailors.filter((t) => t.status === 'rejected' || t.status === 'suspended').length;

  const filteredTailors = tailors.filter((t) => {
    const matchesStatus = filterStatus === 'all' || t.status === filterStatus;
    const matchesSearch =
      t.businessName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.ownerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.phone.includes(searchQuery);
    return matchesStatus && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-stone-100 text-stone-900 font-sans pb-16">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed top-4 right-4 z-50 bg-emerald-900 text-white px-4 py-3 rounded-2xl shadow-xl text-xs font-semibold flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Top Admin Header */}
      <header className="bg-stone-900 text-white px-6 py-4 shadow-md sticky top-0 z-30">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-serif-display font-bold text-lg text-white">
                  Platform Owner Console
                </h1>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400/20 text-amber-300 border border-amber-400/30">
                  SUPER ADMIN
                </span>
              </div>
              <p className="text-xs text-stone-400">
                Logged in as <strong className="text-stone-200">{adminEmail}</strong> · Full Platform Authority
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={loadData}
              className="p-2 bg-stone-800 hover:bg-stone-700 text-stone-300 rounded-xl transition-colors cursor-pointer"
              title="Refresh Tailors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onExitAdmin}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-stone-800 hover:bg-stone-700 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5 text-stone-400" />
              <span>Exit Admin Console</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 space-y-6">
        {/* KPI Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div
            onClick={() => { setFilterStatus('pending'); setActiveTab('requests'); }}
            className={`p-5 rounded-2xl border transition-all cursor-pointer ${
              pendingCount > 0
                ? 'bg-amber-50 border-amber-300 shadow-xs'
                : 'bg-white border-stone-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-amber-900 uppercase tracking-wider">
                Pending Requests
              </span>
              <Clock className="w-4 h-4 text-amber-600" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-amber-950">{pendingCount}</span>
              <span className="text-xs text-amber-800 font-semibold">awaiting your approval</span>
            </div>
            <p className="text-[11px] text-stone-500 mt-1">Tap to review new sign-ups</p>
          </div>

          <div
            onClick={() => { setFilterStatus('approved'); setActiveTab('requests'); }}
            className="p-5 bg-white rounded-2xl border border-stone-200 shadow-2xs cursor-pointer hover:border-emerald-300 transition-colors"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
                Approved Ateliers
              </span>
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-stone-900">{approvedCount}</span>
              <span className="text-xs text-emerald-700 font-semibold">active workshops</span>
            </div>
            <p className="text-[11px] text-stone-500 mt-1">Can log in & create orders</p>
          </div>

          <div
            onClick={() => { setFilterStatus('all'); setActiveTab('requests'); }}
            className="p-5 bg-white rounded-2xl border border-stone-200 shadow-2xs cursor-pointer hover:border-stone-400 transition-colors"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
                Total Tailors
              </span>
              <Users className="w-4 h-4 text-stone-600" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-stone-900">{tailors.length}</span>
              <span className="text-xs text-stone-500">registered in network</span>
            </div>
            <p className="text-[11px] text-stone-500 mt-1">Across all regions</p>
          </div>

          <div
            onClick={() => setActiveTab('settings')}
            className="p-5 bg-white rounded-2xl border border-stone-200 shadow-2xs cursor-pointer hover:border-stone-400 transition-colors"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
                Approval Policy
              </span>
              <Sliders className="w-4 h-4 text-stone-600" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className={`text-base font-bold ${requireApproval ? 'text-amber-700' : 'text-emerald-700'}`}>
                {requireApproval ? 'Owner Approval Required' : 'Instant Sign-up'}
              </span>
            </div>
            <p className="text-[11px] text-stone-500 mt-1">
              {requireApproval ? 'You must confirm each tailor' : 'Tailors enter immediately'}
            </p>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-2 border-b border-stone-200 pb-2">
          <button
            onClick={() => setActiveTab('requests')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-2 ${
              activeTab === 'requests'
                ? 'bg-[#58111A] text-white shadow-xs'
                : 'bg-white text-stone-700 hover:bg-stone-200'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Tailor Management & Approvals</span>
            {pendingCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-amber-400 text-stone-950 font-extrabold text-[10px]">
                {pendingCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-2 ${
              activeTab === 'settings'
                ? 'bg-[#58111A] text-white shadow-xs'
                : 'bg-white text-stone-700 hover:bg-stone-200'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Platform Policy & Broadcast</span>
          </button>
        </div>

        {/* TAB 1: Tailor Management Table */}
        {activeTab === 'requests' && (
          <div className="bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden">
            {/* Filter & Search Bar */}
            <div className="p-4 sm:p-5 border-b border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3 bg-stone-50/50">
              <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto">
                <span className="text-xs font-bold text-stone-500 uppercase tracking-wider mr-1">
                  Filter:
                </span>
                {(['all', 'pending', 'approved', 'rejected'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setFilterStatus(st)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer capitalize ${
                      filterStatus === st
                        ? 'bg-stone-900 text-white'
                        : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
                    }`}
                  >
                    {st === 'all' ? 'All Tailors' : st}
                    {st === 'pending' && pendingCount > 0 && ` (${pendingCount})`}
                  </button>
                ))}
              </div>

              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search tailor, owner, phone..."
                  className="w-full pl-9 pr-3 py-1.5 bg-white border border-stone-200 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20"
                />
              </div>
            </div>

            {/* Tailors Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-100/80 text-stone-500 uppercase font-bold tracking-wider text-[11px] border-b border-stone-200">
                  <tr>
                    <th className="px-5 py-3.5">Atelier & Owner</th>
                    <th className="px-4 py-3.5">Contact / Location</th>
                    <th className="px-4 py-3.5">Status</th>
                    <th className="px-4 py-3.5">Tier Plan</th>
                    <th className="px-4 py-3.5">Registered</th>
                    <th className="px-5 py-3.5 text-right">Approve / Control</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {filteredTailors.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-12 text-stone-400">
                        No tailor records match this filter.
                      </td>
                    </tr>
                  ) : (
                    filteredTailors.map((tailor) => {
                      const isPending = tailor.status === 'pending';
                      const isApproved = tailor.status === 'approved';
                      const isBusy = actionLoading === tailor.id;

                      return (
                        <tr
                          key={tailor.id}
                          className={`hover:bg-stone-50/80 transition-colors ${
                            isPending ? 'bg-amber-50/40' : ''
                          }`}
                        >
                          <td className="px-5 py-4">
                            <div className="font-bold text-sm text-stone-900 flex items-center gap-1.5">
                              <span>{tailor.businessName}</span>
                              {tailor.planTier === 'Premium' && (
                                <span title="Premium Tier" className="inline-flex">
                                  <Crown className="w-3.5 h-3.5 text-amber-600 inline" />
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-stone-500 mt-0.5">
                              Owner: <strong className="text-stone-700">{tailor.ownerName}</strong>
                            </p>
                            {tailor.notes && (
                              <p className="text-[10px] text-amber-800 italic mt-0.5 line-clamp-1">
                                Note: {tailor.notes}
                              </p>
                            )}
                          </td>

                          <td className="px-4 py-4 space-y-0.5">
                            <div className="flex items-center gap-1.5 text-stone-800">
                              <Phone className="w-3 h-3 text-stone-400" />
                              <a
                                href={`https://wa.me/${tailor.phone.replace(/[^0-9]/g, '')}`}
                                target="_blank"
                                rel="noreferrer"
                                className="hover:text-emerald-700 hover:underline font-medium"
                              >
                                {tailor.phone || 'No phone'}
                              </a>
                            </div>
                            <div className="flex items-center gap-1.5 text-stone-500 text-[11px]">
                              <Mail className="w-3 h-3 text-stone-400" />
                              <span>{tailor.email}</span>
                            </div>
                            {tailor.location && (
                              <span className="text-[10px] text-stone-400 block">
                                {tailor.location}
                              </span>
                            )}
                          </td>

                          <td className="px-4 py-4">
                            {tailor.status === 'pending' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300 animate-pulse">
                                <Clock className="w-3 h-3" />
                                <span>Pending Approval</span>
                              </span>
                            ) : tailor.status === 'approved' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-300">
                                <CheckCircle2 className="w-3 h-3" />
                                <span>Active & Approved</span>
                              </span>
                            ) : tailor.status === 'suspended' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-stone-200 text-stone-700 border border-stone-300">
                                <span>Suspended</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
                                <XCircle className="w-3 h-3" />
                                <span>Rejected</span>
                              </span>
                            )}
                          </td>

                          <td className="px-4 py-4">
                            <select
                              value={tailor.planTier || 'Standard'}
                              onChange={(e) =>
                                handleUpdateStatus(tailor.id, tailor.status, e.target.value as any)
                              }
                              className="px-2 py-1 bg-stone-50 border border-stone-200 rounded-lg text-xs font-semibold text-stone-800"
                            >
                              <option value="Standard">Standard</option>
                              <option value="Premium">👑 Premium</option>
                              <option value="VIP">💎 Royal VIP</option>
                            </select>
                          </td>

                          <td className="px-4 py-4 text-stone-500 text-[11px]">
                            {new Date(tailor.registeredAt).toLocaleDateString()}
                          </td>

                          <td className="px-5 py-4 text-right">
                            <div className="flex items-center justify-end gap-1.5 flex-wrap">
                              {isPending && (
                                <>
                                  <button
                                    disabled={isBusy}
                                    onClick={() => handleUpdateStatus(tailor.id, 'approved')}
                                    className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1"
                                  >
                                    <CheckCircle2 className="w-3.5 h-3.5" />
                                    <span>Approve Access</span>
                                  </button>

                                  <button
                                    disabled={isBusy}
                                    onClick={() => handleUpdateStatus(tailor.id, 'rejected')}
                                    className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 font-semibold text-xs rounded-xl transition-colors cursor-pointer"
                                  >
                                    Reject
                                  </button>
                                </>
                              )}

                              {isApproved && (
                                <button
                                  disabled={isBusy}
                                  onClick={() => handleUpdateStatus(tailor.id, 'suspended')}
                                  className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg font-medium text-[11px] cursor-pointer"
                                  title="Suspend account"
                                >
                                  Suspend
                                </button>
                              )}

                              {tailor.status === 'suspended' && (
                                <button
                                  disabled={isBusy}
                                  onClick={() => handleUpdateStatus(tailor.id, 'approved')}
                                  className="px-3 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 border border-emerald-300 rounded-lg font-bold text-xs cursor-pointer"
                                >
                                  Reactivate
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 2: Platform Settings & Approval Policy */}
        {activeTab === 'settings' && (
          <div className="max-w-2xl bg-white p-6 sm:p-7 rounded-3xl border border-stone-200 shadow-sm space-y-6">
            <div>
              <h3 className="font-serif-display font-bold text-lg text-stone-900">
                Platform Access Control & Settings
              </h3>
              <p className="text-xs text-stone-500 mt-1">
                Configure how tailors gain access, your WhatsApp support contact, and global broadcast announcements.
              </p>
            </div>

            <form onSubmit={handleSaveSettings} className="space-y-5">
              {/* Approval toggle */}
              <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 flex items-start justify-between gap-4">
                <div>
                  <h4 className="font-bold text-sm text-stone-900">
                    Require App Owner Approval for New Tailors
                  </h4>
                  <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                    When enabled, tailors who sign up cannot access the tailoring dashboard until you click <strong>Approve Access</strong> in this console.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer shrink-0 mt-1">
                  <input
                    type="checkbox"
                    checked={requireApproval}
                    onChange={(e) => setRequireApproval(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-stone-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-stone-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#58111A]"></div>
                </label>
              </div>

              {/* Owner WhatsApp contact */}
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Platform Owner WhatsApp Support Line
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="text"
                    value={whatsappSupport}
                    onChange={(e) => setWhatsappSupport(e.target.value)}
                    placeholder="+234 803 000 0000"
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900"
                  />
                </div>
                <p className="text-[11px] text-stone-400 mt-1">
                  Tailors awaiting approval will see this number to reach you directly.
                </p>
              </div>

              {/* Broadcast announcement */}
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Platform Announcement Banner (Optional)
                </label>
                <textarea
                  rows={3}
                  value={announcement}
                  onChange={(e) => setAnnouncement(e.target.value)}
                  placeholder="e.g. Eid al-Fitr rush notice: update your delivery cutoffs by Friday..."
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900"
                />
              </div>

              <button
                type="submit"
                disabled={isSavingSettings}
                className="w-full py-2.5 bg-[#58111A] hover:bg-[#4A0E17] text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                {isSavingSettings ? 'Saving Settings...' : 'Save Platform Policy'}
              </button>
            </form>
          </div>
        )}
      </main>
    </div>
  );
};
