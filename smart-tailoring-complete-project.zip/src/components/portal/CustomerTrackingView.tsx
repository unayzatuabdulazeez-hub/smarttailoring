import React, { useState, useEffect } from 'react';
import { PlatformClient, PublicOrderData } from '../../services/platformClient';
import {
  Scissors,
  Search,
  CheckCircle2,
  Clock,
  Calendar,
  CreditCard,
  Phone,
  MessageCircle,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Building2,
  Layers,
  Crown
} from 'lucide-react';

interface CustomerTrackingViewProps {
  initialOrderNumber?: string;
  onExitPortal: () => void;
}

export const CustomerTrackingView: React.FC<CustomerTrackingViewProps> = ({
  initialOrderNumber,
  onExitPortal
}) => {
  const [orderQuery, setOrderQuery] = useState(initialOrderNumber || '');
  const [order, setOrder] = useState<PublicOrderData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchOrder = async (num: string) => {
    if (!num.trim()) return;
    setLoading(true);
    setError('');
    try {
      const data = await PlatformClient.trackOrder(num);
      setOrder(data);
    } catch (err: any) {
      setError(err.message || 'Order not found. Please verify the order number.');
      setOrder(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialOrderNumber) {
      fetchOrder(initialOrderNumber);
    }
  }, [initialOrderNumber]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchOrder(orderQuery);
  };

  const steps = ['Confirmed', 'Cutting', 'Sewing', 'Fitting', 'Ready', 'Delivered'];
  const currentStepIndex = order ? steps.indexOf(order.productionStatus) : -1;

  const getWhatsAppMessage = () => {
    if (!order) return '';
    return encodeURIComponent(
      `Hello ${order.tailorBusinessName}, I am tracking my garment order #${order.orderNumber} (${order.outfitType}). Delivery promised for ${new Date(order.deliveryDate).toLocaleDateString()}. Thank you!`
    );
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-stone-900 font-sans pb-16">
      {/* Top Header */}
      <header className="sticky top-0 z-30 bg-[#FDFBF7]/90 backdrop-blur-md border-b border-stone-200/80 px-4 md:px-8 py-3.5">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#58111A] text-amber-300 flex items-center justify-center shadow-xs">
              <Scissors className="w-4 h-4" />
            </div>
            <div>
              <span className="font-serif-display font-bold text-base text-[#58111A]">
                Smart Tailoring
              </span>
              <span className="hidden sm:inline text-stone-400 text-xs ml-2">
                · Client Tracking Portal
              </span>
            </div>
          </div>

          <button
            onClick={onExitPortal}
            className="text-xs font-semibold text-stone-600 hover:text-stone-900 px-3 py-1.5 rounded-lg hover:bg-stone-100 transition-colors cursor-pointer"
          >
            ← Return to Atelier
          </button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 pt-8 space-y-6">
        {/* Tracking Input Bar */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm text-center space-y-3">
          <span className="text-xs uppercase tracking-widest text-[#58111A] font-bold">
            Live Atelier Garment Tracking
          </span>
          <h2 className="text-2xl font-bold font-serif-display text-stone-900">
            Track Your Custom Outfit
          </h2>
          <p className="text-xs text-stone-500 max-w-md mx-auto">
            Enter the Order Number given by your tailor (e.g. <strong>ST-2026-0001</strong>) to check live workshop status and fitting dates.
          </p>

          <form onSubmit={handleSearchSubmit} className="max-w-md mx-auto flex gap-2 pt-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                required
                value={orderQuery}
                onChange={(e) => setOrderQuery(e.target.value)}
                placeholder="Order Number (e.g. ST-2026-0001)"
                className="w-full pl-9 pr-3 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs font-mono uppercase font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 bg-[#58111A] hover:bg-[#4A0E17] text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              {loading ? 'Searching...' : 'Track'}
            </button>
          </form>

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-medium">
              {error}
            </div>
          )}
        </div>

        {/* Order Result Card */}
        {order && (
          <div className="bg-white rounded-3xl border border-stone-200 shadow-md overflow-hidden animate-in fade-in duration-300">
            {/* Atelier Brand Banner */}
            <div className="bg-gradient-to-r from-[#58111A] to-[#3B0B12] text-white p-6 sm:p-7 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-amber-300">
                  Tailored By
                </span>
                <h3 className="font-serif-display font-bold text-2xl text-white mt-0.5">
                  {order.tailorBusinessName}
                </h3>
                <p className="text-xs text-amber-100/80 mt-1">
                  Master Tailor: <strong>{order.tailorOwnerName}</strong>
                  {order.tailorAddress ? ` · ${order.tailorAddress}` : ''}
                </p>
              </div>

              <div className="sm:text-right">
                <span className="text-xs text-amber-200 block font-mono">ORDER NUMBER</span>
                <span className="text-xl font-mono font-bold text-white tracking-wider">
                  {order.orderNumber}
                </span>
                <div className="mt-1">
                  {order.serviceTier === 'Royal_VIP' ? (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-200 text-purple-950 border border-purple-300">
                      💎 Royal VIP Bespoke
                    </span>
                  ) : order.serviceTier === 'Premium' ? (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-200 text-amber-950 border border-amber-300">
                      👑 Unaabs Premium Couture
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-medium bg-white/20 text-white">
                      🌟 Standard Atelier
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Visual Step Progress Indicator */}
            <div className="p-6 border-b border-stone-100 bg-stone-50/50">
              <h4 className="text-xs font-bold text-stone-500 uppercase tracking-wider mb-4">
                Current Production Stage: <strong className="text-[#58111A] text-sm capitalize">{order.productionStatus}</strong>
              </h4>

              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center text-xs">
                {steps.map((st, idx) => {
                  const isDone = currentStepIndex >= idx;
                  const isCurrent = currentStepIndex === idx;

                  return (
                    <div
                      key={st}
                      className={`p-2.5 rounded-xl border transition-all ${
                        isCurrent
                          ? 'bg-[#58111A] text-white font-bold border-[#58111A] shadow-xs scale-102 ring-2 ring-[#58111A]/20'
                          : isDone
                          ? 'bg-emerald-50 text-emerald-900 border-emerald-300 font-semibold'
                          : 'bg-white text-stone-400 border-stone-200'
                      }`}
                    >
                      <div className="text-[10px] mb-1 font-mono">Step {idx + 1}</div>
                      <div className="capitalize">{st}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Garment Details & Timing */}
            <div className="p-6 grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider block">
                    Garment Details
                  </span>
                  <p className="text-lg font-bold text-stone-900 mt-0.5">
                    {order.outfitType === 'Custom' ? order.customOutfitType : order.outfitType}
                  </p>
                  {order.fabricType && (
                    <p className="text-xs text-stone-600 mt-1">
                      Fabric: <strong>{order.fabricType}</strong> ({order.fabricColour || 'Specified'})
                    </p>
                  )}
                  {order.orderDescription && (
                    <p className="text-xs text-stone-500 italic mt-2 p-2 bg-stone-50 rounded-xl border border-stone-100">
                      "{order.orderDescription}"
                    </p>
                  )}
                </div>

                {/* Important Dates */}
                <div className="space-y-2 pt-2">
                  <div className="flex items-center gap-2 text-xs">
                    <Calendar className="w-4 h-4 text-[#58111A]" />
                    <span>Promised Delivery: <strong>{new Date(order.deliveryDate).toLocaleDateString()}</strong></span>
                  </div>
                  {order.fittingAppointmentDate && (
                    <div className="flex items-center gap-2 text-xs text-amber-900 font-semibold bg-amber-50 p-2 rounded-xl border border-amber-200">
                      <Clock className="w-4 h-4 text-amber-700" />
                      <span>Scheduled VIP Fitting: {new Date(order.fittingAppointmentDate).toLocaleDateString()}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Financial Summary & Bank Transfer Details */}
              <div className="p-5 bg-stone-50 rounded-2xl border border-stone-200 space-y-3 text-xs">
                <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block">
                  Payment Summary
                </span>

                <div className="flex justify-between py-1 border-b border-stone-200 text-stone-600">
                  <span>Total Sewing Cost</span>
                  <span className="font-semibold text-stone-900">{order.tailorCurrency}{order.totalCost.toLocaleString()}</span>
                </div>

                <div className="flex justify-between py-1 border-b border-stone-200 text-stone-600">
                  <span>Deposit / Paid to Date</span>
                  <span className="font-semibold text-emerald-700">{order.tailorCurrency}{order.amountPaid.toLocaleString()}</span>
                </div>

                <div className="flex justify-between py-1.5 text-sm font-bold text-stone-900">
                  <span>Balance Due</span>
                  <span className={order.balanceDue > 0 ? 'text-amber-800' : 'text-emerald-700'}>
                    {order.tailorCurrency}{order.balanceDue.toLocaleString()}
                  </span>
                </div>

                {order.bankDetails && order.balanceDue > 0 && (
                  <div className="p-3 bg-white rounded-xl border border-stone-200 mt-2 space-y-1">
                    <span className="text-[10px] font-bold uppercase text-stone-400 block">
                      Direct Bank Transfer Details:
                    </span>
                    <p className="font-mono text-xs font-semibold text-stone-800 whitespace-pre-line">
                      {order.bankDetails}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Direct Contact with Tailor */}
            <div className="p-6 bg-stone-50 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs text-stone-600">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Verified atelier on Unaabs Smart Tailoring Network</span>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                {order.tailorPhone && (
                  <a
                    href={`https://wa.me/${order.tailorPhone.replace(/[^0-9]/g, '')}?text=${getWhatsAppMessage()}`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Chat on WhatsApp</span>
                  </a>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
