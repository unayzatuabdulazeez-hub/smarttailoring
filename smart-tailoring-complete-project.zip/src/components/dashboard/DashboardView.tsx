import React, { useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { ProductionStatus, PaymentStatus } from '../../types';
import { ProductionStatusBadge, PaymentStatusBadge } from '../common/StatusBadge';
import { EmptyState } from '../common/EmptyState';
import {
  Users,
  ShoppingBag,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  DollarSign,
  TrendingUp,
  Plus,
  Ruler,
  Calculator,
  Calendar,
  ChevronRight,
  Sparkles,
  ArrowRight,
  Layers,
  Mic,
  Radio,
  Rocket
} from 'lucide-react';

interface DashboardViewProps {
  onOpenNewOrder: () => void;
  onOpenNewCustomer: () => void;
  onSelectOrder: (orderId: string) => void;
  onSelectCustomer: (customerId: string) => void;
  onOpenTranscribe?: () => void;
  onOpenLiveVoice?: () => void;
  onOpenAuth?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onOpenNewOrder,
  onOpenNewCustomer,
  onSelectOrder,
  onSelectCustomer,
  onOpenTranscribe,
  onOpenLiveVoice,
  onOpenAuth,
}) => {
  const {
    user,
    isDemo,
    customers,
    orders,
    payments,
    materials,
    setActiveTab,
    formatCurrency
  } = useApp();

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  // Metrics calculation
  const totalCustomers = customers.length;
  const activeOrders = orders.filter(o => o.productionStatus !== 'Delivered' && o.productionStatus !== 'Cancelled');
  const completedOrders = orders.filter(o => o.productionStatus === 'Delivered');
  const outstandingPayments = orders.reduce((sum, o) => sum + o.balanceDue, 0);
  const totalRevenue = orders.reduce((sum, o) => sum + o.sellingPrice, 0);

  // This month's revenue (from orders created this month)
  const thisMonthRevenue = useMemo(() => {
    return orders
      .filter(o => {
        const d = new Date(o.createdAt);
        return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
      })
      .reduce((sum, o) => sum + o.sellingPrice, 0);
  }, [orders, currentMonth, currentYear]);

  // Customer Map
  const customerMap = useMemo(() => {
    const map = new Map<string, string>();
    customers.forEach(c => map.set(c.id, c.fullName));
    return map;
  }, [customers]);

  // Recent 5 orders
  const recentOrders = useMemo(() => {
    return [...orders]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);
  }, [orders]);

  // Upcoming delivery alerts (orders due within 5 days that are not yet delivered)
  const urgentOrders = useMemo(() => {
    const fiveDaysMs = 5 * 24 * 60 * 60 * 1000;
    return orders.filter(o => {
      if (o.productionStatus === 'Delivered' || o.productionStatus === 'Cancelled') return false;
      const deliveryTime = new Date(o.deliveryDate).getTime();
      return deliveryTime - now.getTime() <= fiveDaysMs;
    });
  }, [orders, now]);

  // Low stock materials
  const lowStockMaterials = useMemo(() => {
    return materials.filter(m => m.quantity <= m.lowStockThreshold);
  }, [materials]);

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-[#58111A] to-[#3E0A12] text-white p-6 sm:p-7 rounded-3xl shadow-sm relative overflow-hidden">
        {/* Northern Nigerian Atelier Backdrop Image */}
        <div className="absolute inset-0 pointer-events-none opacity-20">
          <img
            src="/src/assets/images/northern_nigerian_tailor_atelier_1791211874242.jpg"
            alt=""
            aria-hidden="true"
            className="w-full h-full object-cover object-right"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#58111A] via-[#58111A]/90 to-transparent" />
        </div>

        <div className="relative z-10 max-w-2xl space-y-2">
          <span className="text-xs uppercase tracking-widest text-amber-300 font-bold flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Atelier Overview · Northern Nigerian Couture</span>
          </span>
          <h1 className="text-2xl sm:text-3xl font-bold font-serif-display tracking-tight text-white">
            Welcome, {user?.ownerName || 'Master Tailor'}
          </h1>
          <p className="text-xs sm:text-sm text-amber-100/80 leading-relaxed">
            {user?.businessName} · You have <strong className="text-white font-semibold">{activeOrders.length} active orders</strong> currently in cutting, sewing, or fitting.
          </p>

          <div className="pt-2 flex flex-wrap gap-2.5">
            {isDemo && onOpenAuth && (
              <button
                onClick={onOpenAuth}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white text-[#58111A] hover:bg-amber-100 text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                <Rocket className="w-4 h-4 text-[#58111A]" />
                <span>Go Live / Create My Atelier</span>
              </button>
            )}
            <button
              onClick={onOpenNewOrder}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#C5A059] hover:bg-[#b38e47] text-stone-950 text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create Order</span>
            </button>
            <button
              onClick={onOpenNewCustomer}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
            >
              <Users className="w-4 h-4" />
              <span>+ Add Customer</span>
            </button>
            {onOpenLiveVoice && (
              <button
                onClick={onOpenLiveVoice}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-600 hover:to-amber-500 text-stone-950 text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                <Radio className="w-4 h-4 animate-pulse text-stone-950" />
                <span>Talk with Unaabs AI</span>
              </button>
            )}
            {onOpenTranscribe && (
              <button
                onClick={onOpenTranscribe}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                <Mic className="w-4 h-4 text-amber-300" />
                <span>Voice Dictate</span>
              </button>
            )}
            <button
              onClick={() => setActiveTab('calculator')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
            >
              <Calculator className="w-4 h-4" />
              <span>Pricing Calculator</span>
            </button>
          </div>
        </div>
      </div>

      {/* Overview Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Card 1: Total Customers */}
        <div
          onClick={() => setActiveTab('customers')}
          className="bg-white p-4 rounded-2xl border border-stone-200/80 shadow-2xs hover:border-[#58111A]/40 transition-all cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-stone-100 text-stone-600 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <Users className="w-4 h-4 text-[#58111A]" />
          </div>
          <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider block">
            Total Customers
          </span>
          <p className="text-xl font-bold font-mono text-stone-900 mt-0.5">
            {totalCustomers}
          </p>
        </div>

        {/* Card 2: Active Orders */}
        <div
          onClick={() => setActiveTab('orders')}
          className="bg-white p-4 rounded-2xl border border-stone-200/80 shadow-2xs hover:border-[#58111A]/40 transition-all cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <ShoppingBag className="w-4 h-4" />
          </div>
          <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider block">
            Active Orders
          </span>
          <p className="text-xl font-bold font-mono text-amber-800 mt-0.5">
            {activeOrders.length}
          </p>
        </div>

        {/* Card 3: Completed Orders */}
        <div
          onClick={() => setActiveTab('orders')}
          className="bg-white p-4 rounded-2xl border border-stone-200/80 shadow-2xs hover:border-[#58111A]/40 transition-all cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider block">
            Completed
          </span>
          <p className="text-xl font-bold font-mono text-emerald-800 mt-0.5">
            {completedOrders.length}
          </p>
        </div>

        {/* Card 4: Outstanding Payments */}
        <div
          onClick={() => setActiveTab('payments')}
          className="bg-white p-4 rounded-2xl border border-stone-200/80 shadow-2xs hover:border-[#58111A]/40 transition-all cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <CreditCard className="w-4 h-4" />
          </div>
          <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider block">
            Outstanding
          </span>
          <p className="text-base sm:text-lg font-bold font-mono text-[#58111A] mt-0.5 truncate">
            {formatCurrency(outstandingPayments)}
          </p>
        </div>

        {/* Card 5: Total Revenue */}
        <div
          onClick={() => setActiveTab('reports')}
          className="bg-white p-4 rounded-2xl border border-stone-200/80 shadow-2xs hover:border-[#58111A]/40 transition-all cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <DollarSign className="w-4 h-4 text-emerald-700" />
          </div>
          <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider block">
            Total Revenue
          </span>
          <p className="text-base sm:text-lg font-bold font-mono text-stone-900 mt-0.5 truncate">
            {formatCurrency(totalRevenue)}
          </p>
        </div>

        {/* Card 6: This Month's Revenue */}
        <div
          onClick={() => setActiveTab('reports')}
          className="bg-white p-4 rounded-2xl border border-stone-200/80 shadow-2xs hover:border-[#58111A]/40 transition-all cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
            <TrendingUp className="w-4 h-4" />
          </div>
          <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider block">
            This Month
          </span>
          <p className="text-base sm:text-lg font-bold font-mono text-emerald-800 mt-0.5 truncate">
            {formatCurrency(thisMonthRevenue)}
          </p>
        </div>
      </div>

      {/* Notifications / Alerts Row (Urgent deliveries & low stock) */}
      {(urgentOrders.length > 0 || lowStockMaterials.length > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {urgentOrders.length > 0 && (
            <div className="p-4 bg-amber-50/90 border border-amber-200 rounded-2xl flex items-start gap-3">
              <div className="p-2 rounded-xl bg-amber-100 text-amber-800 shrink-0">
                <Calendar className="w-4 h-4" />
              </div>
              <div className="flex-1 text-xs">
                <h4 className="font-bold text-amber-950">
                  {urgentOrders.length} Order{urgentOrders.length > 1 ? 's' : ''} Due in the Next 5 Days
                </h4>
                <p className="text-amber-900/80 mt-0.5">
                  Prepare for client fittings: {urgentOrders.map(o => o.orderNumber).join(', ')}
                </p>
                <button
                  onClick={() => setActiveTab('orders')}
                  className="mt-2 text-xs font-bold text-[#58111A] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Review Delivery Schedule</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}

          {lowStockMaterials.length > 0 && (
            <div className="p-4 bg-rose-50/80 border border-rose-200 rounded-2xl flex items-start gap-3">
              <div className="p-2 rounded-xl bg-rose-100 text-rose-700 shrink-0">
                <Layers className="w-4 h-4" />
              </div>
              <div className="flex-1 text-xs">
                <h4 className="font-bold text-rose-950">
                  {lowStockMaterials.length} Haberdashery Items Low in Stock
                </h4>
                <p className="text-rose-900/80 mt-0.5">
                  {lowStockMaterials.map(m => m.name).slice(0, 2).join(', ')} {lowStockMaterials.length > 2 && `+${lowStockMaterials.length - 2} more`}
                </p>
                <button
                  onClick={() => setActiveTab('materials')}
                  className="mt-2 text-xs font-bold text-[#58111A] hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>Restock Materials</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Recent Orders Section */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold font-serif-display text-stone-900">
              Recent Garment Orders
            </h3>
            <p className="text-xs text-stone-500">Latest bespoke projects in workshop queue</p>
          </div>

          <button
            onClick={() => setActiveTab('orders')}
            className="text-xs font-bold text-[#58111A] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>View All ({orders.length})</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {recentOrders.length === 0 ? (
          <EmptyState
            icon={ShoppingBag}
            title="No orders logged yet"
            description="Create your first bespoke order to track client measurements, fabric, cutting stages, and payments."
            actionLabel="Create First Order"
            onAction={onOpenNewOrder}
          />
        ) : (
          <div className="space-y-3">
            {recentOrders.map((order) => {
              const customerName = customerMap.get(order.customerId) || 'Client';
              const pStatus: PaymentStatus =
                order.balanceDue <= 0 ? 'Paid' : order.amountPaid > 0 ? 'Partial' : 'Unpaid';

              return (
                <div
                  key={order.id}
                  onClick={() => onSelectOrder(order.id)}
                  className="p-4 rounded-xl border border-stone-100 hover:border-stone-300 hover:bg-stone-50/50 transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
                >
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono font-bold text-xs text-stone-900">{order.orderNumber}</span>
                      <span className="text-stone-300">·</span>
                      <span className="font-semibold text-xs text-stone-800">{customerName}</span>
                      <ProductionStatusBadge status={order.productionStatus} size="sm" />
                      <PaymentStatusBadge status={pStatus} size="sm" />
                    </div>

                    <div className="flex items-center gap-2 text-xs text-stone-500 mt-1">
                      <span className="font-medium text-[#58111A]">
                        {order.outfitType === 'Custom' ? order.customOutfitType : order.outfitType}
                      </span>
                      <span>·</span>
                      <span>Delivery: {new Date(order.deliveryDate).toLocaleDateString()}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-5">
                    <div className="text-left sm:text-right">
                      <span className="font-mono font-bold text-xs text-stone-900 block">
                        {formatCurrency(order.sellingPrice)}
                      </span>
                      <span className="font-mono text-[11px] text-stone-500">
                        {order.balanceDue > 0 ? (
                          <span className="text-[#58111A]">Due: {formatCurrency(order.balanceDue)}</span>
                        ) : (
                          <span className="text-emerald-700">Settled</span>
                        )}
                      </span>
                    </div>

                    <ChevronRight className="w-4 h-4 text-stone-400 group-hover:text-[#58111A] group-hover:translate-x-0.5 transition-all" />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Atelier Craftsmanship Visual Banner */}
      <div className="bg-[#FAF7F2] p-5 rounded-2xl border border-stone-200/70 flex flex-col sm:flex-row items-center gap-5">
        <div className="w-full sm:w-52 h-36 rounded-xl overflow-hidden shrink-0 shadow-xs">
          <img
            src="/src/assets/images/northern_nigerian_couture_craft_1791211885077.jpg"
            alt="Northern Nigerian luxury Guinea brocade shadda, Zanna Bukar cap, and tailor shears"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="space-y-1.5 text-xs text-stone-600">
          <span className="text-[10px] uppercase font-bold text-[#C5A059] tracking-wider">
            Northern Nigerian Couture Mastery
          </span>
          <h4 className="font-bold text-stone-900 text-sm font-serif-display">
            Precision Shadda, Guinea Brocade & Royal Embroidery
          </h4>
          <p className="leading-relaxed">
            Record distinct measurement profiles for grand Agbadas, crisp Babbar Riga, luxury Abayas, and bespoke Kaftans to ensure perfect drape and accurate collar tolerances every time.
          </p>
        </div>
      </div>
    </div>
  );
};
