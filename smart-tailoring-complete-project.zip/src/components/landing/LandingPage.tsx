import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Scissors,
  Users,
  Ruler,
  ShoppingBag,
  CreditCard,
  Calculator,
  BarChart3,
  ArrowRight,
  CheckCircle2,
  Sparkles,
  ShieldCheck,
  ChevronRight,
  Mic,
  Radio,
  Search
} from 'lucide-react';
import { PWAInstallButton } from '../common/PWAInstallButton';

interface LandingPageProps {
  onOpenAuth: () => void;
  onExploreDemo: () => void;
  onOpenTracking: () => void;
  onOpenOwnerPortal: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onOpenAuth,
  onExploreDemo,
  onOpenTracking,
  onOpenOwnerPortal
}) => {
  return (
    <div className="min-h-screen bg-[#FDFBF7] text-stone-900 flex flex-col font-sans">
      {/* Top Header */}
      <header className="sticky top-0 z-30 bg-[#FDFBF7]/90 backdrop-blur-md border-b border-stone-200/80 px-4 md:px-8 py-3.5">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#58111A] text-amber-300 flex items-center justify-center shadow-xs">
              <Scissors className="w-4 h-4" />
            </div>
            <span className="text-xl font-bold tracking-tight text-[#58111A] font-serif-display">
              Smart Tailoring
            </span>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            <button
              onClick={onOpenTracking}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-700 hover:text-[#58111A] px-2.5 py-1.5 rounded-lg hover:bg-stone-100 transition-colors cursor-pointer"
              title="Track custom outfit by order number"
            >
              <Search className="w-3.5 h-3.5 text-stone-500" />
              <span>Track Order</span>
            </button>

            <button
              onClick={onOpenOwnerPortal}
              className="inline-flex items-center gap-1 text-xs font-semibold text-stone-600 hover:text-stone-900 px-2.5 py-1.5 rounded-lg hover:bg-stone-100 transition-colors cursor-pointer"
              title="App Owner / Administrator Console"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
              <span className="hidden sm:inline">Owner Portal</span>
            </button>

            <button
              onClick={onExploreDemo}
              className="text-xs font-semibold text-stone-700 hover:text-[#58111A] px-2.5 py-1.5 rounded-lg hover:bg-stone-100 transition-colors cursor-pointer"
            >
              Demo
            </button>

            <PWAInstallButton variant="nav" />

            <button
              onClick={onOpenAuth}
              className="px-3.5 py-2 bg-[#58111A] hover:bg-[#4A0E17] text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              Tailor Sign In
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-stone-200/80">
        {/* Subtle Northern Nigerian Atelier Background Image Treatment */}
        <div className="absolute inset-0 pointer-events-none">
          <img
            src="/src/assets/images/northern_nigerian_tailor_atelier_1791211874242.jpg"
            alt=""
            aria-hidden="true"
            className="w-full h-full object-cover object-center opacity-10 filter blur-xs"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#FDFBF7]/90 via-[#FDFBF7]/95 to-[#FDFBF7]" />
        </div>

        <div className="relative py-12 md:py-20 px-4 md:px-8 max-w-6xl mx-auto w-full">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                <span>Professional Northern Nigerian Couture Tech</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-[#58111A] tracking-tight font-serif-display leading-[1.12]">
                Smart Tailoring
              </h1>
              <p className="text-xl sm:text-2xl font-serif-display italic text-[#C5A059] font-medium">
                Your tailoring business, smarter.
              </p>

              <p className="text-base sm:text-lg text-stone-600 max-w-xl leading-relaxed">
                Manage customers, measurements, orders, payments and your tailoring business from one simple workspace.
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={onOpenAuth}
                  className="px-6 py-3.5 bg-[#58111A] hover:bg-[#4A0E17] text-white font-semibold text-sm rounded-xl shadow-md hover:shadow-lg transition-all flex items-center gap-2 group cursor-pointer"
                >
                  <span>Get Started</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                </button>

                <button
                  onClick={onExploreDemo}
                  className="px-5 py-3.5 bg-white hover:bg-stone-50 border border-stone-300 text-stone-800 font-semibold text-sm rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-amber-600" />
                  <span>Explore Demo</span>
                </button>

                <PWAInstallButton variant="landing" />
              </div>

              <div className="pt-4 flex items-center gap-6 text-xs text-stone-500 font-medium">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Zero complex spreadsheets</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Automatic profit calculations</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-white bg-stone-900 group">
                <img
                  src="/src/assets/images/northern_nigerian_tailor_atelier_1791211874242.jpg"
                  alt="Professional Muslim Northern Nigerian bespoke tailoring atelier in Abuja"
                  className="w-full h-80 sm:h-96 object-cover transform group-hover:scale-102 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent flex flex-col justify-end p-6 text-white">
                  <span className="text-xs uppercase tracking-widest text-amber-300 font-semibold">Unaabs Couture Atelier</span>
                  <p className="font-serif-display text-lg font-bold">Bespoke Kaftans, Abayas & Guinea Brocades</p>
                  <p className="text-xs text-stone-300 mt-1">Crafted for master tailors, modest fashion houses, and couture boutiques in Kano, Kaduna, Abuja, and beyond.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Sections */}
      <section className="py-16 bg-[#F6F2EA] px-4 md:px-8 border-y border-stone-200/80">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-bold font-serif-display text-[#58111A]">
              Engineered for Modern Tailoring Boutiques
            </h2>
            <p className="text-sm text-stone-600 mt-2">
              Everything you need to run your fashion studio smoothly without lost paper notebooks or confusing records.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Feature 1: Customer Management */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-xs hover:shadow-md transition-shadow">
              <div className="w-11 h-11 rounded-xl bg-[#58111A]/10 text-[#58111A] flex items-center justify-center mb-4">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-stone-900 mb-1.5 font-serif-display">
                Customer Management
              </h3>
              <p className="text-sm text-stone-600 leading-relaxed">
                Keep customer information and measurement profiles organized. Access full order history, fitting records, and notes instantly.
              </p>
            </div>

            {/* Feature 2: Smart Measurements */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-xs hover:shadow-md transition-shadow">
              <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center mb-4">
                <Ruler className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-stone-900 mb-1.5 font-serif-display">
                Smart Measurements
              </h3>
              <p className="text-sm text-stone-600 leading-relaxed">
                Save complete measurement profiles and reuse them for future orders. Store multiple profiles per client for Kaftans, Gowns, or Agbadas.
              </p>
            </div>

            {/* Feature 3: Order Tracking */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-xs hover:shadow-md transition-shadow">
              <div className="w-11 h-11 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center mb-4">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-stone-900 mb-1.5 font-serif-display">
                Order Tracking
              </h3>
              <p className="text-sm text-stone-600 leading-relaxed">
                Know what is pending, cutting, sewing, ready for fitting, completed or delivered. Never miss a client's wedding or event deadline.
              </p>
            </div>

            {/* Feature 4: Payments */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-xs hover:shadow-md transition-shadow">
              <div className="w-11 h-11 rounded-xl bg-sky-50 text-sky-800 flex items-center justify-center mb-4">
                <CreditCard className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-stone-900 mb-1.5 font-serif-display">
                Payments
              </h3>
              <p className="text-sm text-stone-600 leading-relaxed">
                Track total order value, amount paid and outstanding balance. Record multiple installment deposits and generate receipts.
              </p>
            </div>

            {/* Feature 5: Pricing Calculator */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-xs hover:shadow-md transition-shadow">
              <div className="w-11 h-11 rounded-xl bg-rose-50 text-rose-800 flex items-center justify-center mb-4">
                <Calculator className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-stone-900 mb-1.5 font-serif-display">
                Pricing Calculator
              </h3>
              <p className="text-sm text-stone-600 leading-relaxed">
                Calculate your selling price based on fabric, labour, additional materials, logistics, and desired profit margins with precision.
              </p>
            </div>

            {/* Feature 6: Business Dashboard */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-xs hover:shadow-md transition-shadow">
              <div className="w-11 h-11 rounded-xl bg-purple-50 text-purple-800 flex items-center justify-center mb-4">
                <BarChart3 className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-stone-900 mb-1.5 font-serif-display">
                Business Dashboard
              </h3>
              <p className="text-sm text-stone-600 leading-relaxed">
                See your orders, revenue, outstanding payments and business performance. Know your most profitable garment styles at a glance.
              </p>
            </div>

            {/* Feature 7: Audio Transcription */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-xs hover:shadow-md transition-shadow">
              <div className="w-11 h-11 rounded-xl bg-rose-50 text-rose-700 flex items-center justify-center mb-4">
                <Mic className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-stone-900 mb-1.5 font-serif-display">
                Dictate with Microphone
              </h3>
              <p className="text-sm text-stone-600 leading-relaxed">
                Dictate client measurements, fabric specs, and tailoring notes via microphone. Transcribed accurately into text with model <strong>gemini-3.5-transcribe</strong>.
              </p>
            </div>

            {/* Feature 8: Real-Time Voice Conversations */}
            <div className="bg-white p-6 rounded-2xl border border-stone-200/80 shadow-xs hover:shadow-md transition-shadow">
              <div className="w-11 h-11 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center mb-4">
                <Radio className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-semibold text-stone-900 mb-1.5 font-serif-display">
                Live Voice Assistant
              </h3>
              <p className="text-sm text-stone-600 leading-relaxed">
                Have real-time spoken conversations with the Unaabs Voice Assistant powered by model <strong>gemini-3.8-live</strong> (Live API) to plan garments, yardage, and prices.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 md:py-20 px-4 md:px-8 max-w-5xl mx-auto w-full">
        <div className="text-center max-w-xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-widest text-[#C5A059] font-bold">Effortless Workflow</span>
          <h2 className="text-3xl font-bold font-serif-display text-[#58111A] mt-1">
            How Smart Tailoring Works
          </h2>
          <p className="text-sm text-stone-600 mt-2">
            From first client measurement to final delivery, step-by-step clarity.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { step: '01', title: 'Add your customer', desc: 'Save name, phone number, address, and special styling notes in seconds.' },
            { step: '02', title: 'Record measurements', desc: 'Enter custom anatomical measurements in inches or cm with custom labels.' },
            { step: '03', title: 'Create an order', desc: 'Link fabric, attach measurements, and set delivery deadlines and selling price.' },
            { step: '04', title: 'Track production', desc: 'Update progress from Cutting to Sewing and Fitting stages.' },
            { step: '05', title: 'Record payment', desc: 'Log initial advance deposits and track remaining balances effortlessly.' },
            { step: '06', title: 'Deliver the outfit', desc: 'Print clean client invoices and mark the outfit happily delivered.' },
          ].map((item) => (
            <div key={item.step} className="p-5 bg-white rounded-xl border border-stone-200/80 relative">
              <span className="text-2xl font-bold font-serif-display text-[#C5A059] block mb-2">{item.step}.</span>
              <h4 className="font-bold text-stone-900 text-sm">{item.title}</h4>
              <p className="text-xs text-stone-500 mt-1 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#58111A] text-white px-4 md:px-8 text-center">
        <div className="max-w-3xl mx-auto space-y-6">
          <div className="w-12 h-12 rounded-full bg-amber-400/20 text-amber-300 mx-auto flex items-center justify-center">
            <Scissors className="w-6 h-6" />
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold font-serif-display">
            Ready to make your tailoring business smarter?
          </h2>
          <p className="text-sm sm:text-base text-amber-100/80 max-w-lg mx-auto">
            Join professional tailors and fashion designers streamlining their customer fittings, fabrics, and revenue.
          </p>
          <div className="pt-2 flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={onOpenAuth}
              className="px-6 py-3.5 bg-[#C5A059] hover:bg-[#b08d48] text-stone-950 font-bold text-sm rounded-xl shadow-lg transition-colors cursor-pointer"
            >
              Start Using Smart Tailoring
            </button>
            <button
              onClick={onExploreDemo}
              className="px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-sm rounded-xl transition-colors cursor-pointer"
            >
              Explore Demo Experience
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-stone-900 text-stone-400 text-xs px-4 md:px-8 border-t border-stone-800">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-white">
            <Scissors className="w-4 h-4 text-amber-400" />
            <span className="font-bold font-serif-display">Smart Tailoring</span>
            <span className="text-stone-500">·</span>
            <span className="text-stone-400 text-[11px]">Your tailoring business, smarter.</span>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4 text-stone-400 text-center sm:text-right">
            <span>© {new Date().getFullYear()} Smart Tailoring</span>
            <span className="hidden sm:inline">·</span>
            <span className="text-[#D4AF37] font-semibold tracking-wide">
              Powered by Unaabs Smart Business
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
};
