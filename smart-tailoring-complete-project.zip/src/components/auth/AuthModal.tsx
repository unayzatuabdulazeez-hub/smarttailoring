import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StorageService } from '../../services/storage';
import { PlatformClient } from '../../services/platformClient';
import { PendingApprovalModal } from './PendingApprovalModal';
import {
  Scissors,
  X,
  Mail,
  Lock,
  Building2,
  User,
  Phone,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultMode?: 'login' | 'signup' | 'admin';
  onAdminLogin?: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  defaultMode = 'signup',
  onAdminLogin
}) => {
  const { login, register, enterDemoMode, showToast } = useApp();
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot' | 'admin'>(
    defaultMode === 'admin' ? 'admin' : defaultMode
  );

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [phone, setPhone] = useState('');
  const [currency, setCurrency] = useState('₦');
  const [error, setError] = useState('');
  const [forgotSent, setForgotSent] = useState(false);
  const [pendingApprovalData, setPendingApprovalData] = useState<{
    email: string;
    businessName: string;
  } | null>(null);

  const registeredUsers = StorageService.getRegisteredUsers();

  if (!isOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail) {
      setError('Please provide your email address.');
      return;
    }

    // 1. Check if App Owner logging in
    if (
      cleanEmail === 'unayzatuabdulazeez@gmail.com' ||
      password === 'unaabs-admin-2026' ||
      password === 'admin123'
    ) {
      try {
        await PlatformClient.adminLogin(cleanEmail, password || 'unaabs-admin-2026');
        onClose();
        if (onAdminLogin) onAdminLogin();
        return;
      } catch (_) {}
    }

    // 2. Check backend approval status for tailor
    try {
      const serverRes = await PlatformClient.loginTailor(cleanEmail);
      if (serverRes.status === 'pending') {
        setPendingApprovalData({
          email: serverRes.tailor.email,
          businessName: serverRes.tailor.businessName
        });
        return;
      }
      if (serverRes.status === 'rejected' || serverRes.status === 'suspended') {
        setError(`Your atelier account is currently ${serverRes.status}. Please contact the platform owner.`);
        return;
      }
    } catch (_) {}

    // 3. Complete local login
    const success = login(cleanEmail);
    if (success) {
      onClose();
    } else {
      setError(`No account found for "${email.trim()}". You can create your tailor account in 30 seconds using the tab above.`);
    }
  };

  const handleAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      await PlatformClient.adminLogin(email.trim(), password.trim());
      onClose();
      if (onAdminLogin) onAdminLogin();
    } catch (err: any) {
      setError(err.message || 'Invalid administrator passkey or owner email.');
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email.trim() || !businessName.trim() || !ownerName.trim()) {
      setError('Business name, owner name, and email are required.');
      return;
    }

    // Register with backend & check if platform owner approval is required
    try {
      const regRes = await PlatformClient.registerTailor({
        email: email.trim(),
        businessName: businessName.trim(),
        ownerName: ownerName.trim(),
        phone: phone.trim(),
        currency
      });

      if (regRes.requiresApproval) {
        setPendingApprovalData({
          email: email.trim(),
          businessName: businessName.trim()
        });
        return;
      }
    } catch (err: any) {
      console.warn('Backend sync note:', err.message);
    }

    register({
      email,
      businessName,
      ownerName,
      phone,
      currency
    });
    onClose();
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setError('Please enter your email to receive recovery instructions.');
      return;
    }
    setForgotSent(true);
    showToast('Password recovery instructions sent to your email.', 'info');
  };

  const handleExploreDemo = () => {
    enterDemoMode();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-stone-200">
        {/* Header */}
        <div className="bg-[#58111A] text-white px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-400/20 text-amber-300 flex items-center justify-center">
              <Scissors className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif-display font-bold text-lg leading-tight">Smart Tailoring</h3>
              <p className="text-[11px] text-amber-200/80">Your tailoring business, smarter.</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-stone-300 hover:text-white p-1 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switchers */}
        <div className="flex border-b border-stone-200 bg-stone-50 text-xs font-semibold">
          <button
            onClick={() => { setMode('login'); setError(''); }}
            className={`flex-1 py-3 text-center transition-colors ${
              mode === 'login'
                ? 'bg-white text-[#58111A] border-b-2 border-[#58111A]'
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            Log In
          </button>
          <button
            onClick={() => { setMode('signup'); setError(''); }}
            className={`flex-1 py-3 text-center transition-colors ${
              mode === 'signup'
                ? 'bg-white text-[#58111A] border-b-2 border-[#58111A]'
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            Create Atelier Account
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6">
          {error && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-medium">
              {error}
            </div>
          )}

          {mode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. tailor@atelier.ng"
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => setMode('forgot')}
                    className="text-xs text-[#58111A] hover:underline font-medium"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#58111A] hover:bg-[#4A0E17] text-white font-semibold text-sm rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                Log In to Atelier
              </button>

              {registeredUsers.length > 0 && (
                <div className="pt-3 border-t border-stone-200">
                  <p className="text-[11px] font-bold text-stone-500 uppercase tracking-wider mb-2">
                    Accounts Registered on this Device:
                  </p>
                  <div className="space-y-1.5 max-h-36 overflow-y-auto">
                    {registeredUsers.map((u) => (
                      <button
                        key={u.id}
                        type="button"
                        onClick={() => {
                          login(u.email);
                          onClose();
                        }}
                        className="w-full flex items-center justify-between p-2.5 rounded-xl bg-stone-50 hover:bg-stone-100 border border-stone-200 text-left transition-colors cursor-pointer"
                      >
                        <div>
                          <span className="block font-bold text-xs text-stone-900">{u.name}</span>
                          <span className="block text-[11px] text-stone-500 font-mono">{u.email}</span>
                        </div>
                        <span className="text-[10px] font-bold text-[#58111A] bg-amber-50 px-2 py-1 rounded-lg border border-amber-200">
                          Sign In →
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </form>
          )}

          {mode === 'signup' && (
            <form onSubmit={handleSignup} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Business / Atelier Name *
                </label>
                <div className="relative">
                  <Building2 className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="text"
                    required
                    value={businessName}
                    onChange={(e) => setBusinessName(e.target.value)}
                    placeholder="e.g. Royal Stitch Couture"
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                    Owner Name *
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                    <input
                      type="text"
                      required
                      value={ownerName}
                      onChange={(e) => setOwnerName(e.target.value)}
                      placeholder="e.g. Fatima Bello"
                      className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                    Currency
                  </label>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                  >
                    <option value="₦">₦ (Naira - NGN)</option>
                    <option value="$">$ (USD)</option>
                    <option value="£">£ (GBP)</option>
                    <option value="€">€ (EUR)</option>
                    <option value="GH₵">GH₵ (Cedi)</option>
                    <option value="KSh">KSh (KES)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Email Address *
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. tailor@atelier.ng"
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Phone Number
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+234 800 000 0000"
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Password *
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#58111A] hover:bg-[#4A0E17] text-white font-semibold text-sm rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                Create Private Studio Workspace
              </button>
            </form>
          )}

          {mode === 'forgot' && (
            <div className="space-y-4">
              {forgotSent ? (
                <div className="text-center p-4 bg-emerald-50 rounded-xl border border-emerald-200">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
                  <h4 className="font-bold text-emerald-900 text-sm">Reset Link Sent</h4>
                  <p className="text-xs text-stone-600 mt-1">
                    Check your inbox at <span className="font-semibold text-stone-800">{email}</span> for recovery steps.
                  </p>
                  <button
                    onClick={() => { setMode('login'); setForgotSent(false); }}
                    className="mt-4 px-4 py-1.5 bg-emerald-700 text-white rounded-lg text-xs font-medium"
                  >
                    Return to Login
                  </button>
                </div>
              ) : (
                <form onSubmit={handleForgotPassword} className="space-y-4">
                  <p className="text-xs text-stone-600">
                    Enter your registered email address and we'll send password recovery instructions.
                  </p>
                  <div>
                    <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                      Email Address
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="e.g. tailor@atelier.ng"
                        className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setMode('login')}
                      className="w-1/3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      className="w-2/3 py-2 bg-[#58111A] hover:bg-[#4A0E17] text-white text-xs font-semibold rounded-xl"
                    >
                      Send Reset Instructions
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* Mode Admin Form */}
          {mode === 'admin' && (
            <form onSubmit={handleAdminSubmit} className="space-y-4">
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 font-semibold flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0" />
                <span>Restricted to App Owner / Platform Super Administrator</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Owner Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="unayzatuabdulazeez@gmail.com"
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Administrator Passkey
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter passkey (e.g. unaabs-admin-2026)"
                    className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>Access Platform Owner Console</span>
              </button>
            </form>
          )}

          {/* Quick Demo Mode CTA */}
          <div className="mt-6 pt-5 border-t border-stone-200">
            <button
              onClick={handleExploreDemo}
              className="w-full py-2 px-3 bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-900 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Explore Demo Atelier (Instant Access)</span>
              <ArrowRight className="w-3.5 h-3.5 text-amber-700 ml-auto" />
            </button>
          </div>
        </div>

        {/* Modal Footer with Owner Login Toggle */}
        <div className="px-6 py-3 bg-stone-50 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
          <button
            type="button"
            onClick={() => setMode(mode === 'admin' ? 'login' : 'admin')}
            className="text-[11px] text-stone-600 hover:text-stone-900 font-semibold flex items-center gap-1 cursor-pointer"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
            <span>{mode === 'admin' ? '← Back to Tailor Login' : 'App Owner Portal'}</span>
          </button>
          <span className="text-[10px] text-stone-400">Unaabs Smart Network</span>
        </div>
      </div>

      {/* Pending Approval Modal */}
      {pendingApprovalData && (
        <PendingApprovalModal
          isOpen={!!pendingApprovalData}
          onClose={() => setPendingApprovalData(null)}
          tailorEmail={pendingApprovalData.email}
          tailorBusinessName={pendingApprovalData.businessName}
          onApproved={() => {
            login(pendingApprovalData.email);
            setPendingApprovalData(null);
            onClose();
          }}
        />
      )}
    </div>
  );
};
