import React, { useState } from 'react';
import { Clock, Phone, MessageCircle, RefreshCw, X, ShieldCheck } from 'lucide-react';
import { PlatformClient } from '../../services/platformClient';

interface PendingApprovalModalProps {
  isOpen: boolean;
  onClose: () => void;
  tailorEmail: string;
  tailorBusinessName?: string;
  ownerWhatsApp?: string;
  onApproved: () => void;
}

export const PendingApprovalModal: React.FC<PendingApprovalModalProps> = ({
  isOpen,
  onClose,
  tailorEmail,
  tailorBusinessName = 'Your Atelier',
  ownerWhatsApp = '+234 803 555 0192',
  onApproved
}) => {
  const [checking, setChecking] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');

  if (!isOpen) return null;

  const handleCheckStatus = async () => {
    setChecking(true);
    setStatusMsg('');
    try {
      const res = await PlatformClient.loginTailor(tailorEmail);
      if (res.status === 'approved') {
        setStatusMsg('Congratulations! Your atelier has been approved by the platform owner.');
        setTimeout(() => {
          onApproved();
        }, 1200);
      } else {
        setStatusMsg('Your request is still awaiting review by the platform administrator.');
      }
    } catch {
      setStatusMsg('Still awaiting review. Please check back shortly.');
    } finally {
      setChecking(false);
    }
  };

  const getWhatsAppExpediteLink = () => {
    const cleanPhone = ownerWhatsApp.replace(/[^0-9]/g, '');
    const text = encodeURIComponent(
      `Hello Unaabs Platform Owner, I submitted a registration for my tailor atelier "${tailorBusinessName}" (${tailorEmail}) on Smart Tailoring. Kindly review and approve my account. Thank you!`
    );
    return `https://wa.me/${cleanPhone}?text=${text}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl overflow-hidden border border-stone-200 text-center p-6 sm:p-7 space-y-5">
        <div className="flex justify-end">
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-stone-600 p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="w-16 h-16 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto shadow-inner">
          <Clock className="w-8 h-8 animate-pulse" />
        </div>

        <div>
          <span className="text-[11px] font-bold uppercase tracking-widest text-amber-800 bg-amber-100 px-3 py-1 rounded-full">
            Under Administrator Review
          </span>
          <h3 className="font-serif-display font-bold text-2xl text-stone-900 mt-3">
            Registration Awaiting Approval
          </h3>
          <p className="text-xs text-stone-600 mt-2 leading-relaxed">
            Welcome to the Smart Tailoring Network! The platform owner verifies each atelier before granting live access to maintain quality standards.
          </p>
        </div>

        <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 text-left text-xs space-y-1">
          <p className="text-stone-500">
            Registered Shop: <strong className="text-stone-800">{tailorBusinessName}</strong>
          </p>
          <p className="text-stone-500">
            Registered Email: <strong className="text-stone-800">{tailorEmail}</strong>
          </p>
        </div>

        {statusMsg && (
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 font-semibold">
            {statusMsg}
          </div>
        )}

        <div className="space-y-2 pt-2">
          <a
            href={getWhatsAppExpediteLink()}
            target="_blank"
            rel="noreferrer"
            className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Message Platform Owner on WhatsApp</span>
          </a>

          <button
            type="button"
            onClick={handleCheckStatus}
            disabled={checking}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-semibold transition-all cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${checking ? 'animate-spin' : ''}`} />
            <span>{checking ? 'Checking status...' : 'Check Approval Status'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
