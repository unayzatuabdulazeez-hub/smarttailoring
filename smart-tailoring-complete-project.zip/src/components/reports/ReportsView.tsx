import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  BarChart3,
  TrendingUp,
  DollarSign,
  ShoppingBag,
  Calendar,
  Layers,
  Award,
  Clock,
  ArrowUpRight,
  Filter
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { orders, payments, customers, formatCurrency } = useApp();

  const [dateRange, setDateRange] = useState<'all' | 'this-month' | 'last-30' | 'this-year'>('all');

  const now = new Date();

  // Filtered orders & payments based on date range
  const { filteredOrders, filteredPayments } = useMemo(() => {
    let cutoff = new Date(0); // all time

    if (dateRange === 'this-month') {
      cutoff = new Date(now.getFullYear(), now.getMonth(), 1);
    } else if (dateRange === 'last-30') {
      cutoff = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    } else if (dateRange === 'this-year') {
      cutoff = new Date(now.getFullYear(), 0, 1);
    }

    const oList = orders.filter(o => new Date(o.createdAt) >= cutoff);
    const pList = payments.filter(p => new Date(p.paymentDate) >= cutoff);

    return { filteredOrders: oList, filteredPayments: pList };
  }, [orders, payments, dateRange]);

  // Aggregate Metrics
  const totalRevenue = filteredOrders.reduce((sum, o) => sum + o.sellingPrice, 0);
  const amountCollected = filteredPayments.reduce((sum, p) => sum + p.amount, 0);
  const outstandingBalance = filteredOrders.reduce((sum, o) => sum + o.balanceDue, 0);
  const totalEstimatedProfit = filteredOrders.reduce((sum, o) => sum + o.profit, 0);
  const totalProductionCosts = filteredOrders.reduce((sum, o) => sum + o.totalCost, 0);

  // Status breakdown
  const completedOrders = filteredOrders.filter(o => o.productionStatus === 'Delivered').length;
  const inProgressOrders = filteredOrders.filter(o => o.productionStatus !== 'Delivered' && o.productionStatus !== 'Cancelled').length;
  const cancelledOrders = filteredOrders.filter(o => o.productionStatus === 'Cancelled').length;

  // Best performing outfit types
  const outfitPerformance = useMemo(() => {
    const map = new Map<string, { count: number; revenue: number; profit: number }>();
    filteredOrders.forEach(o => {
      const type = o.outfitType === 'Custom' ? (o.customOutfitType || 'Custom') : o.outfitType;
      const cur = map.get(type) || { count: 0, revenue: 0, profit: 0 };
      map.set(type, {
        count: cur.count + 1,
        revenue: cur.revenue + o.sellingPrice,
        profit: cur.profit + o.profit
      });
    });

    return Array.from(map.entries())
      .map(([name, data]) => ({ name, ...data }))
      .sort((a, b) => b.revenue - a.revenue);
  }, [filteredOrders]);

  // Monthly Revenue breakdown for the chart (last 6 months)
  const monthlyChartData = useMemo(() => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const result: { month: string; revenue: number; ordersCount: number }[] = [];

    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const mIdx = d.getMonth();
      const yr = d.getFullYear();
      const label = `${months[mIdx]} '${String(yr).slice(-2)}`;

      const mOrders = orders.filter(o => {
        const od = new Date(o.createdAt);
        return od.getMonth() === mIdx && od.getFullYear() === yr;
      });

      const mRevenue = mOrders.reduce((sum, o) => sum + o.sellingPrice, 0);
      result.push({
        month: label,
        revenue: mRevenue,
        ordersCount: mOrders.length
      });
    }
    return result;
  }, [orders]);

  const maxChartRevenue = Math.max(...monthlyChartData.map(d => d.revenue), 100000);

  return (
    <div className="space-y-6">
      {/* Top action bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-serif-display text-stone-900 tracking-tight">
            Business Performance & Reports
          </h1>
          <p className="text-xs text-stone-500 mt-0.5">
            Real financial and production statistics calculated directly from your atelier database
          </p>
        </div>

        {/* Date Filter */}
        <div className="flex bg-white p-1 rounded-xl border border-stone-200 shadow-2xs self-start sm:self-auto">
          {[
            { id: 'all', label: 'All Time' },
            { id: 'this-month', label: 'This Month' },
            { id: 'last-30', label: 'Last 30 Days' },
            { id: 'this-year', label: 'This Year' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setDateRange(tab.id as any)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                dateRange === tab.id
                  ? 'bg-[#58111A] text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Aggregate Scorecards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
          <span className="text-xs uppercase font-bold text-stone-400 tracking-wider block">
            Total Invoiced
          </span>
          <p className="text-2xl font-bold font-mono text-stone-900 mt-1">
            {formatCurrency(totalRevenue)}
          </p>
          <span className="text-[11px] text-stone-500 mt-1 block">Across {filteredOrders.length} orders</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
          <span className="text-xs uppercase font-bold text-stone-400 tracking-wider block">
            Cash Collected
          </span>
          <p className="text-2xl font-bold font-mono text-emerald-700 mt-1">
            {formatCurrency(amountCollected)}
          </p>
          <span className="text-[11px] text-emerald-800/80 mt-1 block">Settled client payments</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
          <span className="text-xs uppercase font-bold text-stone-400 tracking-wider block">
            Outstanding Due
          </span>
          <p className="text-2xl font-bold font-mono text-[#58111A] mt-1">
            {formatCurrency(outstandingBalance)}
          </p>
          <span className="text-[11px] text-stone-500 mt-1 block">Pending final delivery</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
          <span className="text-xs uppercase font-bold text-stone-400 tracking-wider block">
            Estimated Net Profit
          </span>
          <p className="text-2xl font-bold font-mono text-amber-700 mt-1">
            {formatCurrency(totalEstimatedProfit)}
          </p>
          <span className="text-[11px] text-stone-500 mt-1 block">After labour & materials</span>
        </div>
      </div>

      {/* Charts & Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Monthly Revenue Trend SVG Chart (7 cols) */}
        <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold font-serif-display text-stone-900">
                Revenue Trajectory (Past 6 Months)
              </h3>
              <p className="text-xs text-stone-400">Order bookings by month</p>
            </div>
            <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
              Live Data
            </span>
          </div>

          {/* Bar Chart Visualization */}
          <div className="pt-6 pb-2">
            <div className="h-56 flex items-end gap-3 sm:gap-6 justify-between px-2 border-b border-stone-200">
              {monthlyChartData.map((d, idx) => {
                const heightPercent = Math.max(10, Math.round((d.revenue / maxChartRevenue) * 100));
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2 group h-full justify-end">
                    <span className="text-[10px] font-mono text-stone-400 opacity-0 group-hover:opacity-100 transition-opacity truncate">
                      {formatCurrency(d.revenue)}
                    </span>
                    <div
                      style={{ height: `${heightPercent}%` }}
                      className="w-full bg-[#58111A] hover:bg-[#C5A059] rounded-t-lg transition-all relative group-hover:scale-y-102 origin-bottom shadow-xs"
                    >
                      {d.ordersCount > 0 && (
                        <span className="absolute top-1 left-1/2 -translate-x-1/2 text-[9px] font-bold text-white/90">
                          {d.ordersCount}
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] font-semibold text-stone-600 truncate">
                      {d.month}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right: Production Pipeline distribution (5 cols) */}
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
          <h3 className="text-sm font-bold font-serif-display text-stone-900">
            Garment Production Health
          </h3>

          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between p-3 bg-emerald-50/80 rounded-xl border border-emerald-200 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-emerald-600" />
                <span className="font-semibold text-emerald-950">Delivered & Completed</span>
              </div>
              <span className="font-bold font-mono text-emerald-900 text-sm">{completedOrders}</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-amber-50/80 rounded-xl border border-amber-200 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-amber-500" />
                <span className="font-semibold text-amber-950">In Progress (Cutting, Sewing, Fitting)</span>
              </div>
              <span className="font-bold font-mono text-amber-900 text-sm">{inProgressOrders}</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-stone-400" />
                <span className="font-semibold text-stone-700">Cancelled / Inactive</span>
              </div>
              <span className="font-bold font-mono text-stone-700 text-sm">{cancelledOrders}</span>
            </div>
          </div>

          <div className="border-t border-stone-100 pt-3 text-xs text-stone-500">
            <div className="flex justify-between py-1">
              <span>Gross Production Costs:</span>
              <span className="font-mono font-medium text-stone-800">{formatCurrency(totalProductionCosts)}</span>
            </div>
            <div className="flex justify-between py-1 font-semibold text-emerald-800">
              <span>Overall Atelier Margin:</span>
              <span className="font-mono">
                {totalRevenue > 0 ? Math.round((totalEstimatedProfit / totalRevenue) * 100) : 0}%
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Best-performing Outfit Types Ranking */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-500" />
            <h3 className="text-sm font-bold font-serif-display text-stone-900">
              Top Garment Categories by Revenue
            </h3>
          </div>
          <span className="text-xs text-stone-400">Ranked by client demand</span>
        </div>

        {outfitPerformance.length === 0 ? (
          <p className="text-xs text-stone-400 py-4 text-center">No orders recorded for this period.</p>
        ) : (
          <div className="divide-y divide-stone-100 text-xs">
            {outfitPerformance.map((item, idx) => (
              <div key={item.name} className="py-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-full bg-stone-100 text-stone-600 font-bold font-mono flex items-center justify-center text-xs">
                    {idx + 1}
                  </span>
                  <div>
                    <span className="font-bold text-stone-900 text-sm">{item.name}</span>
                    <span className="text-stone-400 ml-2">({item.count} orders crafted)</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-bold font-mono text-stone-900 text-sm block">
                    {formatCurrency(item.revenue)}
                  </span>
                  <span className="text-emerald-700 font-mono text-[11px]">
                    Est. Profit: {formatCurrency(item.profit)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
