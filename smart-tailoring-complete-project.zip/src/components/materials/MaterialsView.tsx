import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Material, MaterialCategory } from '../../types';
import { EmptyState } from '../common/EmptyState';
import { ConfirmModal } from '../common/ConfirmModal';
import {
  Layers,
  Search,
  Plus,
  AlertTriangle,
  Minus,
  Edit,
  Trash2,
  DollarSign,
  PackageCheck,
  X
} from 'lucide-react';

export const MaterialsView: React.FC = () => {
  const {
    materials,
    addMaterial,
    updateMaterial,
    adjustMaterialQuantity,
    deleteMaterial,
    formatCurrency,
    globalSearch
  } = useApp();

  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [showLowStockOnly, setShowLowStockOnly] = useState(false);

  // Modal states
  const [showModal, setShowModal] = useState(false);
  const [materialToEdit, setMaterialToEdit] = useState<Material | null>(null);
  const [materialToDelete, setMaterialToDelete] = useState<string | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [category, setCategory] = useState<MaterialCategory>('Thread');
  const [quantity, setQuantity] = useState<number>(10);
  const [unit, setUnit] = useState('pieces');
  const [costPerUnit, setCostPerUnit] = useState<number>(0);
  const [lowStockThreshold, setLowStockThreshold] = useState<number>(5);
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState('');

  const activeSearch = globalSearch || search;

  // Valuation & statistics
  const totalValuation = materials.reduce((sum, m) => sum + (m.quantity * m.costPerUnit), 0);
  const lowStockItems = materials.filter(m => m.quantity <= m.lowStockThreshold);

  const categories: MaterialCategory[] = [
    'Thread',
    'Buttons',
    'Zippers',
    'Lining',
    'Interfacing',
    'Beads',
    'Stones',
    'Hooks',
    'Needles',
    'Other'
  ];

  const filteredMaterials = useMemo(() => {
    return materials.filter(m => {
      const matchesSearch =
        !activeSearch ||
        m.name.toLowerCase().includes(activeSearch.toLowerCase()) ||
        m.category.toLowerCase().includes(activeSearch.toLowerCase()) ||
        (m.notes && m.notes.toLowerCase().includes(activeSearch.toLowerCase()));

      if (!matchesSearch) return false;

      if (categoryFilter !== 'all' && m.category !== categoryFilter) {
        return false;
      }

      if (showLowStockOnly && m.quantity > m.lowStockThreshold) {
        return false;
      }

      return true;
    });
  }, [materials, activeSearch, categoryFilter, showLowStockOnly]);

  const handleOpenAdd = () => {
    setMaterialToEdit(null);
    setName('');
    setCategory('Thread');
    setQuantity(10);
    setUnit('pieces');
    setCostPerUnit(0);
    setLowStockThreshold(5);
    setNotes('');
    setFormError('');
    setShowModal(true);
  };

  const handleOpenEdit = (mat: Material) => {
    setMaterialToEdit(mat);
    setName(mat.name);
    setCategory(mat.category);
    setQuantity(mat.quantity);
    setUnit(mat.unit);
    setCostPerUnit(mat.costPerUnit);
    setLowStockThreshold(mat.lowStockThreshold);
    setNotes(mat.notes || '');
    setFormError('');
    setShowModal(true);
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setFormError('Material name is required.');
      return;
    }

    if (materialToEdit) {
      updateMaterial(materialToEdit.id, {
        name: name.trim(),
        category,
        quantity: Math.max(0, quantity),
        unit: unit.trim(),
        costPerUnit: Math.max(0, costPerUnit),
        lowStockThreshold: Math.max(0, lowStockThreshold),
        notes: notes.trim()
      });
      setShowModal(false);
    } else {
      addMaterial({
        name: name.trim(),
        category,
        quantity: Math.max(0, quantity),
        unit: unit.trim(),
        costPerUnit: Math.max(0, costPerUnit),
        lowStockThreshold: Math.max(0, lowStockThreshold),
        notes: notes.trim()
      });
      setShowModal(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-serif-display text-stone-900 tracking-tight">
            Materials & Haberdashery Stock
          </h1>
          <p className="text-xs text-stone-500 mt-0.5">
            Keep track of embroidery threads, linings, zippers, crystals, and notions
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#58111A] hover:bg-[#4A0E17] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Material</span>
        </button>
      </div>

      {/* Aggregate metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
          <span className="text-xs uppercase font-bold text-stone-400 tracking-wider block">
            Total Inventory Valuation
          </span>
          <p className="text-2xl font-bold font-mono text-stone-900 mt-1">
            {formatCurrency(totalValuation)}
          </p>
          <span className="text-[11px] text-stone-400 mt-1 block">Across {materials.length} tracked materials</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
          <span className="text-xs uppercase font-bold text-stone-400 tracking-wider block">
            Current Stock Items
          </span>
          <p className="text-2xl font-bold font-mono text-emerald-800 mt-1">
            {materials.reduce((sum, m) => sum + m.quantity, 0)} units
          </p>
          <span className="text-[11px] text-stone-400 mt-1 block">In workshop storage</span>
        </div>

        <div
          onClick={() => setShowLowStockOnly(prev => !prev)}
          className={`p-5 rounded-2xl border shadow-2xs cursor-pointer transition-all ${
            showLowStockOnly
              ? 'bg-amber-100 border-amber-400 ring-2 ring-amber-400/40'
              : 'bg-white border-stone-200 hover:border-amber-300'
          }`}
        >
          <span className="text-xs uppercase font-bold text-amber-900 tracking-wider flex items-center justify-between">
            <span>Low-Stock Alerts</span>
            <AlertTriangle className="w-4 h-4 text-amber-600" />
          </span>
          <p className="text-2xl font-bold font-mono text-amber-900 mt-1">
            {lowStockItems.length} items
          </p>
          <span className="text-[11px] text-amber-800/80 mt-1 block">
            {showLowStockOnly ? 'Showing low stock filter (Click to show all)' : 'Click to filter low stock items'}
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-8 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by material name, category (e.g. Zippers, Thread)..."
              className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>

          <div className="sm:col-span-4">
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            >
              <option value="all">All Categories</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Materials Grid / Table */}
      {filteredMaterials.length === 0 ? (
        <EmptyState
          icon={Layers}
          title={materials.length === 0 ? "No inventory items registered" : "No materials match your filters"}
          description="Log buttons, lining fabrics, threads, and zippers to prevent running out of essentials mid-sewing."
          actionLabel={materials.length === 0 ? "Add First Material" : undefined}
          onAction={materials.length === 0 ? handleOpenAdd : undefined}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMaterials.map((mat) => {
            const isLow = mat.quantity <= mat.lowStockThreshold;

            return (
              <div
                key={mat.id}
                className={`bg-white p-5 rounded-2xl border shadow-2xs transition-all flex flex-col justify-between ${
                  isLow ? 'border-amber-300 ring-1 ring-amber-300/40' : 'border-stone-200'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider">
                        {mat.category}
                      </span>
                      <h3 className="font-bold text-stone-900 text-sm font-serif-display mt-0.5">
                        {mat.name}
                      </h3>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEdit(mat)}
                        className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100 transition-colors"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setMaterialToDelete(mat.id)}
                        className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Stock Quantity Adjuster */}
                  <div className="mt-4 p-3 bg-stone-50 rounded-xl border border-stone-100 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-stone-400 uppercase font-semibold block">In Stock</span>
                      <div className="flex items-baseline gap-1">
                        <span className="text-xl font-bold font-mono text-stone-900">{mat.quantity}</span>
                        <span className="text-xs text-stone-500">{mat.unit}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 bg-white border border-stone-200 p-1 rounded-xl shadow-2xs">
                      <button
                        onClick={() => adjustMaterialQuantity(mat.id, -1)}
                        className="w-7 h-7 rounded-lg text-stone-600 hover:bg-stone-100 flex items-center justify-center font-bold text-sm cursor-pointer"
                        title="Reduce 1"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => adjustMaterialQuantity(mat.id, 1)}
                        className="w-7 h-7 rounded-lg text-stone-600 hover:bg-stone-100 flex items-center justify-center font-bold text-sm cursor-pointer"
                        title="Add 1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {mat.notes && (
                    <p className="text-[11px] text-stone-500 italic mt-2.5 line-clamp-2">
                      "{mat.notes}"
                    </p>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
                  <span className="text-stone-500 font-mono">
                    {formatCurrency(mat.costPerUnit)} / {mat.unit}
                  </span>

                  {isLow ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                      <AlertTriangle className="w-3 h-3 text-amber-600" />
                      <span>Low Stock (≤{mat.lowStockThreshold})</span>
                    </span>
                  ) : (
                    <span className="text-[11px] text-emerald-800 font-medium">
                      Total: {formatCurrency(mat.quantity * mat.costPerUnit)}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Material Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-stone-200">
            <div className="bg-[#58111A] text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-amber-300" />
                <h3 className="font-serif-display font-bold text-lg">
                  {materialToEdit ? 'Edit Material' : 'Add Material to Stock'}
                </h3>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-stone-300 hover:text-white p-1 rounded-md transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="p-6 space-y-4">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-medium">
                  {formError}
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Material Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. YKK Invisible Zippers (22-inch)"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                    Category *
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as MaterialCategory)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                  >
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                    Unit of Measurement
                  </label>
                  <input
                    type="text"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    placeholder="yards, pieces, spools"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-stone-700 uppercase mb-1">
                    Quantity
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={quantity}
                    onChange={(e) => setQuantity(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 bg-stone-50 border border-stone-300 rounded-xl text-xs font-mono font-bold text-stone-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-stone-700 uppercase mb-1">
                    Cost / Unit
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={costPerUnit}
                    onChange={(e) => setCostPerUnit(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 bg-stone-50 border border-stone-300 rounded-xl text-xs font-mono font-bold text-stone-900"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-stone-700 uppercase mb-1">
                    Low Alert
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={lowStockThreshold}
                    onChange={(e) => setLowStockThreshold(parseFloat(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 bg-stone-50 border border-stone-300 rounded-xl text-xs font-mono font-bold text-stone-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1">
                  Supplier / Storage Notes
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Purchased at Balogun Market, Shop 4B..."
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-sm font-medium text-stone-600 hover:text-stone-900 bg-stone-100 rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-sm font-semibold text-white bg-[#58111A] hover:bg-[#4A0E17] rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  {materialToEdit ? 'Save Changes' : 'Add to Inventory'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      <ConfirmModal
        isOpen={!!materialToDelete}
        title="Delete Material?"
        message="Are you sure you want to remove this item from your studio inventory?"
        confirmLabel="Delete Item"
        onConfirm={() => {
          if (materialToDelete) {
            deleteMaterial(materialToDelete);
            setMaterialToDelete(null);
          }
        }}
        onCancel={() => setMaterialToDelete(null)}
      />
    </div>
  );
};
