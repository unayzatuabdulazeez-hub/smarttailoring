import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Customer } from '../../types';
import { EmptyState } from '../common/EmptyState';
import { CustomerFormModal } from './CustomerFormModal';
import {
  Users,
  Search,
  Plus,
  Phone,
  Mail,
  MapPin,
  ChevronRight,
  Ruler,
  ShoppingBag
} from 'lucide-react';

interface CustomersViewProps {
  onSelectCustomer: (customerId: string) => void;
}

export const CustomersView: React.FC<CustomersViewProps> = ({ onSelectCustomer }) => {
  const { customers, measurements, orders, globalSearch } = useApp();

  const [search, setSearch] = useState('');
  const [genderFilter, setGenderFilter] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);

  const activeSearch = globalSearch || search;

  const filteredCustomers = useMemo(() => {
    return customers.filter(c => {
      const matchesSearch =
        !activeSearch ||
        c.fullName.toLowerCase().includes(activeSearch.toLowerCase()) ||
        c.phoneNumber.includes(activeSearch) ||
        c.email.toLowerCase().includes(activeSearch.toLowerCase());

      if (!matchesSearch) return false;

      if (genderFilter !== 'all' && c.gender !== genderFilter) {
        return false;
      }

      return true;
    });
  }, [customers, activeSearch, genderFilter]);

  return (
    <div className="space-y-6">
      {/* Top action bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-serif-display text-stone-900 tracking-tight">
            Client Directory
          </h1>
          <p className="text-xs text-stone-500 mt-0.5">
            Manage your bespoke clientele, fitting records, and tailoring preferences ({filteredCustomers.length} clients)
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#58111A] hover:bg-[#4A0E17] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Customer</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-8 relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by client name, phone number, or email..."
              className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            />
          </div>

          <div className="sm:col-span-4">
            <select
              value={genderFilter}
              onChange={(e) => setGenderFilter(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none focus:ring-2 focus:ring-[#58111A]/20 focus:border-[#58111A]"
            >
              <option value="all">All Genders</option>
              <option value="Female">Female</option>
              <option value="Male">Male</option>
              <option value="Other">Other</option>
            </select>
          </div>
        </div>
      </div>

      {/* Customer Cards Grid */}
      {filteredCustomers.length === 0 ? (
        <EmptyState
          icon={Users}
          title={customers.length === 0 ? "No customers yet" : "No customers matching your search"}
          description={
            customers.length === 0
              ? "Add your first customer to start building your tailoring client list and saving measurements."
              : "Try checking the spelling or resetting the gender filter."
          }
          actionLabel={customers.length === 0 ? "Add Customer" : undefined}
          onAction={customers.length === 0 ? () => setShowAddModal(true) : undefined}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCustomers.map((customer) => {
            const clientMeasurements = measurements.filter(m => m.customerId === customer.id);
            const clientOrders = orders.filter(o => o.customerId === customer.id);
            const activeOrders = clientOrders.filter(o => o.productionStatus !== 'Delivered' && o.productionStatus !== 'Cancelled');

            return (
              <div
                key={customer.id}
                onClick={() => onSelectCustomer(customer.id)}
                className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs hover:border-[#58111A]/40 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#58111A]/10 text-[#58111A] font-bold text-sm flex items-center justify-center font-serif-display group-hover:scale-105 transition-transform">
                        {customer.fullName.charAt(0)}
                      </div>
                      <div>
                        <h3 className="font-bold text-stone-900 text-sm font-serif-display group-hover:text-[#58111A] transition-colors">
                          {customer.fullName}
                        </h3>
                        <span className="text-[10px] text-stone-400 font-medium">
                          {customer.gender} · Added {new Date(customer.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    <ChevronRight className="w-4 h-4 text-stone-400 group-hover:text-[#58111A] group-hover:translate-x-0.5 transition-all" />
                  </div>

                  <div className="mt-3 space-y-1.5 text-xs text-stone-600">
                    <p className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                      <span>{customer.phoneNumber}</span>
                    </p>
                    {customer.email && (
                      <p className="flex items-center gap-2 truncate">
                        <Mail className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        <span className="truncate">{customer.email}</span>
                      </p>
                    )}
                    {customer.address && (
                      <p className="flex items-center gap-2 text-stone-500 truncate">
                        <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        <span className="truncate">{customer.address}</span>
                      </p>
                    )}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500 font-medium">
                  <span className="flex items-center gap-1">
                    <Ruler className="w-3.5 h-3.5 text-stone-400" />
                    <span>{clientMeasurements.length} profiles</span>
                  </span>

                  <span className="flex items-center gap-1">
                    <ShoppingBag className="w-3.5 h-3.5 text-stone-400" />
                    <span>{clientOrders.length} orders {activeOrders.length > 0 && `(${activeOrders.length} active)`}</span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Customer Modal */}
      {showAddModal && (
        <CustomerFormModal
          isOpen={showAddModal}
          onClose={() => setShowAddModal(false)}
        />
      )}
    </div>
  );
};
