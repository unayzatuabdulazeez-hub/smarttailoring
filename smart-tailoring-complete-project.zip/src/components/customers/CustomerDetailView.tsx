import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { MeasurementProfile } from '../../types';
import { ProductionStatusBadge, PaymentStatusBadge } from '../common/StatusBadge';
import { ConfirmModal } from '../common/ConfirmModal';
import { MeasurementModal } from '../measurements/MeasurementModal';
import { EmptyState } from '../common/EmptyState';
import {
  ArrowLeft,
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Ruler,
  ShoppingBag,
  CreditCard,
  Edit,
  Trash2,
  Copy,
  Plus,
  ChevronRight,
  FileText
} from 'lucide-react';

interface CustomerDetailViewProps {
  customerId: string;
  onBack: () => void;
  onEditCustomer: () => void;
  onOpenOrder: (orderId: string) => void;
  onNewOrderForCustomer: (customerId: string) => void;
}

export const CustomerDetailView: React.FC<CustomerDetailViewProps> = ({
  customerId,
  onBack,
  onEditCustomer,
  onOpenOrder,
  onNewOrderForCustomer
}) => {
  const {
    getCustomer,
    deleteCustomer,
    getCustomerMeasurements,
    getCustomerOrders,
    payments,
    formatCurrency,
    duplicateMeasurementProfile,
    deleteMeasurementProfile
  } = useApp();

  const [activeTab, setActiveTab] = useState<'measurements' | 'orders' | 'payments' | 'notes'>('measurements');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [measurementToEdit, setMeasurementToEdit] = useState<MeasurementProfile | null>(null);
  const [showMeasurementModal, setShowMeasurementModal] = useState(false);
  const [measurementToDelete, setMeasurementToDelete] = useState<string | null>(null);

  const customer = getCustomer(customerId);
  if (!customer) {
    return (
      <div className="p-8 text-center">
        <p className="text-stone-500">Customer not found.</p>
        <button onClick={onBack} className="mt-4 px-4 py-2 bg-stone-100 rounded-lg text-xs font-semibold">
          Return to Customers
        </button>
      </div>
    );
  }

  const measurements = getCustomerMeasurements(customer.id);
  const orders = getCustomerOrders(customer.id);
  // Get all payments for customer
  const customerPayments = payments.filter(p => p.customerId === customer.id);

  const totalSpent = orders.reduce((sum, o) => sum + o.sellingPrice, 0);
  const totalPaid = orders.reduce((sum, o) => sum + o.amountPaid, 0);
  const totalBalance = orders.reduce((sum, o) => sum + o.balanceDue, 0);

  const handleConfirmDeleteCustomer = () => {
    deleteCustomer(customer.id);
    onBack();
  };

  return (
    <div className="space-y-6">
      {/* Top action bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 bg-white hover:bg-stone-100 border border-stone-200 rounded-xl text-stone-600 transition-colors cursor-pointer"
            title="Back to Customers"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold font-serif-display text-stone-900 tracking-tight">
                {customer.fullName}
              </h1>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-stone-100 text-stone-700 font-medium">
                {customer.gender}
              </span>
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              Client since {new Date(customer.createdAt).toLocaleDateString()}
            </p>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNewOrderForCustomer(customer.id)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#58111A] hover:bg-[#4A0E17] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create Order</span>
          </button>

          <button
            onClick={onEditCustomer}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            <Edit className="w-3.5 h-3.5" />
            <span>Edit</span>
          </button>

          <button
            onClick={() => setShowDeleteModal(true)}
            className="p-2 text-stone-400 hover:text-rose-600 rounded-xl hover:bg-rose-50 transition-colors"
            title="Delete Customer"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Customer summary card */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* Contact info (7 cols) */}
        <div className="md:col-span-7 bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-3">
          <h3 className="text-xs font-bold text-stone-400 uppercase tracking-wider">
            Contact & Address Details
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-stone-700">
            <div>
              <span className="text-stone-400 block text-[11px] mb-0.5">Phone Number</span>
              <p className="font-semibold text-stone-900 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-stone-400" />
                {customer.phoneNumber}
              </p>
            </div>
            <div>
              <span className="text-stone-400 block text-[11px] mb-0.5">Email Address</span>
              <p className="font-semibold text-stone-900 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-stone-400" />
                {customer.email || 'None'}
              </p>
            </div>
            <div className="sm:col-span-2">
              <span className="text-stone-400 block text-[11px] mb-0.5">Address</span>
              <p className="text-stone-800 flex items-start gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-stone-400 mt-0.5 shrink-0" />
                {customer.address || 'No address provided'}
              </p>
            </div>
          </div>
        </div>

        {/* Financial Quick Metrics (5 cols) */}
        <div className="md:col-span-5 bg-[#58111A] text-white p-5 rounded-2xl shadow-2xs flex flex-col justify-between space-y-4">
          <span className="text-xs uppercase tracking-widest text-amber-200/80 font-bold">
            Client Lifetime Value
          </span>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div>
              <span className="text-[10px] text-stone-300 uppercase block">Total Orders</span>
              <span className="text-xl font-bold font-mono">{orders.length}</span>
            </div>
            <div>
              <span className="text-[10px] text-emerald-300 uppercase block">Total Paid</span>
              <span className="text-sm font-bold font-mono text-emerald-300">{formatCurrency(totalPaid)}</span>
            </div>
            <div>
              <span className="text-[10px] text-amber-300 uppercase block">Outstanding</span>
              <span className="text-sm font-bold font-mono text-amber-300">{formatCurrency(totalBalance)}</span>
            </div>
          </div>
          <div className="text-[11px] text-amber-100/70 border-t border-white/10 pt-2 flex items-center justify-between">
            <span>Gross Invoiced:</span>
            <span className="font-bold font-mono">{formatCurrency(totalSpent)}</span>
          </div>
        </div>
      </div>

      {/* Profile Section Tabs */}
      <div className="border-b border-stone-200 flex gap-4 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('measurements')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'measurements'
              ? 'border-[#58111A] text-[#58111A]'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <Ruler className="w-4 h-4" />
          <span>Measurement Profiles ({measurements.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'orders'
              ? 'border-[#58111A] text-[#58111A]'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Order History ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('payments')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'payments'
              ? 'border-[#58111A] text-[#58111A]'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>Payments Ledger ({customerPayments.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('notes')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-colors cursor-pointer ${
            activeTab === 'notes'
              ? 'border-[#58111A] text-[#58111A]'
              : 'border-transparent text-stone-500 hover:text-stone-800'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Fitting & Styling Notes</span>
        </button>
      </div>

      {/* Tab 1: Measurements */}
      {activeTab === 'measurements' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <p className="text-xs text-stone-500">
              Saved anatomical measurement profiles for {customer.fullName}
            </p>
            <button
              onClick={() => {
                setMeasurementToEdit(null);
                setShowMeasurementModal(true);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#58111A] hover:bg-[#4A0E17] text-white text-xs font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Measurement Profile</span>
            </button>
          </div>

          {measurements.length === 0 ? (
            <EmptyState
              icon={Ruler}
              title="No measurement profiles saved yet"
              description={`Record ${customer.fullName}'s measurements (e.g. Kaftan, Agbada, Evening Gown) so you can attach them directly to orders.`}
              actionLabel="Take Measurements"
              onAction={() => {
                setMeasurementToEdit(null);
                setShowMeasurementModal(true);
              }}
            />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {measurements.map(m => (
                <div key={m.id} className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-bold text-stone-900 text-sm font-serif-display">
                        {m.profileName}
                      </h4>
                      <p className="text-[11px] text-stone-400 mt-0.5">
                        Recorded {new Date(m.recordedAt).toLocaleDateString()} · Unit: <span className="font-semibold text-stone-600">{m.unit}</span>
                      </p>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => duplicateMeasurementProfile(m.id)}
                        className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100 transition-colors"
                        title="Duplicate Profile"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          setMeasurementToEdit(m);
                          setShowMeasurementModal(true);
                        }}
                        className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100 transition-colors"
                        title="Edit Profile"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setMeasurementToDelete(m.id)}
                        className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                        title="Delete Profile"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Measurement points grid */}
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 text-xs pt-1">
                    {Object.entries(m.measurements)
                      .filter(([_, val]) => typeof val === 'number' && val > 0)
                      .slice(0, 12)
                      .map(([key, val]) => (
                        <div key={key} className="bg-stone-50 p-1.5 rounded-lg border border-stone-100">
                          <span className="block text-[10px] text-stone-500 capitalize truncate">
                            {key.replace(/([A-Z])/g, ' $1')}
                          </span>
                          <span className="font-bold text-stone-900 font-mono text-xs">
                            {val}
                            <span className="text-[9px] text-stone-400 ml-0.5">{m.unit === 'inches' ? '"' : 'cm'}</span>
                          </span>
                        </div>
                      ))}
                  </div>

                  {m.notes && (
                    <p className="text-[11px] text-stone-500 italic border-t border-stone-100 pt-2 line-clamp-2">
                      "{m.notes}"
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Orders */}
      {activeTab === 'orders' && (
        <div className="space-y-3">
          {orders.length === 0 ? (
            <EmptyState
              icon={ShoppingBag}
              title="No orders yet for this client"
              description={`Create an order for ${customer.fullName} to start tracking fabric cutting, fittings, and payments.`}
              actionLabel="Create Order"
              onAction={() => onNewOrderForCustomer(customer.id)}
            />
          ) : (
            orders.map(order => (
              <div
                key={order.id}
                onClick={() => onOpenOrder(order.id)}
                className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs hover:border-[#58111A]/40 transition-all cursor-pointer flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-sm text-stone-900">{order.orderNumber}</span>
                    <span className="text-stone-300">·</span>
                    <span className="text-sm font-semibold text-[#58111A]">
                      {order.outfitType === 'Custom' ? order.customOutfitType : order.outfitType}
                    </span>
                    <ProductionStatusBadge status={order.productionStatus} size="sm" />
                  </div>
                  <p className="text-xs text-stone-500 mt-1">
                    Promised Delivery: {new Date(order.deliveryDate).toLocaleDateString()} · {order.fabricType || 'Bespoke fabric'}
                  </p>
                </div>

                <div className="text-right flex items-center gap-4">
                  <div>
                    <span className="font-bold font-mono text-sm text-stone-900 block">{formatCurrency(order.sellingPrice)}</span>
                    <span className="text-xs font-mono text-stone-500">
                      {order.balanceDue > 0 ? `Bal: ${formatCurrency(order.balanceDue)}` : 'Paid'}
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-stone-400" />
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Tab 3: Payments */}
      {activeTab === 'payments' && (
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs">
          {customerPayments.length === 0 ? (
            <p className="text-xs text-stone-400 py-6 text-center">No payment transactions recorded yet.</p>
          ) : (
            <div className="divide-y divide-stone-100 text-xs">
              {customerPayments.map((p, idx) => (
                <div key={p.id} className="py-3 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-stone-800 text-sm font-mono">{formatCurrency(p.amount)}</span>
                    <p className="text-stone-500 mt-0.5">
                      {p.paymentDate} · via <span className="font-semibold">{p.paymentMethod}</span> {p.note && `· "${p.note}"`}
                    </p>
                  </div>
                  <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded text-[11px] font-semibold">
                    Received
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Notes */}
      {activeTab === 'notes' && (
        <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-2xs space-y-3">
          <h3 className="text-xs font-bold text-stone-400 uppercase tracking-wider">
            Tailoring & Fitting Preferences
          </h3>
          {customer.notes ? (
            <p className="text-sm text-stone-700 leading-relaxed bg-stone-50 p-4 rounded-xl border border-stone-100">
              {customer.notes}
            </p>
          ) : (
            <p className="text-xs text-stone-400 italic">No special notes recorded. Click Edit above to add styling preferences.</p>
          )}
        </div>
      )}

      {/* Modals */}
      <ConfirmModal
        isOpen={showDeleteModal}
        title="Delete Customer Profile?"
        message={`Are you sure you want to delete ${customer.fullName}? This will also delete their saved measurements and orders.`}
        confirmLabel="Delete Customer"
        onConfirm={handleConfirmDeleteCustomer}
        onCancel={() => setShowDeleteModal(false)}
      />

      <ConfirmModal
        isOpen={!!measurementToDelete}
        title="Delete Measurement Profile?"
        message="Are you sure you want to delete this measurement profile?"
        confirmLabel="Delete Profile"
        onConfirm={() => {
          if (measurementToDelete) {
            deleteMeasurementProfile(measurementToDelete);
            setMeasurementToDelete(null);
          }
        }}
        onCancel={() => setMeasurementToDelete(null)}
      />

      {showMeasurementModal && (
        <MeasurementModal
          isOpen={showMeasurementModal}
          onClose={() => {
            setShowMeasurementModal(false);
            setMeasurementToEdit(null);
          }}
          customerId={customer.id}
          measurementToEdit={measurementToEdit}
        />
      )}
    </div>
  );
};
