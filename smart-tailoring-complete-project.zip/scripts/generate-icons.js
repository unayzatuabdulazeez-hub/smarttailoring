import { PNG } from 'pngjs';
import fs from 'fs';

function drawIcon(size, filename, isMaskable = false) {
  const png = new PNG({ width: size, height: size });

  const burgundyR = 0x58, burgundyG = 0x11, burgundyB = 0x1A;
  const darkBurgundyR = 0x3A, darkBurgundyG = 0x0B, darkBurgundyB = 0x11;
  const goldR = 0xD4, goldG = 0xAF, goldB = 0x37;
  const lightGoldR = 0xF5, lightGoldG = 0xE0, lightGoldB = 0xA3;

  const center = size / 2;
  const cornerRadius = isMaskable ? 0 : size * 0.22;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (size * y + x) << 2;

      // Rounded rect check (if not maskable)
      let inside = true;
      if (!isMaskable) {
        let dx = 0;
        let dy = 0;
        if (x < cornerRadius) dx = cornerRadius - x;
        else if (x > size - cornerRadius) dx = x - (size - cornerRadius);
        if (y < cornerRadius) dy = cornerRadius - y;
        else if (y > size - cornerRadius) dy = y - (size - cornerRadius);

        if (dx > 0 && dy > 0 && Math.sqrt(dx * dx + dy * dy) > cornerRadius) {
          inside = false;
        }
      }

      if (!inside) {
        png.data[idx] = 0;
        png.data[idx + 1] = 0;
        png.data[idx + 2] = 0;
        png.data[idx + 3] = 0;
        continue;
      }

      // Background gradient
      const gradFactor = (x + y) / (size * 2);
      let r = Math.round(burgundyR * (1 - gradFactor) + darkBurgundyR * gradFactor);
      let g = Math.round(burgundyG * (1 - gradFactor) + darkBurgundyG * gradFactor);
      let b = Math.round(burgundyB * (1 - gradFactor) + darkBurgundyB * gradFactor);

      // Gold border
      const borderDist = Math.min(x, y, size - 1 - x, size - 1 - y);
      if (borderDist >= size * 0.04 && borderDist <= size * 0.055) {
        r = goldR;
        g = goldG;
        b = goldB;
      }

      // Draw stylized scissors
      const nx = (x - center) / (size * 0.4);
      const ny = (y - center) / (size * 0.4);

      // Scissor blade 1 (diagonal line)
      const d1 = Math.abs(ny - (nx * 1.3 - 0.1));
      const inBlade1 = d1 < 0.1 && ny < 0.6 && ny > -0.8;

      // Scissor blade 2 (opposite diagonal)
      const d2 = Math.abs(ny - (-nx * 1.3 - 0.1));
      const inBlade2 = d2 < 0.1 && ny < 0.6 && ny > -0.8;

      // Left loop
      const distLoop1 = Math.hypot(nx - (-0.35), ny - 0.55);
      const inLoop1 = distLoop1 < 0.25 && distLoop1 > 0.12;

      // Right loop
      const distLoop2 = Math.hypot(nx - 0.35, ny - 0.55);
      const inLoop2 = distLoop2 < 0.25 && distLoop2 > 0.12;

      // Pivot rivet
      const distPivot = Math.hypot(nx, ny - 0.05);
      const inPivot = distPivot < 0.08;

      if (inPivot) {
        r = lightGoldR;
        g = lightGoldG;
        b = lightGoldB;
      } else if (inBlade1 || inBlade2 || inLoop1 || inLoop2) {
        r = goldR;
        g = goldG;
        b = goldB;
      }

      png.data[idx] = r;
      png.data[idx + 1] = g;
      png.data[idx + 2] = b;
      png.data[idx + 3] = 255;
    }
  }

  const buffer = PNG.sync.write(png);
  fs.writeFileSync(filename, buffer);
  console.log(`Generated ${filename} (${size}x${size})`);
}

drawIcon(192, 'public/pwa-192x192.png');
drawIcon(512, 'public/pwa-512x512.png');
drawIcon(180, 'public/apple-touch-icon.png');
drawIcon(512, 'public/maskable-icon-512x512.png', true);
